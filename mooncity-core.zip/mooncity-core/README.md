# MoonCity Core (Forge 1.20.1)

Mod pentru serverul MoonCity (RP). Lucrează împreună cu **MrCrayfish's Vehicle** (+ Framework).

## Build
Pune `mooncity-core.zip` în repo + `.github/workflows/build.yml` (dezarhivează și compilează).
Jar-ul apare la **Actions → Build → Artifacts**. Local: `gradle build` (Gradle 8.1.1, Java 17).

## Taste
K meniu circular | P telefon | M hartă (teren real, GPS) | O garaj | G portbagaj
I meniu mecanic (doar jobul Mecanic) | J minijoc (sudor / constructor)
Shift + click dreapta pe jucător = interacțiune (buletin, legitimație, percheziție)

## Comenzi (op)
/mc npc banker|shop [0-4]|fuel|kevin|dealer   (shop: 0=24/7 1=Haine 2=Unelte 3=Electronice 4=Farmacie)
/mc npcremove | /mc poi <garage|job|shop|bank|fuel|delivery|spawn|safezone|dealer> <nume> | /mc poiclear
/mc safezone <raza> <nume> | /mc zoneclear | /mc license <jucător>
/setid <jucător> <id> | /givemoney <jucător> <lei>
/rank set <jucător> <grad> <culoare>   ex: /rank set Ion tirist galben   | /rank remove <jucător>
/staff <jucător> true|false   (sau din K → Admin, doar owner/op nivel 4)
/ticket

## Blocuri
ATM (creative → Functional) și Boxă portabilă JBL (creative sau magazinul „Electronice").

## Sisteme noi
- **ATM cu PIN:** primul click îți cere să setezi un PIN (4 cifre). Tranzacțiile se văd în bancă / telefon.
- **Garaje cu zonă (cerc, 10 blocuri):** `/garage personal zone [raza]` pentru garajele jucătorilor; tasta O merge doar în zonă.
- **Garaj de facțiune:** `/garage politie zone` (zona) și, stând într-un vehicul, `/garage politie add` (adaugă vehiculul ca model). Membrii facțiunii îl scot din O → „Garaj politie”.
- **Facțiuni:** `/faction set <jucător> politie|mafie|...`, `/faction remove <jucător>`.
- **MDT:** item „Tabletă MDT” (creative) sau K → MDT. Poliție: căutați, dosare, persoane, dispecerat 112, unități, daune. Alte facțiuni: dosare, persoane, unități.
- **/112 <text>** către poliție. **/anunt <text>** banner sus pentru toți (staff).
- **Documente:** buletin, permis auto/armă (`/doc give <jucător> auto|arma`, poliție sau staff), contracte casă.
- **Case:** `/mc house <preț>` în locul casei; jucătorii cumpără din telefon → Case.
- **Asigurări + dosare de daună:** telefon → Asigurări; poliția/staff aprobă în MDT → Daune și plătește despăgubirea.
- **Mecanic:** I → Panou (piese cu dependențe, tuning, neon cu culoare).

## Facțiuni din MDT
- Staff/owner: **K → MDT → Facțiune → Creează facțiune** (ex: `mafia1`, `politie`). Devii liderul.
- Liderul: adaugă membri după ID, îi scoate, dă/retrage **Garaj ON/OFF**, pune garajul privat (**Garaj aici**, cerc 10 blocuri), adaugă vehicule în garaj (**+ Vehicul**, stând în el) și șterge zonele.
- Membrii cu acces: **O → Garaj <facțiune>** în cercul facțiunii.
- Staff: **Desființează** șterge facțiunea (membri, zone, vehicule).
- **Predarea conducerii:** în MDT → Facțiune, buton **Lider** pe fiecare membru (după ce îl adaugi cu ID). Apoi staff-ul poate apăsa **Părăsește**. Sau direct: `/faction leader <jucător> <nume_facțiune>`.
