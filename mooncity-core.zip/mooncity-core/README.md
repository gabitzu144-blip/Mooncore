# MoonCity Core (Forge 1.20.1)

Mod pentru serverul MoonCity: HUD, bancă, NPC-uri, magazin, benzinărie, garaj, portbagaj și 10 joburi.
Funcționează împreună cu **MrCrayfish's Vehicle** (+ Framework), dar compilarea nu depinde de el.

## Cum îl compilezi
1. Urcă tot folderul pe GitHub.
2. Intră la **Actions → Build** (rulează automat la fiecare push).
3. Descarcă artifact-ul `mooncity_core` – conține `.jar`-ul.
4. Pune jar-ul în `mods/` împreună cu Vehicle + Framework (Forge 47.x).

Local: `gradle build` (Gradle 8.1.1, Java 17) → `build/libs/`.

## Taste
- **K** meniu (joburi, garaj, portbagaj, hartă)
- **O** garaj  |  **G** portbagaj (vehiculul din apropiere / în care ești)

## Comenzi (op)
- `/mc npc banker|shop|fuel`  – pune un NPC unde stai
- `/mc npcremove`  – șterge NPC-urile din 4 blocuri
- `/mc poi <garage|job|shop|bank|fuel|delivery> <nume>` – punct pe hartă (delivery = adrese pentru curier/tirist)
- `/mc poiclear`
- `/setid <jucător> <id>`  – owner schimbă ID-ul (unic)
- `/givemoney <jucător> <lei>`

ID-ul se dă automat (1, 2, 3...) la prima intrare; HUD arată și „#ordine / total".

## Joburi
Forger, constructor, sudor, curier, gunoier, tirist, fermier, pădurar, grădinar, apicultor – se pornesc din K → Joburi.
Plățile sunt în `server/Jobs.java`, produsele din magazin în `server/Shop.java`.

## Note
- Benzina folosește metodele din Vehicle prin reflecție (`getCurrentFuel`, `getFuelCapacity`, `addFuel`).
  Dacă alimentarea zice „incompatibil", spune-mi și ajustez după clasele din jar.
- Loading screen: înlocuiește ecranul de încărcare al lumii. Poți adăuga poze în `assets/mooncity/textures/gui/`.
