package com.mooncity.core.net;

import com.mooncity.core.client.ClientHooks;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** which: 0 banca, 1 magazin, 2 benzinarie */
public class OpenScreenPacket {
    public final int which;
    public OpenScreenPacket(int which) { this.which = which; }
    public void encode(FriendlyByteBuf b) { b.writeInt(which); }
    public static OpenScreenPacket decode(FriendlyByteBuf b) { return new OpenScreenPacket(b.readInt()); }

    public static void handle(OpenScreenPacket m, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() ->
            DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientHooks.open(m.which)));
        ctx.get().setPacketHandled(true);
    }
}
