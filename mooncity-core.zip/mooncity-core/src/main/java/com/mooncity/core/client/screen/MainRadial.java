package com.mooncity.core.client.screen;

import com.mooncity.core.net.ActionPacket;
import com.mooncity.core.net.ClientState;
import com.mooncity.core.net.Net;
import net.minecraft.client.Minecraft;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.util.ArrayList;
import java.util.List;

public class MainRadial {
    private static void open(net.minecraft.client.gui.screens.Screen s) { Minecraft.getInstance().setScreen(s); }

    public static RadialScreen create() {
        List<RadialScreen.Entry> e = new ArrayList<>();
        e.add(new RadialScreen.Entry("Inventar", new ItemStack(Items.CHEST), () -> open(new MoonInventoryScreen())));
        e.add(new RadialScreen.Entry("Tabletă", new ItemStack(Items.COMPARATOR), () -> open(new PhoneScreen())));
        e.add(new RadialScreen.Entry("Hartă", new ItemStack(Items.FILLED_MAP), () -> open(new MapScreen())));
        e.add(new RadialScreen.Entry("Magazine", new ItemStack(Items.EMERALD), () -> open(new NavigatorScreen("shop"))));
        e.add(new RadialScreen.Entry("Misiuni", new ItemStack(Items.WRITABLE_BOOK), () -> open(new TasksScreen())));
        e.add(new RadialScreen.Entry("Documente", new ItemStack(Items.NAME_TAG), () -> open(new DocumentsScreen())));
        e.add(new RadialScreen.Entry("Animații", new ItemStack(Items.NOTE_BLOCK), () -> open(new AnimationsScreen())));
        e.add(new RadialScreen.Entry("Tickete", new ItemStack(Items.PAPER), () -> open(new TicketsScreen())));
        if (!ClientState.faction.isEmpty() || ClientState.staff) e.add(new RadialScreen.Entry("MDT", new ItemStack(Items.SPYGLASS), () -> open(new MdtScreen())));
        if (ClientState.staff) e.add(new RadialScreen.Entry("Staff", new ItemStack(Items.COMMAND_BLOCK), () -> open(new StaffScreen())));
        if (ClientState.owner) e.add(new RadialScreen.Entry("Admin", new ItemStack(Items.NETHER_STAR), () -> open(new AdminScreen())));
        return new RadialScreen("MOONCITY", e);
    }

    public static RadialScreen mechanic() {
        List<RadialScreen.Entry> e = new ArrayList<>();
        e.add(new RadialScreen.Entry("Repară", new ItemStack(Items.ANVIL), () -> Net.CH.sendToServer(new ActionPacket(ActionPacket.MECH, 0, 0))));
        e.add(new RadialScreen.Entry("Vopsește", new ItemStack(Items.RED_DYE), () -> open(new ColorPickScreen("VOPSEA VEHICUL", 200, 30, 30,
                rgb -> Net.CH.sendToServer(new ActionPacket(ActionPacket.MECH, 1, rgb))))));
        e.add(new RadialScreen.Entry("Alimentează", new ItemStack(Items.BUCKET), () -> Net.CH.sendToServer(new ActionPacket(ActionPacket.MECH, 2, 0))));
        e.add(new RadialScreen.Entry("Panou", new ItemStack(Items.REDSTONE), () -> open(new MechanicPanelScreen())));
        e.add(new RadialScreen.Entry("Verifică", new ItemStack(Items.SPYGLASS), () -> Net.CH.sendToServer(new ActionPacket(ActionPacket.MECH, 3, 0))));
        return new RadialScreen("MECANIC", e);
    }

    public static RadialScreen interaction(int entityId) {
        List<RadialScreen.Entry> e = new ArrayList<>();
        e.add(new RadialScreen.Entry("Buletin", new ItemStack(Items.NAME_TAG), () -> Net.CH.sendToServer(new ActionPacket(ActionPacket.INTERACT, entityId, 0))));
        e.add(new RadialScreen.Entry("Legitimație", new ItemStack(Items.SHIELD), () -> Net.CH.sendToServer(new ActionPacket(ActionPacket.INTERACT, entityId, 1))));
        e.add(new RadialScreen.Entry("Percheziție", new ItemStack(Items.SPYGLASS), () -> Net.CH.sendToServer(new ActionPacket(ActionPacket.INTERACT, entityId, 2))));
        return new RadialScreen("INTERACȚIUNE", e);
    }
}
