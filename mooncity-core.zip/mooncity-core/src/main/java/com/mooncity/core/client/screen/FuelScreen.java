package com.mooncity.core.client.screen;

import com.mooncity.core.net.ActionPacket;
import com.mooncity.core.net.ClientState;
import com.mooncity.core.net.Net;
import com.mooncity.core.server.Shop;
import com.mooncity.core.util.VehicleUtil;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.Entity;

public class FuelScreen extends MoonScreen {
    public FuelScreen() { super("BENZINĂRIE"); pw = 260; ph = 150; }

    @Override
    protected void build() {
        int w = 74, x0 = px + 12;
        int[] pct = {10, 50, 100};
        String[] names = {"+10%", "+50%", "Plin"};
        for (int i = 0; i < 3; i++) {
            final int p = pct[i];
            btn(names[i], x0 + i * (w + 6), py + 80, w, b -> Net.CH.sendToServer(new ActionPacket(ActionPacket.REFUEL, p, 0)));
        }
        btn("Închide", px + pw / 2 - 40, py + 112, 80, b -> onClose());
    }

    @Override
    protected void draw(GuiGraphics g, int mx, int my) {
        g.drawString(font, "Cash: " + ClientState.cash + " lei", px + 12, py + 24, 0xFF55FF55, false);
        Entity v = VehicleUtil.find(minecraft.player);
        if (v == null || !VehicleUtil.isPowered(v)) {
            g.drawString(font, "Apropie-te de un vehicul.", px + 12, py + 44, 0xFFFF5555, false);
            return;
        }
        float cap = VehicleUtil.capacity(v), cur = VehicleUtil.fuel(v);
        if (cap <= 0) { g.drawString(font, "Vehicul incompatibil.", px + 12, py + 44, 0xFFFF5555, false); return; }
        g.drawString(font, v.getType().getDescription(), px + 12, py + 40, 0xFFFFFFFF, false);
        g.fill(px + 12, py + 54, px + pw - 12, py + 64, 0xFF1B2A1B);
        g.fill(px + 12, py + 54, px + 12 + (int) ((pw - 24) * Math.min(1f, cur / cap)), py + 64, 0xFF2EAA55);
        g.drawString(font, Math.round(cur) + " / " + Math.round(cap) + "   (" + Shop.FUEL_PRICE_PER_UNIT + " lei/unitate)",
                px + 12, py + 68, 0xFFAAAAAA, false);
    }
}
