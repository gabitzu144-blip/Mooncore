package com.mooncity.core.client.screen;

import com.mooncity.core.net.ActionPacket;
import com.mooncity.core.net.Net;
import com.mooncity.core.util.Weights;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** Inventar MoonCity: categorii, sortare dupa greutate, echipare si aruncare. */
public class MoonInventoryScreen extends MoonScreen {
    private static final String[] TABS = {"General", "Mâncare", "Arme", "Haine", "Altele"};
    private int tab = 0, selected = -1;
    private boolean byWeight = true;
    private final List<int[]> cells = new ArrayList<>();

    public MoonInventoryScreen() { super("INVENTAR"); pw = 440; ph = 262; }

    @Override
    protected void build() {
        for (int i = 0; i < TABS.length; i++) {
            final int fi = i;
            btn((tab == i ? "► " : "") + TABS[i], px + 160 + i * 56, py + 22, 54, b -> { tab = fi; selected = -1; rebuildWidgets(); });
        }
        btn("Sort: " + (byWeight ? "greutate" : "nume"), px + 160, py + ph - 26, 90, b -> { byWeight = !byWeight; rebuildWidgets(); });
        btn("Echipează", px + 254, py + ph - 26, 70, b -> { if (selected >= 0) Net.CH.sendToServer(new ActionPacket(ActionPacket.INV_EQUIP, selected, 0)); selected = -1; });
        btn("Aruncă", px + 328, py + ph - 26, 54, b -> { if (selected >= 0) Net.CH.sendToServer(new ActionPacket(ActionPacket.INV_DROP, selected, 0)); selected = -1; });
        btn("Închide", px + pw - 54, py + ph - 26, 48, b -> onClose());
    }

    private List<Integer> visible() {
        List<Integer> slots = new ArrayList<>();
        var inv = minecraft.player.getInventory();
        for (int i = 0; i < 36; i++) {
            ItemStack s = inv.getItem(i);
            if (s.isEmpty()) continue;
            if (tab != 0 && Weights.category(s) != tab) continue;
            slots.add(i);
        }
        if (byWeight) slots.sort(Comparator.comparingDouble((Integer i) -> -Weights.of(inv.getItem(i))));
        else slots.sort(Comparator.comparing((Integer i) -> inv.getItem(i).getHoverName().getString()));
        return slots;
    }

    @Override
    protected void draw(GuiGraphics g, int mx, int my) {
        var p = minecraft.player;
        int count = 0;
        for (ItemStack s : p.getInventory().items) if (!s.isEmpty()) count++;
        g.drawString(font, "Obiecte (" + count + "/36)", px + 160, py + 8, 0xFFFFFFFF, false);
        double w = Weights.total(p);
        g.drawString(font, String.format("%.1f / %.0f kg", w, Weights.MAX), px + 270, py + 8, w > Weights.MAX ? 0xFFFF5555 : 0xFF55FF55, false);

        // echipament
        String[] names = {"Cap", "Armură", "Pantaloni", "Pantofi", "Mână", "Mână 2"};
        ItemStack[] eq = {p.getItemBySlot(EquipmentSlot.HEAD), p.getItemBySlot(EquipmentSlot.CHEST), p.getItemBySlot(EquipmentSlot.LEGS),
                p.getItemBySlot(EquipmentSlot.FEET), p.getMainHandItem(), p.getOffhandItem()};
        for (int i = 0; i < 6; i++) {
            int x = px + 12 + (i % 2) * 70, y = py + 28 + (i / 2) * 62;
            g.fill(x, y, x + 64, y + 56, 0xFF161B3A);
            g.drawCenteredString(font, names[i], x + 32, y + 4, 0xFFAAAAAA);
            g.renderItem(eq[i], x + 24, y + 26);
            if (mx >= x && mx < x + 64 && my >= y && my < y + 56 && !eq[i].isEmpty())
                g.renderTooltip(font, eq[i], mx, my);
        }

        // grila
        cells.clear();
        List<Integer> vis = visible();
        for (int n = 0; n < vis.size() && n < 54; n++) {
            int x = px + 160 + (n % 9) * 30, y = py + 46 + (n / 9) * 30;
            int slot = vis.get(n);
            g.fill(x, y, x + 28, y + 28, slot == selected ? 0xFF6B5A10 : 0xFF161B3A);
            ItemStack s = p.getInventory().getItem(slot);
            g.renderItem(s, x + 6, y + 6);
            g.renderItemDecorations(font, s, x + 6, y + 6);
            cells.add(new int[]{x, y, slot});
        }
        for (int[] c : cells)
            if (mx >= c[0] && mx < c[0] + 28 && my >= c[1] && my < c[1] + 28) {
                ItemStack s = p.getInventory().getItem(c[2]);
                List<Component> tip = new ArrayList<>(Screen.getTooltipFromItem(minecraft, s));
                tip.add(Component.literal(String.format("Greutate: %.1f kg", Weights.of(s))));
                g.renderComponentTooltip(font, tip, mx, my);
            }
    }

    @Override
    public boolean mouseClicked(double mx, double my, int btn) {
        if (super.mouseClicked(mx, my, btn)) return true;
        for (int[] c : cells) if (mx >= c[0] && mx < c[0] + 28 && my >= c[1] && my < c[1] + 28) { selected = c[2]; return true; }
        return false;
    }
}
