package com.mooncity.core.client.screen;

import com.mooncity.core.net.ActionPacket;
import com.mooncity.core.net.ClientState;
import com.mooncity.core.net.Net;
import com.mooncity.core.server.Parts;
import net.minecraft.client.gui.GuiGraphics;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Panou de mecanic (tableta rosie): componente, dependinte, montare/demontare, neon. */
public class MechanicPanelScreen extends MoonScreen {
    private int sel = 0, ticks = 0, lastHash = 0;

    public MechanicPanelScreen() { super("MECHANIC PANEL"); pw = 440; ph = 262; }

    private Set<String> installed() {
        Set<String> s = new HashSet<>();
        for (String r : ClientState.list(17)) if (r.startsWith("part|")) s.add(r.substring(5));
        return s;
    }
    private String vehicle() {
        for (String r : ClientState.list(17)) if (r.startsWith("veh|")) return r.substring(4);
        return "";
    }
    private int neonRgb() {
        for (String r : ClientState.list(17)) if (r.startsWith("neon|")) return Integer.parseInt(r.substring(5));
        return -1;
    }

    @Override
    protected void build() {
        Set<String> inst = installed();
        for (int i = 0; i < Parts.ALL.size(); i++) {
            final int fi = i;
            Parts.Part p = Parts.ALL.get(i);
            boolean locked = false;
            for (String d : p.deps()) if (!inst.contains(d)) locked = true;
            String mark = inst.contains(p.id()) ? "● " : locked ? "✘ " : "○ ";
            btn((sel == i ? "► " : "") + mark + p.name(), px + 8, py + 30 + i * 18, 190, b -> { sel = fi; rebuildWidgets(); });
        }
        Parts.Part cur = Parts.ALL.get(sel);
        btn(inst.contains(cur.id()) ? "DEMONTEAZĂ" : "MONTEAZĂ (" + cur.price() + " lei)", px + 210, py + 190, 220, b ->
            Net.CH.sendToServer(new ActionPacket(ActionPacket.PART_TOGGLE, sel, 0)));
        if (inst.contains("neon"))
            btn("Culoare neon", px + 210, py + 214, 108, b -> {
                int c = neonRgb() < 0 ? 0x22D3EE : neonRgb();
                minecraft.setScreen(new ColorPickScreen("CULOARE NEON", (c >> 16) & 255, (c >> 8) & 255, c & 255,
                    rgb -> Net.CH.sendToServer(new ActionPacket(ActionPacket.NEON_SET, rgb, 0))));
            });
        btn("Ieșire", px + 322, py + 214, 108, b -> onClose());
    }

    @Override
    public void tick() {
        if (ticks++ % 20 == 0) Net.CH.sendToServer(new ActionPacket(ActionPacket.REQ, 17, 0));
        int h = ClientState.list(17).hashCode();
        if (h != lastHash) { lastHash = h; rebuildWidgets(); }
    }

    @Override
    protected void draw(GuiGraphics g, int mx, int my) {
        Set<String> inst = installed();
        long stage = inst.size();
        g.drawString(font, "Vehicul: " + (vehicle().isEmpty() ? "— niciun vehicul lângă tine —" : vehicle()) + "     STAGE " + stage + "/" + Parts.ALL.size(), px + 8, py + 18, 0xFFFF8A3D, false);
        Parts.Part p = Parts.ALL.get(sel);
        g.fill(px + 206, py + 30, px + pw - 8, py + 184, 0xFF0E1330);
        g.drawString(font, "COMPONENTĂ SELECTATĂ", px + 212, py + 36, 0xFF888888, false);
        g.drawString(font, p.name(), px + 212, py + 48, 0xFFFFFFFF, false);
        g.drawString(font, p.cat() + "   " + p.price() + " lei", px + 212, py + 60, 0xFFF5C518, false);
        boolean has = inst.contains(p.id());
        g.drawString(font, has ? "STATUS: MONTAT" : "STATUS: DISPONIBIL", px + 212, py + 74, has ? 0xFF55FF55 : 0xFF22D3EE, false);
        g.drawString(font, "DEPENDENȚE", px + 212, py + 92, 0xFF888888, false);
        if (p.deps().length == 0) g.drawString(font, "nicio dependență", px + 212, py + 104, 0xFF55FF55, false);
        for (int i = 0; i < p.deps().length; i++) {
            Parts.Part d = Parts.ALL.get(Parts.index(p.deps()[i]));
            boolean ok = inst.contains(d.id());
            g.drawString(font, (ok ? "✔ " : "✘ ") + d.name(), px + 212, py + 104 + i * 11, ok ? 0xFF55FF55 : 0xFFFF5555, false);
        }
        List<String> blockers = new java.util.ArrayList<>();
        for (Parts.Part o : Parts.ALL) if (inst.contains(o.id()) && java.util.Arrays.asList(o.deps()).contains(p.id())) blockers.add(o.name());
        if (!blockers.isEmpty()) g.drawString(font, "Blocat de: " + String.join(", ", blockers), px + 212, py + 140, 0xFFFF8A3D, false);
        g.drawString(font, "Plata o face clientul din apropiere (80% pentru tine).", px + 212, py + 170, 0xFF666666, false);
    }
}
