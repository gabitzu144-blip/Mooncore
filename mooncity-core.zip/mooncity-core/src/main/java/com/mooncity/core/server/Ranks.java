package com.mooncity.core.server;

import com.mooncity.core.data.Account;
import com.mooncity.core.data.MoonData;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.scores.PlayerTeam;
import net.minecraft.world.scores.Scoreboard;

/** Grade afisate deasupra capului (prin echipe de scoreboard: merge in nametag, tab si chat). */
public class Ranks {
    public static ChatFormatting color(String c) {
        return switch (c.toLowerCase()) {
            case "galben", "yellow" -> ChatFormatting.YELLOW;
            case "rosu", "roșu", "red" -> ChatFormatting.RED;
            case "verde", "green" -> ChatFormatting.GREEN;
            case "verdeinchis" -> ChatFormatting.DARK_GREEN;
            case "albastru", "blue" -> ChatFormatting.BLUE;
            case "bleu", "cyan", "turcoaz", "aqua" -> ChatFormatting.AQUA;
            case "mov", "purple" -> ChatFormatting.DARK_PURPLE;
            case "roz", "pink" -> ChatFormatting.LIGHT_PURPLE;
            case "portocaliu", "orange" -> ChatFormatting.GOLD;
            case "negru", "black" -> ChatFormatting.BLACK;
            case "gri", "gray" -> ChatFormatting.GRAY;
            default -> ChatFormatting.WHITE;
        };
    }

    public static void apply(ServerPlayer p) {
        Account a = MoonData.get(p.getServer()).acc(p);
        Scoreboard sb = p.getServer().getScoreboard();
        String name = p.getScoreboardName();
        PlayerTeam cur = sb.getPlayersTeam(name);
        if (cur != null && cur.getName().startsWith("mcr")) sb.removePlayerFromTeam(name, cur);
        if (a.rankLabel.isEmpty()) return;
        ChatFormatting cf = color(a.rankColor);
        String tn = "mcr" + Integer.toHexString((a.rankLabel.toLowerCase() + cf.getName()).hashCode());
        PlayerTeam t = sb.getPlayerTeam(tn);
        if (t == null) t = sb.addPlayerTeam(tn);
        t.setColor(cf);
        t.setPlayerPrefix(Component.literal(a.rankLabel.toUpperCase() + " | ").withStyle(cf));
        sb.addPlayerToTeam(name, t);
    }
}
