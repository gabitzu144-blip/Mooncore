package com.mooncity.core.server;

public enum Jobs {
    FORGER("forger", "Forger", 6, "Topești minereu în cuptor: iron, gold, copper. Primești lei pentru fiecare lingou."),
    CONSTRUCTOR("constructor", "Constructor", 2, "Pui blocuri de construcție (cărămidă, piatră, scânduri). Plată pentru fiecare bloc."),
    WELDER("sudor", "Sudor", 15, "Fabrici piese de metal: gard, ușă de fier, șină, nicovală, găleată, foarfecă."),
    COURIER("curier", "Curier", 80, "Duci pachete la adresa marcată. Distanța mare = bani mai mulți. Țintă pe HUD."),
    GARBAGE("gunoier", "Gunoier", 3, "Aduni gunoiul de pe jos: carne stricată, oase, ață, bețe, hârtie."),
    TRUCKER("tirist", "Tirist", 150, "Cursă lungă DOAR cu vehicul. Cu cât drumul e mai lung, cu atât câștigi mai mult."),
    FARMER("fermier", "Fermier", 4, "Recoltezi culturi coapte (grâu, morcovi, cartofi, sfeclă)."),
    FORESTER("padurar", "Pădurar", 5, "Tai copaci: plată pentru fiecare buștean."),
    GARDENER("gradinar", "Grădinar", 6, "Plantezi puieți și flori."),
    BEEKEEPER("apicultor", "Apicultor", 25, "Colectezi miere/faguri din stupi plini (foarfecă sau sticlă goală).");

    public final String key, label, desc;
    public final int pay;

    Jobs(String key, String label, int pay, String desc) {
        this.key = key; this.label = label; this.pay = pay; this.desc = desc;
    }

    public static Jobs byKey(String k) {
        for (Jobs j : values()) if (j.key.equals(k)) return j;
        return null;
    }
}
