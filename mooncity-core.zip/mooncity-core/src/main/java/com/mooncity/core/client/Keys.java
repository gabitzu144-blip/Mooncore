package com.mooncity.core.client;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;

public class Keys {
    public static final String CAT = "key.categories.mooncity";
    public static final KeyMapping MENU = new KeyMapping("key.mooncity.menu", InputConstants.KEY_K, CAT);
    public static final KeyMapping GARAGE = new KeyMapping("key.mooncity.garage", InputConstants.KEY_O, CAT);
    public static final KeyMapping TRUNK = new KeyMapping("key.mooncity.trunk", InputConstants.KEY_G, CAT);
    public static final KeyMapping PHONE = new KeyMapping("key.mooncity.phone", InputConstants.KEY_P, CAT);
    public static final KeyMapping MECH = new KeyMapping("key.mooncity.interact", InputConstants.KEY_I, CAT);
    public static final KeyMapping MAP = new KeyMapping("key.mooncity.map", InputConstants.KEY_M, CAT);
    public static final KeyMapping JOB = new KeyMapping("key.mooncity.job", InputConstants.KEY_J, CAT);
}
