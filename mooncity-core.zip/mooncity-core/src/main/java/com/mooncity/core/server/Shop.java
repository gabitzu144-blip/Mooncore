package com.mooncity.core.server;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.alchemy.PotionUtils;
import net.minecraft.world.item.alchemy.Potions;

import java.util.List;
import java.util.function.Supplier;

public class Shop {
    public record Entry(String name, int price, Supplier<ItemStack> stack) {}

    public static final List<Entry> ITEMS = List.of(
        new Entry("Pâine", 5, () -> new ItemStack(Items.BREAD)),
        new Entry("Măr", 3, () -> new ItemStack(Items.APPLE)),
        new Entry("Friptură", 12, () -> new ItemStack(Items.COOKED_BEEF)),
        new Entry("Cartof copt", 4, () -> new ItemStack(Items.BAKED_POTATO)),
        new Entry("Apă", 4, () -> PotionUtils.setPotion(new ItemStack(Items.POTION), Potions.WATER)),
        new Entry("Biscuiți", 2, () -> new ItemStack(Items.COOKIE)),
        new Entry("Morcov auriu", 20, () -> new ItemStack(Items.GOLDEN_CARROT)),
        new Entry("Bidon gol (sticlă)", 3, () -> new ItemStack(Items.GLASS_BOTTLE))
    );

    public static final double FUEL_PRICE_PER_UNIT = 0.5; // lei / unitate de benzina
}
