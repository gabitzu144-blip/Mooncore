package com.mooncity.core.server;

import com.mooncity.core.block.ModBlocks;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.alchemy.PotionUtils;
import net.minecraft.world.item.alchemy.Potions;

import java.util.List;
import java.util.function.Supplier;

public class Shop {
    public record Entry(String name, int price, Supplier<ItemStack> stack) {}
    public record Store(String name, List<Entry> items) {}

    private static ItemStack water() { return PotionUtils.setPotion(new ItemStack(Items.POTION), Potions.WATER); }

    public static final List<Store> STORES = List.of(
        new Store("Magazin 24/7", List.of(
            new Entry("Pâine", 5, () -> new ItemStack(Items.BREAD)),
            new Entry("Măr", 3, () -> new ItemStack(Items.APPLE)),
            new Entry("Friptură", 12, () -> new ItemStack(Items.COOKED_BEEF)),
            new Entry("Cartof copt", 4, () -> new ItemStack(Items.BAKED_POTATO)),
            new Entry("Apă", 4, Shop::water),
            new Entry("Biscuiți", 2, () -> new ItemStack(Items.COOKIE)),
            new Entry("Lapte", 6, () -> new ItemStack(Items.MILK_BUCKET)))),
        new Store("Haine", List.of(
            new Entry("Cască piele", 40, () -> new ItemStack(Items.LEATHER_HELMET)),
            new Entry("Jachetă piele", 90, () -> new ItemStack(Items.LEATHER_CHESTPLATE)),
            new Entry("Pantaloni piele", 70, () -> new ItemStack(Items.LEATHER_LEGGINGS)),
            new Entry("Bocanci piele", 50, () -> new ItemStack(Items.LEATHER_BOOTS)),
            new Entry("Vopsea albastră", 10, () -> new ItemStack(Items.BLUE_DYE)),
            new Entry("Vopsea roșie", 10, () -> new ItemStack(Items.RED_DYE)))),
        new Store("Unelte", List.of(
            new Entry("Târnăcop", 120, () -> new ItemStack(Items.IRON_PICKAXE)),
            new Entry("Topor", 100, () -> new ItemStack(Items.IRON_AXE)),
            new Entry("Lopată", 80, () -> new ItemStack(Items.IRON_SHOVEL)),
            new Entry("Sapă", 70, () -> new ItemStack(Items.IRON_HOE)),
            new Entry("Foarfecă", 60, () -> new ItemStack(Items.SHEARS)),
            new Entry("Găleată", 40, () -> new ItemStack(Items.BUCKET)),
            new Entry("Undiță", 50, () -> new ItemStack(Items.FISHING_ROD)))),
        new Store("Electronice", List.of(
            new Entry("Boxă portabilă JBL", 450, () -> new ItemStack(ModBlocks.SPEAKER_ITEM.get())),
            new Entry("Busolă", 80, () -> new ItemStack(Items.COMPASS)),
            new Entry("Ceas", 60, () -> new ItemStack(Items.CLOCK)),
            new Entry("Lunetă", 120, () -> new ItemStack(Items.SPYGLASS)))),
        new Store("Farmacie", List.of(
            new Entry("Trusă medicală", 150, () -> new ItemStack(Items.GOLDEN_APPLE)),
            new Entry("Calmant (regenerare)", 60, () -> PotionUtils.setPotion(new ItemStack(Items.POTION), Potions.REGENERATION)),
            new Entry("Apă", 4, Shop::water)))
    );

    public static final double FUEL_PRICE_PER_UNIT = 0.5;
}
