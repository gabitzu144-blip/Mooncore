package com.mooncity.core;

import com.mooncity.core.entity.ModEntities;
import com.mooncity.core.net.Net;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(MoonCity.MODID)
public class MoonCity {
    public static final String MODID = "mooncity";

    public MoonCity() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModEntities.ENTITIES.register(bus);
        com.mooncity.core.block.ModBlocks.BLOCKS.register(bus);
        com.mooncity.core.block.ModBlocks.ITEMS.register(bus);
        com.mooncity.core.block.ModBlocks.BLOCK_ENTITIES.register(bus);
        bus.addListener(this::setup);
    }

    private void setup(FMLCommonSetupEvent e) {
        e.enqueueWork(Net::init);
    }
}
