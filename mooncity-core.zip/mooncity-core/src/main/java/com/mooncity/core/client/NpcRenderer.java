package com.mooncity.core.client;

import com.mooncity.core.MoonCity;
import com.mooncity.core.entity.NpcEntity;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.resources.ResourceLocation;

public class NpcRenderer extends HumanoidMobRenderer<NpcEntity, HumanoidModel<NpcEntity>> {
    private static final ResourceLocation[] TEX = {
        new ResourceLocation(MoonCity.MODID, "textures/entity/npc_banker.png"),
        new ResourceLocation(MoonCity.MODID, "textures/entity/npc_shop.png"),
        new ResourceLocation(MoonCity.MODID, "textures/entity/npc_fuel.png")
    };

    public NpcRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new HumanoidModel<>(ctx.bakeLayer(ModelLayers.PLAYER)), 0.5f);
    }

    @Override
    public ResourceLocation getTextureLocation(NpcEntity e) {
        return TEX[Math.floorMod(e.getVariant(), TEX.length)];
    }
}
