package com.mooncity.core.net;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class AnnouncePacket {
    public final String text;
    public AnnouncePacket(String text) { this.text = text; }
    public void encode(FriendlyByteBuf b) { b.writeUtf(text, 300); }
    public static AnnouncePacket decode(FriendlyByteBuf b) { return new AnnouncePacket(b.readUtf(300)); }
    public static void handle(AnnouncePacket m, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> { ClientState.announce = m.text; ClientState.announceUntil = System.currentTimeMillis() + 9000; });
        ctx.get().setPacketHandled(true);
    }
}
