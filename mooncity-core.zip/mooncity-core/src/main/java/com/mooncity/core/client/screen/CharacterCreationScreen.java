package com.mooncity.core.client.screen;

import com.mooncity.core.net.ActionPacket;
import com.mooncity.core.net.Net;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.network.chat.Component;

public class CharacterCreationScreen extends MoonScreen {
    private EditBox first, last, age;
    private boolean female = false;
    private String f = "", l = "", a = "18";

    public CharacterCreationScreen() { super("CREARE PERSONAJ"); pw = 280; ph = 210; }

    @Override public boolean shouldCloseOnEsc() { return false; }

    @Override
    protected void build() {
        first = new EditBox(font, px + 14, py + 40, pw - 28, 18, Component.literal("Prenume"));
        first.setHint(Component.literal("Prenume")); first.setMaxLength(16); first.setValue(f); addRenderableWidget(first);
        last = new EditBox(font, px + 14, py + 64, pw - 28, 18, Component.literal("Nume"));
        last.setHint(Component.literal("Nume")); last.setMaxLength(16); last.setValue(l); addRenderableWidget(last);
        age = new EditBox(font, px + 14, py + 88, 60, 18, Component.literal("Vârstă"));
        age.setHint(Component.literal("Vârstă")); age.setMaxLength(2); age.setFilter(s -> s.matches("\\d*")); age.setValue(a); addRenderableWidget(age);
        btn("Sex: " + (female ? "Feminin" : "Masculin"), px + 84, py + 88, pw - 98, bt -> { save(); female = !female; rebuildWidgets(); });
        btn("CREATE", px + 14, py + 130, pw - 28, bt -> {
            save();
            if (f.isBlank() || l.isBlank()) return;
            Net.CH.sendToServer(new ActionPacket(ActionPacket.CREATE_CHAR, 0, 0, f + "|" + l + "|" + a + "|" + (female ? "F" : "M")));
            minecraft.setScreen(null);
        });
    }

    private void save() { if (first != null) { f = first.getValue(); l = last.getValue(); a = age.getValue(); } }

    @Override protected void draw(GuiGraphics g, int mx, int my) {
        g.drawString(font, "Bine ai venit în MoonCity! Alege-ți identitatea.", px + 14, py + 24, 0xFFAAAAAA, false);
        g.drawString(font, "Poți schimba aspectul (skin) din launcher.", px + 14, py + 176, 0xFF666666, false);
    }
}
