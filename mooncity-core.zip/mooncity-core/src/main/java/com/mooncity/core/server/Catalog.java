package com.mooncity.core.server;

import java.util.ArrayList;
import java.util.List;

/** Catalogul dealerului (vehicule din MrCrayfish's Vehicle). Statisticile sunt estimative. */
public class Catalog {
    public record Model(String key, String label, String cls, int price, int speed, int handling, int brake, int accel) {}

    public static final String[] CLASSES = {"Sport", "A", "B", "Motoare", "Acvatice"};

    public static final List<Model> MODELS = new ArrayList<>(List.of(
        new Model("go_kart", "Go Kart", "Sport", 4500, 55, 90, 60, 70),
        new Model("dune_buggy", "Dune Buggy", "Sport", 14000, 70, 75, 55, 75),
        new Model("off_roader", "Off Roader", "Sport", 22000, 75, 60, 60, 70),
        new Model("atv", "ATV", "Sport", 9000, 60, 70, 55, 65),
        new Model("sports_plane", "Avion sport", "Sport", 85000, 95, 50, 40, 60),
        new Model("compact_helicopter", "Elicopter compact", "Sport", 120000, 85, 55, 40, 55),
        new Model("smart_car", "Smart Car", "A", 12000, 55, 70, 65, 55),
        new Model("mini_bus", "Mini Bus", "A", 30000, 50, 40, 50, 40),
        new Model("golf_cart", "Golf Cart", "A", 4000, 30, 65, 60, 40),
        new Model("tractor", "Tractor", "A", 18000, 25, 40, 55, 30),
        new Model("lawn_mower", "Tuns iarbă", "B", 1800, 20, 60, 50, 30),
        new Model("bumper_car", "Mașinuță", "B", 1500, 25, 70, 60, 35),
        new Model("shopping_cart", "Cărucior", "B", 300, 15, 50, 50, 20),
        new Model("couch", "Canapea", "B", 600, 20, 40, 40, 25),
        new Model("bath", "Cadă", "B", 900, 20, 35, 40, 25),
        new Model("sofacopter", "Sofacopter", "B", 40000, 60, 45, 40, 45),
        new Model("mini_bike", "Mini Bike", "Motoare", 2500, 45, 75, 55, 55),
        new Model("moped", "Moped", "Motoare", 2000, 40, 75, 55, 50),
        new Model("dirt_bike", "Dirt Bike", "Motoare", 5500, 65, 80, 55, 70),
        new Model("quad_bike", "Quad", "Motoare", 7000, 60, 70, 55, 65),
        new Model("aluminum_boat", "Barcă aluminiu", "Acvatice", 7000, 40, 60, 45, 45),
        new Model("jet_ski", "Jet Ski", "Acvatice", 11000, 70, 75, 45, 70),
        new Model("speed_boat", "Speed Boat", "Acvatice", 20000, 80, 65, 45, 70)
    ));

    public static Model get(int i) { return i >= 0 && i < MODELS.size() ? MODELS.get(i) : null; }

    public static List<Integer> ofClass(String cls) {
        List<Integer> r = new ArrayList<>();
        for (int i = 0; i < MODELS.size(); i++) if (MODELS.get(i).cls().equals(cls)) r.add(i);
        return r;
    }
}
