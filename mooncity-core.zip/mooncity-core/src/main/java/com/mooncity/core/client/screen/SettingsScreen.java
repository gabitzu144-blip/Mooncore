package com.mooncity.core.client.screen;

import com.mooncity.core.net.ClientState;
import net.minecraft.client.gui.components.Button;
import net.minecraft.network.chat.Component;

public class SettingsScreen extends MoonScreen {
    public SettingsScreen() { super("SETĂRI"); pw = 240; ph = 150; }

    @Override
    protected void build() {
        Button[] mini = new Button[1], quest = new Button[1];
        mini[0] = btn("Minimap: " + (ClientState.showMinimap ? "ON" : "OFF"), px + 20, py + 34, pw - 40, b -> {
            ClientState.showMinimap = !ClientState.showMinimap;
            mini[0].setMessage(Component.literal("Minimap: " + (ClientState.showMinimap ? "ON" : "OFF")));
        });
        quest[0] = btn("Panou misiuni: " + (ClientState.showQuest ? "ON" : "OFF"), px + 20, py + 60, pw - 40, b -> {
            ClientState.showQuest = !ClientState.showQuest;
            quest[0].setMessage(Component.literal("Panou misiuni: " + (ClientState.showQuest ? "ON" : "OFF")));
        });
        btn("Închide", px + 20, py + 110, pw - 40, b -> onClose());
    }
}
