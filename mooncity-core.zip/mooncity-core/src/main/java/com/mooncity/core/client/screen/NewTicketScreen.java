package com.mooncity.core.client.screen;

import com.mooncity.core.net.ActionPacket;
import com.mooncity.core.net.Net;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.network.chat.Component;

public class NewTicketScreen extends MoonScreen {
    private static final String[] CATS = {"INTREBARE", "RAPORT", "BUG"};
    private int cat = 0;
    private EditBox text;

    public NewTicketScreen() { super("TICKET NOU — Întrebare / Problemă"); pw = 360; ph = 160; }

    @Override
    protected void build() {
        for (int i = 0; i < 3; i++) {
            final int fi = i;
            btn((cat == i ? "► " : "") + CATS[i], px + 10 + i * 116, py + 26, 112, b -> { cat = fi; rebuildWidgets(); });
        }
        text = new EditBox(font, px + 10, py + 54, pw - 20, 20, Component.literal("Descriere"));
        text.setMaxLength(400);
        text.setHint(Component.literal("Descrie problema în detaliu..."));
        addRenderableWidget(text);
        btn("TRIMITE TICKET", px + 10, py + 100, pw - 20, b -> {
            if (text.getValue().isBlank()) return;
            Net.CH.sendToServer(new ActionPacket(ActionPacket.T_CREATE, 0, 0, CATS[cat] + "|" + text.getValue()));
            minecraft.setScreen(new TicketsScreen());
        });
        btn("Anulează cererea", px + 10, py + 126, pw - 20, b -> onClose());
    }

    @Override protected void draw(GuiGraphics g, int mx, int my) { g.drawString(font, "Maxim 400 caractere.", px + 10, py + 80, 0xFF888888, false); }
}
