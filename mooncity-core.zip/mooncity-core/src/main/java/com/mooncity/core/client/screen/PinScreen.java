package com.mooncity.core.client.screen;

import com.mooncity.core.net.ActionPacket;
import com.mooncity.core.net.ClientState;
import com.mooncity.core.net.Net;
import net.minecraft.client.gui.GuiGraphics;

/** Tastatura PIN a ATM-ului (4 cifre). Daca nu ai PIN, il setezi acum. */
public class PinScreen extends MoonScreen {
    private String pin = "";

    public PinScreen() { super("MOONCITY BANKING"); pw = 200; ph = 220; }

    private void press(int d) { if (pin.length() < 4) pin += d; }

    @Override
    protected void build() {
        int[] keys = {1, 2, 3, 4, 5, 6, 7, 8, 9};
        for (int i = 0; i < 9; i++) {
            final int k = keys[i];
            btn(String.valueOf(k), px + 30 + (i % 3) * 46, py + 62 + (i / 3) * 24, 42, b -> press(k));
        }
        btn("C", px + 30, py + 134, 42, b -> pin = "");
        btn("0", px + 76, py + 134, 42, b -> press(0));
        btn("OK", px + 122, py + 134, 42, b -> {
            if (pin.length() != 4) return;
            Net.CH.sendToServer(new ActionPacket(ClientState.hasPin ? ActionPacket.PIN_CHECK : ActionPacket.PIN_SET, 0, 0, pin));
            pin = "";
        });
        btn("Anulează", px + 30, py + 166, 134, b -> onClose());
    }

    @Override
    protected void draw(GuiGraphics g, int mx, int my) {
        g.drawCenteredString(font, ClientState.hasPin ? "INTRODU CODUL PIN" : "SETEAZĂ UN PIN (4 cifre)", px + pw / 2, py + 26, 0xFFFFFFFF);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 4; i++) sb.append(i < pin.length() ? "● " : "○ ");
        g.drawCenteredString(font, sb.toString(), px + pw / 2, py + 42, 0xFFF5C518);
    }

    @Override
    public boolean keyPressed(int key, int sc, int mod) {
        if (key >= 48 && key <= 57) { press(key - 48); return true; }
        if (key == 259 && !pin.isEmpty()) { pin = pin.substring(0, pin.length() - 1); return true; }
        return super.keyPressed(key, sc, mod);
    }
}
