package com.mooncity.core.client.screen;

import com.mooncity.core.data.Poi;
import com.mooncity.core.net.ClientState;

import java.util.ArrayList;
import java.util.List;

public class NavigatorScreen extends ListScreen {
    private final String filter;

    public NavigatorScreen(String filter) {
        super(filter == null ? "NAVIGATOR" : "MAGAZINE", "GPS");
        this.filter = filter;
    }

    private List<Poi> pois() {
        List<Poi> l = new ArrayList<>();
        for (Poi p : ClientState.pois) if (filter == null || p.type().equals(filter)) l.add(p);
        return l;
    }

    @Override protected List<String> rows() {
        List<String> r = new ArrayList<>();
        double px = minecraft == null || minecraft.player == null ? 0 : minecraft.player.getX();
        double pz = minecraft == null || minecraft.player == null ? 0 : minecraft.player.getZ();
        for (Poi p : pois()) r.add("[" + p.type() + "] " + p.name() + "  (" + (int) Math.sqrt((p.x() - px) * (p.x() - px) + (p.z() - pz) * (p.z() - pz)) + " m)");
        return r;
    }

    @Override protected void onAction(int row, int action) {
        Poi p = pois().get(row);
        ClientState.hasWp = true; ClientState.wpX = p.x(); ClientState.wpZ = p.z(); ClientState.wpName = p.name();
        onClose();
    }

    @Override protected void extra() {
        btn("Oprește GPS", px + 62, py + ph - 26, 90, b -> ClientState.hasWp = false);
    }
}
