package com.mooncity.core.client.screen;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.ReceivingLevelScreen;
import net.minecraft.util.Mth;

/** Ecran de incarcare MoonCity (inlocuieste "Loading terrain"). */
public class MoonLoadingScreen extends ReceivingLevelScreen {
    private static final String[] TIPS = {
        "Nu știi unde să mergi? Apasă K și deschide Harta.",
        "Cel mai simplu mod de a face primii bani: joburile din meniul K.",
        "Garajul se deschide cu O, portbagajul cu G.",
        "Banii din portofel sunt în pericol — depune-i la bancher.",
        "Alimentează vehiculul la benzinar înainte de o cursă lungă."
    };
    private final long start = System.currentTimeMillis();

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        int w = this.width, h = this.height;
        g.fillGradient(0, 0, w, h, 0xFF0B0F24, 0xFF2A1B3D);
        long el = System.currentTimeMillis() - start;
        g.drawCenteredString(this.font, "MOONCITY", w / 2, h / 2 - 40, 0xFFF5C518);
        g.drawCenteredString(this.font, "Se încarcă lumea...", w / 2, h / 2 - 24, 0xFFCCCCCC);
        int bw = 220, bx = w / 2 - bw / 2, by = h / 2 - 6;
        float prog = Mth.clamp(1f - (float) Math.exp(-el / 2500.0), 0f, 0.97f);
        g.fill(bx, by, bx + bw, by + 6, 0xFF222844);
        g.fill(bx, by, bx + (int) (bw * prog), by + 6, 0xFFF5C518);
        g.drawCenteredString(this.font, (int) (prog * 100) + "%", w / 2, by + 10, 0xFFFFFFFF);
        String tip = TIPS[(int) ((el / 3500) % TIPS.length)];
        g.drawCenteredString(this.font, "SFAT: " + tip, w / 2, h - 40, 0xFFAAAAAA);
    }
}
