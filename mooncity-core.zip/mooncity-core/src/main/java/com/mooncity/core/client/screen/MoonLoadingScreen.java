package com.mooncity.core.client.screen;

import com.mooncity.core.client.HudRenderer;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.ReceivingLevelScreen;
import net.minecraft.util.Mth;

/** Ecran de incarcare MoonCity cu mai multe slide-uri (inlocuieste "Loading terrain"). */
public class MoonLoadingScreen extends ReceivingLevelScreen {
    private record Slide(String title, String sub, int top, int bottom) {}

    private static final Slide[] SLIDES = {
        new Slide("BINE AI VENIT ÎN MOONCITY", "Un oraș. Mii de povești. A ta începe acum.", 0xFF0B0F24, 0xFF2A1B3D),
        new Slide("JOBURI ȘI ECONOMIE", "Forger, sudor, curier, tirist, mecanic... urcă în nivel și câștigi mai mult.", 0xFF0B2420, 0xFF14532D),
        new Slide("VEHICULE ȘI GARAJ", "Cumperi de la dealer, alimentezi la benzinărie, parchezi în garaj (O).", 0xFF241B0B, 0xFF7C4A03),
        new Slide("BANCĂ ȘI TELEFON", "Card, ATM, transferuri, licitații și loto — totul din telefon (P).", 0xFF0B1B2A, 0xFF1D4ED8),
        new Slide("REGULAMENT ȘI SUPORT", "Ai o problemă? Deschide un ticket din meniul K sau cu /ticket.", 0xFF2A0B1B, 0xFF9F1239)
    };
    private static final String[] TIPS = {
        "Apasă K pentru meniul circular.", "Apasă M pentru hartă și GPS.",
        "Garajul se deschide cu O, portbagajul cu G.", "Depune banii pe card la ATM — cash-ul se poate pierde.",
        "Shift + click dreapta pe un jucător = meniu de interacțiune."
    };
    private final long start = System.currentTimeMillis();

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        long el = System.currentTimeMillis() - start;
        int idx = (int) ((el / 4500) % SLIDES.length);
        Slide s = SLIDES[idx];
        g.fillGradient(0, 0, width, height, s.top(), s.bottom());
        int lw = 64, lh = 74;
        g.blit(HudRenderer.LOGO, width / 2 - lw / 2, height / 2 - 120, lw, lh, 0f, 0f, 128, 147, 128, 147);
        g.drawCenteredString(font, s.title(), width / 2, height / 2 - 36, 0xFFF5C518);
        g.drawCenteredString(font, s.sub(), width / 2, height / 2 - 20, 0xFFDDDDDD);
        for (int i = 0; i < SLIDES.length; i++)
            g.fill(width / 2 - 30 + i * 14, height / 2 - 4, width / 2 - 30 + i * 14 + 10, height / 2, i == idx ? 0xFFF5C518 : 0x66FFFFFF);
        int bw = 240, bx = width / 2 - bw / 2, by = height / 2 + 14;
        float prog = Mth.clamp(1f - (float) Math.exp(-el / 2500.0), 0f, 0.97f);
        g.fill(bx, by, bx + bw, by + 6, 0xFF222844);
        g.fill(bx, by, bx + (int) (bw * prog), by + 6, 0xFFF5C518);
        g.drawCenteredString(font, "Se încarcă lumea... " + (int) (prog * 100) + "%", width / 2, by + 12, 0xFFFFFFFF);
        g.drawCenteredString(font, "SFAT: " + TIPS[(int) ((el / 3500) % TIPS.length)], width / 2, height - 36, 0xFFAAAAAA);
    }
}
