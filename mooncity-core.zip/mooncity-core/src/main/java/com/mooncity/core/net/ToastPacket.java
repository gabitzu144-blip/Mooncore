package com.mooncity.core.net;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class ToastPacket {
    public final String text;
    public final boolean good;

    public ToastPacket(String text, boolean good) { this.text = text; this.good = good; }
    public void encode(FriendlyByteBuf b) { b.writeUtf(text, 256); b.writeBoolean(good); }
    public static ToastPacket decode(FriendlyByteBuf b) { return new ToastPacket(b.readUtf(256), b.readBoolean()); }

    public static void handle(ToastPacket m, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ClientState.toast = m.text;
            ClientState.toastGood = m.good;
            ClientState.toastUntil = System.currentTimeMillis() + 4000;
        });
        ctx.get().setPacketHandled(true);
    }
}
