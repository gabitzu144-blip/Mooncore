package com.mooncity.core.client.screen;

import com.mooncity.core.net.ActionPacket;
import com.mooncity.core.net.ClientState;
import com.mooncity.core.net.Net;

import java.util.ArrayList;
import java.util.List;

/** Doar owner: alege un jucator (online sau care a mai intrat) si ii dai/retragi accesul STAFF. */
public class AdminScreen extends ListScreen {
    private boolean onlineOnly = false;

    public AdminScreen() { super("ADMIN — ACCES STAFF", "Comută"); perPage = 6; }

    private List<String[]> parsed() {
        List<String[]> l = new ArrayList<>();
        for (String s : ClientState.list(7)) {
            String[] p = s.split("\\|");
            if (p.length >= 4 && (!onlineOnly || p[3].equals("1"))) l.add(p);
        }
        return l;
    }

    @Override protected List<String> rows() {
        List<String> r = new ArrayList<>();
        for (String[] p : parsed()) r.add("#" + p[0] + "  " + p[1] + "   " + (p[3].equals("1") ? "[ONLINE]" : "[offline]") + "   " + (p[2].equals("1") ? "★ STAFF" : "jucător"));
        return r;
    }

    @Override protected void refresh() { Net.CH.sendToServer(new ActionPacket(ActionPacket.REQ, 7, 0)); }

    @Override protected void onAction(int row, int action) {
        String[] p = parsed().get(row);
        Net.CH.sendToServer(new ActionPacket(ActionPacket.ADMIN_SET, Integer.parseInt(p[0]), p[2].equals("1") ? 0 : 1));
    }

    @Override protected void extra() {
        btn(onlineOnly ? "Arată toți" : "Doar online", px + 62, py + ph - 26, 90, b -> { onlineOnly = !onlineOnly; page = 0; rebuildWidgets(); });
    }
}
