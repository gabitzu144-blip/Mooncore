package com.mooncity.core.net;

import com.mooncity.core.client.ClientHooks;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** op 0 = porneste, 1 = opreste */
public class SpeakerSoundPacket {
    public final BlockPos pos; public final int op, track; public final float vol;
    public SpeakerSoundPacket(BlockPos pos, int op, int track, float vol) { this.pos = pos; this.op = op; this.track = track; this.vol = vol; }
    public void encode(FriendlyByteBuf b) { b.writeBlockPos(pos); b.writeInt(op); b.writeInt(track); b.writeFloat(vol); }
    public static SpeakerSoundPacket decode(FriendlyByteBuf b) { return new SpeakerSoundPacket(b.readBlockPos(), b.readInt(), b.readInt(), b.readFloat()); }
    public static void handle(SpeakerSoundPacket m, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientHooks.speakerSound(m.pos, m.op, m.track, m.vol)));
        ctx.get().setPacketHandled(true);
    }
}
