package com.mooncity.core.client.screen;

import com.mooncity.core.net.ActionPacket;
import com.mooncity.core.net.ClientState;
import com.mooncity.core.net.Net;
import com.mooncity.core.server.Jobs;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import net.minecraft.util.FormattedCharSequence;

import java.util.List;

public class JobsScreen extends MoonScreen {
    private int selected = 0;

    public JobsScreen() { super("JOBURI"); pw = 300; ph = 250; }

    @Override
    protected void build() {
        Jobs[] all = Jobs.values();
        int w = 138;
        for (int i = 0; i < all.length; i++) {
            final int idx = i;
            int x = px + 10 + (i % 2) * (w + 4);
            int y = py + 24 + (i / 2) * 22;
            btn(all[i].label, x, y, w, b -> selected = idx);
        }
        btn("Începe tura", px + 10, py + ph - 30, 100, b -> Net.CH.sendToServer(new ActionPacket(ActionPacket.JOB_START, selected, 0)));
        btn("Renunță", px + 114, py + ph - 30, 80, b -> Net.CH.sendToServer(new ActionPacket(ActionPacket.JOB_QUIT, 0, 0)));
        btn("Închide", px + pw - 90, py + ph - 30, 80, b -> onClose());
    }

    @Override
    protected void draw(GuiGraphics g, int mx, int my) {
        Jobs j = Jobs.values()[selected];
        int y = py + 24 + 5 * 22 + 6;
        g.drawString(font, j.label + "  —  " + j.pay + " lei / acțiune", px + 10, y, 0xFFF5C518, false);
        List<FormattedCharSequence> lines = font.split(Component.literal(j.desc), pw - 20);
        for (int i = 0; i < lines.size(); i++) g.drawString(font, lines.get(i), px + 10, y + 14 + i * 10, 0xFFDDDDDD, false);
        Jobs cur = Jobs.byKey(ClientState.job);
        g.drawString(font, "Job curent: " + (cur == null ? "niciunul" : cur.label), px + 10, py + ph - 46, 0xFF55FF55, false);
    }
}
