package com.mooncity.core.server;

import com.mooncity.core.MoonCity;
import com.mooncity.core.data.MoonData;
import com.mooncity.core.data.Poi;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.BeehiveBlock;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.CropBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.InteractionHand;
import net.minecraftforge.event.entity.player.EntityItemPickupEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.*;

@Mod.EventBusSubscriber(modid = MoonCity.MODID)
public class JobEvents {
    public static final Map<UUID, BlockPos> targets = new HashMap<>();
    public static final Map<UUID, BlockPos> starts = new HashMap<>();
    private static final Random RNG = new Random();

    static Jobs cur(ServerPlayer p) {
        return Jobs.byKey(MoonData.get(p.getServer()).acc(p).job);
    }

    public static void pay(ServerPlayer p, long amt) {
        MoonData d = MoonData.get(p.getServer());
        d.acc(p).cash += amt;
        d.setDirty();
        p.displayClientMessage(Component.literal("+" + amt + " lei"), true);
        Sync.send(p);
    }

    public static void assignTarget(ServerPlayer p, Jobs j) {
        MoonData d = MoonData.get(p.getServer());
        List<Poi> dl = new ArrayList<>();
        for (Poi o : d.pois) if (o.type().equals("delivery")) dl.add(o);
        BlockPos t;
        if (!dl.isEmpty()) {
            Poi o = dl.get(RNG.nextInt(dl.size()));
            t = new BlockPos(o.x(), o.y(), o.z());
        } else {
            double ang = RNG.nextDouble() * Math.PI * 2;
            int dist = j == Jobs.TRUCKER ? 600 + RNG.nextInt(900) : 150 + RNG.nextInt(250);
            t = BlockPos.containing(p.getX() + Math.cos(ang) * dist, p.getY(), p.getZ() + Math.sin(ang) * dist);
        }
        targets.put(p.getUUID(), t);
        starts.put(p.getUUID(), p.blockPosition());
        p.sendSystemMessage(Component.literal("Livrare nouă: X " + t.getX() + "  Z " + t.getZ()));
    }

    /** Verifica livrarile curier/tirist (o data pe secunda). */
    public static void tickDelivery(ServerPlayer p) {
        Jobs j = cur(p);
        if (j != Jobs.COURIER && j != Jobs.TRUCKER) return;
        BlockPos t = targets.get(p.getUUID());
        if (t == null) { assignTarget(p, j); Sync.send(p); return; }
        double dx = p.getX() - t.getX(), dz = p.getZ() - t.getZ();
        if (Math.sqrt(dx * dx + dz * dz) > 6) return;
        if (j == Jobs.TRUCKER && !com.mooncity.core.util.VehicleUtil.isVehicle(p.getVehicle())) {
            p.displayClientMessage(Component.literal("Ca tirist trebuie să fii într-un vehicul!"), true);
            return;
        }
        BlockPos s = starts.getOrDefault(p.getUUID(), t);
        double dist = Math.sqrt(s.distSqr(t));
        long amt = j.pay + Math.round(dist / (j == Jobs.TRUCKER ? 4.0 : 10.0));
        pay(p, amt);
        assignTarget(p, j);
        Sync.send(p);
    }

    @SubscribeEvent
    public static void smelt(PlayerEvent.ItemSmeltedEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p) || cur(p) != Jobs.FORGER) return;
        ItemStack s = e.getSmelting();
        if (s.is(Items.IRON_INGOT) || s.is(Items.GOLD_INGOT) || s.is(Items.COPPER_INGOT))
            pay(p, (long) Jobs.FORGER.pay * s.getCount());
    }

    @SubscribeEvent
    public static void craft(PlayerEvent.ItemCraftedEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p) || cur(p) != Jobs.WELDER) return;
        ItemStack s = e.getCrafting();
        if (s.is(Items.IRON_BARS) || s.is(Items.IRON_DOOR) || s.is(Items.IRON_TRAPDOOR) || s.is(Items.ANVIL)
                || s.is(Items.RAIL) || s.is(Items.BUCKET) || s.is(Items.SHEARS) || s.is(Items.CHAIN))
            pay(p, (long) Jobs.WELDER.pay * s.getCount());
    }

    @SubscribeEvent
    public static void place(BlockEvent.EntityPlaceEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p)) return;
        Jobs j = cur(p);
        BlockState st = e.getPlacedBlock();
        if (j == Jobs.CONSTRUCTOR && (st.is(Blocks.BRICKS) || st.is(BlockTags.STONE_BRICKS) || st.is(Blocks.COBBLESTONE)
                || st.is(Blocks.STONE) || st.is(BlockTags.PLANKS)))
            pay(p, Jobs.CONSTRUCTOR.pay);
        else if (j == Jobs.GARDENER && (st.is(BlockTags.SAPLINGS) || st.is(BlockTags.FLOWERS)))
            pay(p, Jobs.GARDENER.pay);
    }

    @SubscribeEvent
    public static void breakBlock(BlockEvent.BreakEvent e) {
        if (!(e.getPlayer() instanceof ServerPlayer p)) return;
        Jobs j = cur(p);
        BlockState st = e.getState();
        if (j == Jobs.FORESTER && st.is(BlockTags.LOGS)) pay(p, Jobs.FORESTER.pay);
        else if (j == Jobs.FARMER && st.getBlock() instanceof CropBlock c && c.isMaxAge(st)) pay(p, Jobs.FARMER.pay);
    }

    @SubscribeEvent
    public static void pickup(EntityItemPickupEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer p) || cur(p) != Jobs.GARBAGE) return;
        ItemStack s = e.getItem().getItem();
        if (s.is(Items.ROTTEN_FLESH) || s.is(Items.BONE) || s.is(Items.STRING) || s.is(Items.STICK)
                || s.is(Items.PAPER) || s.is(Items.SPIDER_EYE) || s.is(Items.POISONOUS_POTATO))
            pay(p, (long) Jobs.GARBAGE.pay * s.getCount());
    }

    @SubscribeEvent
    public static void hive(PlayerInteractEvent.RightClickBlock e) {
        if (e.getLevel().isClientSide() || e.getHand() != InteractionHand.MAIN_HAND) return;
        if (!(e.getEntity() instanceof ServerPlayer p) || cur(p) != Jobs.BEEKEEPER) return;
        BlockState st = e.getLevel().getBlockState(e.getPos());
        if (!(st.getBlock() instanceof BeehiveBlock)) return;
        ItemStack held = e.getItemStack();
        if (!(held.is(Items.SHEARS) || held.is(Items.GLASS_BOTTLE))) return;
        if (st.getValue(BeehiveBlock.HONEY_LEVEL) >= 5) pay(p, Jobs.BEEKEEPER.pay);
    }
}
