package com.mooncity.core.client.screen;

import com.mooncity.core.net.ActionPacket;
import com.mooncity.core.net.Net;

import java.util.List;

public class AnimationsScreen extends ListScreen {
    private static final List<String> NAMES = List.of("Salută", "Aplaudă", "Dansează", "Se gândește", "Face cu mâna", "Râde");

    public AnimationsScreen() { super("ANIMAȚII", "Fă"); }

    @Override protected List<String> rows() { return NAMES; }
    @Override protected void onAction(int row, int action) { Net.CH.sendToServer(new ActionPacket(ActionPacket.EMOTE, row, 0)); onClose(); }
}
