package com.mooncity.core.client.screen;

import net.minecraft.client.gui.GuiGraphics;

import java.util.List;
import java.util.function.Supplier;

public class InfoScreen extends MoonScreen {
    private final Supplier<List<String>> lines;

    public InfoScreen(String title, Supplier<List<String>> lines) { super(title); this.lines = lines; pw = 280; ph = 200; }

    @Override protected void build() { btn("Închide", px + pw / 2 - 40, py + ph - 28, 80, b -> onClose()); }

    @Override
    protected void draw(GuiGraphics g, int mx, int my) {
        int y = py + 28;
        for (String s : lines.get()) { g.drawString(font, s, px + 14, y, 0xFFFFFFFF, false); y += 13; }
    }
}
