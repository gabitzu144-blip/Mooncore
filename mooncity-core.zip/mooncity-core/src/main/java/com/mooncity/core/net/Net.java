package com.mooncity.core.net;

import com.mooncity.core.MoonCity;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

public class Net {
    private static final String VERSION = "1";
    public static final SimpleChannel CH = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(MoonCity.MODID, "main"), () -> VERSION, VERSION::equals, VERSION::equals);

    public static void init() {
        int i = 0;
        CH.registerMessage(i++, SyncPacket.class, SyncPacket::encode, SyncPacket::decode, SyncPacket::handle);
        CH.registerMessage(i++, OpenScreenPacket.class, OpenScreenPacket::encode, OpenScreenPacket::decode, OpenScreenPacket::handle);
        CH.registerMessage(i++, ListPacket.class, ListPacket::encode, ListPacket::decode, ListPacket::handle);
        CH.registerMessage(i++, ToastPacket.class, ToastPacket::encode, ToastPacket::decode, ToastPacket::handle);
        CH.registerMessage(i++, OpenSpeakerPacket.class, OpenSpeakerPacket::encode, OpenSpeakerPacket::decode, OpenSpeakerPacket::handle);
        CH.registerMessage(i++, SpeakerSoundPacket.class, SpeakerSoundPacket::encode, SpeakerSoundPacket::decode, SpeakerSoundPacket::handle);
        CH.registerMessage(i++, SpeakerActionPacket.class, SpeakerActionPacket::encode, SpeakerActionPacket::decode, SpeakerActionPacket::handle);
        CH.registerMessage(i++, AnnouncePacket.class, AnnouncePacket::encode, AnnouncePacket::decode, AnnouncePacket::handle);
        CH.registerMessage(i++, NeonPacket.class, NeonPacket::encode, NeonPacket::decode, NeonPacket::handle);
        CH.registerMessage(i++, ActionPacket.class, ActionPacket::encode, ActionPacket::decode, ActionPacket::handle);
    }
}
