package com.mooncity.core.client.screen;

import com.mooncity.core.net.ActionPacket;
import com.mooncity.core.net.ClientState;
import com.mooncity.core.net.Net;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.network.chat.Component;

public class PhoneBankScreen extends MoonScreen {
    private EditBox idBox, amtBox;

    public PhoneBankScreen() { super("MOONCITY BANKING"); pw = 280; ph = 190; }

    @Override
    protected void build() {
        idBox = new EditBox(font, px + 12, py + 90, pw - 24, 18, Component.literal("ID"));
        idBox.setHint(Component.literal("ID destinatar"));
        idBox.setFilter(s -> s.matches("\\d*"));
        idBox.setMaxLength(6);
        addRenderableWidget(idBox);
        amtBox = new EditBox(font, px + 12, py + 114, pw - 24, 18, Component.literal("Suma"));
        amtBox.setHint(Component.literal("Suma (lei)"));
        amtBox.setFilter(s -> s.matches("\\d*"));
        amtBox.setMaxLength(8);
        addRenderableWidget(amtBox);
        btn("Transfer", px + 12, py + 142, 100, b -> {
            if (idBox.getValue().isEmpty() || amtBox.getValue().isEmpty()) return;
            Net.CH.sendToServer(new ActionPacket(ActionPacket.TRANSFER, Integer.parseInt(idBox.getValue()), Integer.parseInt(amtBox.getValue())));
        });
        btn("Închide", px + pw - 112, py + 142, 100, b -> onClose());
    }

    @Override
    protected void draw(GuiGraphics g, int mx, int my) {
        g.drawString(font, "Cash: " + ClientState.cash + " lei", px + 12, py + 28, 0xFF55FF55, false);
        g.drawString(font, "Card: " + ClientState.bank + " lei", px + 12, py + 42, 0xFF55AAFF, false);
        g.drawString(font, "Transferul se face de pe card.", px + 12, py + 62, 0xFF888888, false);
        g.drawString(font, "Depunerile/retragerile se fac la ATM sau bancher.", px + 12, py + 74, 0xFF888888, false);
    }
}
