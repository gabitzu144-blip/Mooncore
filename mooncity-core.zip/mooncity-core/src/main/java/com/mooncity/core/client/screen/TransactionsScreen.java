package com.mooncity.core.client.screen;

import com.mooncity.core.net.ActionPacket;
import com.mooncity.core.net.ClientState;
import com.mooncity.core.net.Net;

import java.util.ArrayList;
import java.util.List;

public class TransactionsScreen extends ListScreen {
    public TransactionsScreen() { super("TRANZACȚII"); perPage = 8; }

    @Override protected List<String> rows() {
        List<String> r = new ArrayList<>();
        for (String s : ClientState.list(15)) { String[] p = s.split("\\|", 2); r.add(p[0] + "   " + (p.length > 1 ? p[1] : "")); }
        return r;
    }
    @Override protected void refresh() { Net.CH.sendToServer(new ActionPacket(ActionPacket.REQ, 15, 0)); }
    @Override protected void onAction(int row, int action) { }
}
