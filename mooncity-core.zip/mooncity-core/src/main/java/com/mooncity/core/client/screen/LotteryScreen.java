package com.mooncity.core.client.screen;

import com.mooncity.core.net.ActionPacket;
import com.mooncity.core.net.ClientState;
import com.mooncity.core.net.Net;
import net.minecraft.client.gui.GuiGraphics;

public class LotteryScreen extends MoonScreen {
    public LotteryScreen() { super("LOTO"); pw = 260; ph = 160; }

    @Override
    protected void build() {
        btn("Cumpără bilet (50 lei)", px + 30, py + 90, pw - 60, b -> Net.CH.sendToServer(new ActionPacket(ActionPacket.LOTTERY, 0, 0)));
        btn("Închide", px + 30, py + 120, pw - 60, b -> onClose());
    }

    @Override
    protected void draw(GuiGraphics g, int mx, int my) {
        g.drawString(font, "Cash: " + ClientState.cash + " lei  |  Card: " + ClientState.bank + " lei", px + 12, py + 28, 0xFFFFFFFF, false);
        g.drawString(font, "Premii: 75 / 200 / 1.000 / 10.000 lei", px + 12, py + 46, 0xFFF5C518, false);
        g.drawString(font, "Rezultatul apare jos pe ecran.", px + 12, py + 60, 0xFF888888, false);
    }
}
