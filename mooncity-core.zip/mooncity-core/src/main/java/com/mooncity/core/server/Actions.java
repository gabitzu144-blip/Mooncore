package com.mooncity.core.server;

import com.mooncity.core.block.ModBlocks;
import com.mooncity.core.data.*;
import com.mooncity.core.entity.NpcEntity;
import com.mooncity.core.net.*;
import com.mooncity.core.util.VehicleUtil;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.PacketDistributor;

import java.util.*;

public class Actions {
    private static final Random RNG = new Random();
    static final String[] EMOTES = {"salută", "aplaudă", "dansează", "se gândește", "face cu mâna", "râde"};

    // ---------- helpers ----------
    private static boolean nearNpc(ServerPlayer p, int variant) {
        return !p.serverLevel().getEntitiesOfClass(NpcEntity.class, p.getBoundingBox().inflate(8),
                n -> n.getVariant() == variant).isEmpty();
    }

    private static boolean nearBank(ServerPlayer p) {
        if (nearNpc(p, 0)) return true;
        if (!Extra.pinUnlocked(p)) return false;
        BlockPos c = p.blockPosition();
        for (BlockPos b : BlockPos.betweenClosed(c.offset(-5, -3, -5), c.offset(5, 3, 5)))
            if (p.level().getBlockState(b).is(ModBlocks.ATM.get())) return true;
        return false;
    }

    private static void msg(ServerPlayer p, String s) { p.sendSystemMessage(Component.literal(s)); }

    public static void toast(ServerPlayer p, String s, boolean good) {
        Net.CH.send(PacketDistributor.PLAYER.with(() -> p), new ToastPacket(s, good));
    }

    private static ServerPlayer byId(MinecraftServer s, MoonData d, int id) {
        for (ServerPlayer sp : s.getPlayerList().getPlayers()) if (d.acc(sp).id == id) return sp;
        return null;
    }

    private static Account accById(MoonData d, int id) {
        for (Account a : d.accounts.values()) if (a.id == id) return a;
        return null;
    }

    private static String clean(String s, int max) {
        s = s == null ? "" : s.replaceAll("[\\p{Cntrl}|]", "").trim();
        return s.length() > max ? s.substring(0, max) : s;
    }

    private static void sendList(ServerPlayer p, int kind, List<String> rows) {
        Net.CH.send(PacketDistributor.PLAYER.with(() -> p), new ListPacket(kind, rows));
    }

    // ---------- main ----------
    public static void handle(ServerPlayer p, int type, int a, int b, String s) {
        MoonData d = MoonData.get(p.getServer());
        Account acc = d.acc(p);
        switch (type) {
            case ActionPacket.DEPOSIT -> {
                if (!nearBank(p)) { msg(p, "Trebuie să fii lângă un ATM sau bancher."); break; }
                long amt = a < 0 ? acc.cash : Math.min(a, acc.cash);
                if (amt <= 0) break;
                acc.cash -= amt; acc.bank += amt;
                acc.addTx("Depunere +" + amt);
                Quests.advance(p, 1);
            }
            case ActionPacket.WITHDRAW -> {
                if (!nearBank(p)) { msg(p, "Trebuie să fii lângă un ATM sau bancher."); break; }
                long amt = a < 0 ? acc.bank : Math.min(a, acc.bank);
                if (amt <= 0) break;
                acc.bank -= amt; acc.cash += amt;
                acc.addTx("Retragere -" + amt);
            }
            case ActionPacket.BUY -> {
                if (!nearNpc(p, 1)) { msg(p, "Trebuie să fii lângă vânzător."); break; }
                NpcEntity shopNpc = p.serverLevel().getEntitiesOfClass(NpcEntity.class, p.getBoundingBox().inflate(8),
                        n -> n.getVariant() == 1).get(0);
                Shop.Store store = Shop.STORES.get(Math.floorMod(shopNpc.getSub(), Shop.STORES.size()));
                if (a < 0 || a >= store.items().size()) break;
                int qty = Math.max(1, Math.min(b, 64));
                Shop.Entry e = store.items().get(a);
                long cost = (long) e.price() * qty;
                if (!acc.spend(cost)) { msg(p, "Nu ai destui lei (" + cost + " lei)."); break; }
                for (int i = 0; i < qty; i++) {
                    ItemStack st = e.stack().get();
                    if (!p.getInventory().add(st)) p.drop(st, false);
                }
                toast(p, "Ai cumpărat " + qty + "x " + e.name() + " (-" + cost + " lei)", true);
                Quests.advance(p, 2);
            }
            case ActionPacket.REFUEL -> refuel(p, acc, a);
            case ActionPacket.PARK -> { if (!Extra.zoneOk(d, p, "personal")) { toast(p, "Trebuie să fii într-un garaj (cerc de 10 blocuri).", false); break; } park(p, acc); }
            case ActionPacket.TAKE -> { if (!Extra.zoneOk(d, p, "personal")) { toast(p, "Trebuie să fii într-un garaj (cerc de 10 blocuri).", false); break; } take(p, acc, a); }
            case ActionPacket.TRUNK -> { trunk(p, d); return; }
            case ActionPacket.JOB_START -> {
                if (a < 0 || a >= Jobs.values().length) break;
                Jobs j = Jobs.values()[a];
                acc.job = j.key;
                JobEvents.targets.remove(p.getUUID());
                if (j == Jobs.COURIER || j == Jobs.TRUCKER) JobEvents.assignTarget(p, j);
                toast(p, "Ai început jobul: " + j.label, true);
                Quests.advance(p, 3);
            }
            case ActionPacket.JOB_QUIT -> {
                acc.job = "";
                JobEvents.targets.remove(p.getUUID());
                toast(p, "Ai părăsit jobul.", false);
            }
            case ActionPacket.TRANSFER -> {
                Account t = accById(d, a);
                if (t == null || t == acc) { toast(p, "ID invalid.", false); break; }
                if (b <= 0 || acc.bank < b) { toast(p, "Fonduri insuficiente pe card.", false); break; }
                acc.bank -= b; t.bank += b;
                acc.addTx("Transfer -" + b + " către #" + a); t.addTx("Transfer +" + b + " de la #" + acc.id);
                toast(p, "Ai trimis " + b + " lei către #" + a, true);
                ServerPlayer tp = byId(p.getServer(), d, a);
                if (tp != null) { toast(tp, "Ai primit " + b + " lei de la #" + acc.id, true); Sync.send(tp); }
            }
            case ActionPacket.SEND_MSG -> {
                String text = clean(s, 120);
                ServerPlayer tp = byId(p.getServer(), d, a);
                if (text.isEmpty() || tp == null) { toast(p, "Destinatar offline sau mesaj gol.", false); break; }
                Account t = d.acc(tp);
                t.addInbox("#" + acc.id + " " + acc.displayName(p.getName().getString()) + "|" + text);
                toast(tp, "Mesaj nou de la #" + acc.id, true);
                toast(p, "Mesaj trimis.", true);
            }
            case ActionPacket.CALL -> {
                ServerPlayer tp = byId(p.getServer(), d, a);
                if (tp == null) { toast(p, "Abonatul nu e disponibil.", false); break; }
                toast(tp, "Te sună #" + acc.id + " " + acc.displayName(p.getName().getString()), true);
                msg(tp, "[Telefon] Te sună #" + acc.id + " (" + acc.phone() + ")");
                toast(p, "Se sună #" + a + "...", true);
            }
            case ActionPacket.REQ -> { request(p, d, a, b); return; }
            case ActionPacket.AUC_SELL -> {
                ItemStack held = p.getMainHandItem();
                if (held.isEmpty() || a <= 0) { toast(p, "Ține un obiect în mână și pune un preț.", false); break; }
                int mine = 0;
                for (Auction x : d.auctions) if (x.seller.equals(p.getUUID())) mine++;
                if (mine >= 5) { toast(p, "Maxim 5 anunțuri.", false); break; }
                Auction au = new Auction();
                au.id = d.nextAuctionId++;
                au.seller = p.getUUID();
                au.sellerName = acc.displayName(p.getName().getString());
                au.item = held.save(new CompoundTag());
                au.price = a;
                d.auctions.add(au);
                p.setItemInHand(InteractionHand.MAIN_HAND, ItemStack.EMPTY);
                toast(p, "Anunț publicat.", true);
            }
            case ActionPacket.AUC_BUY -> {
                Auction au = null;
                for (Auction x : d.auctions) if (x.id == a) au = x;
                if (au == null) { toast(p, "Anunțul nu mai există.", false); break; }
                ItemStack st = ItemStack.of(au.item);
                if (au.seller.equals(p.getUUID())) {
                    d.auctions.remove(au);
                    if (!p.getInventory().add(st)) p.drop(st, false);
                    toast(p, "Anunț retras.", true);
                } else if (acc.spend(au.price)) {
                    d.auctions.remove(au);
                    if (!p.getInventory().add(st)) p.drop(st, false);
                    Account sel = d.accounts.get(au.seller);
                    if (sel != null) sel.bank += Math.round(au.price * 0.95);
                    toast(p, "Ai cumpărat " + st.getHoverName().getString() + ".", true);
                    ServerPlayer sp = p.getServer().getPlayerList().getPlayer(au.seller);
                    if (sp != null) { toast(sp, "Ți s-a vândut un obiect (" + Math.round(au.price * 0.95) + " lei pe card)", true); Sync.send(sp); }
                } else toast(p, "Nu ai destui lei.", false);
                request(p, d, 4);
            }
            case ActionPacket.LOTTERY -> {
                if (!acc.spend(50)) { toast(p, "Biletul costă 50 lei.", false); break; }
                int r = RNG.nextInt(100);
                long win = r == 0 ? 10000 : r < 5 ? 1000 : r < 15 ? 200 : r < 40 ? 75 : 0;
                acc.cash += win;
                toast(p, win > 0 ? "Bilet câștigător: +" + win + " lei!" : "Bilet necâștigător.", win > 0);
            }
            case ActionPacket.BONUS -> {
                long day = java.time.LocalDate.now().toEpochDay();
                if (acc.lastBonusDay == day) { toast(p, "Bonusul zilnic a fost deja luat.", false); break; }
                acc.lastBonusDay = day;
                acc.cash += 300;
                toast(p, "Bonus zilnic: +300 lei", true);
            }
            case ActionPacket.DEALER_BUY -> dealerBuy(p, d, acc, a, b);
            case ActionPacket.CREATE_CHAR -> {
                String[] f = (s == null ? "" : s).split("\\|", -1);
                if (f.length < 4) break;
                String fn = clean(f[0], 16), ln = clean(f[1], 16);
                int age;
                try { age = Math.max(16, Math.min(90, Integer.parseInt(f[2].trim()))); } catch (Exception ex) { age = 18; }
                if (fn.isEmpty() || ln.isEmpty()) { toast(p, "Completează numele.", false); break; }
                acc.first = fn; acc.last = ln; acc.age = age;
                acc.sex = f[3].equals("F") ? "F" : "M";
                acc.created = true;
                Net.CH.send(PacketDistributor.PLAYER.with(() -> p), new OpenScreenPacket(11));
            }
            case ActionPacket.SPAWN_CHOICE -> {
                List<Poi> sp = new ArrayList<>();
                for (Poi o : d.pois) if (o.type().equals("spawn")) sp.add(o);
                if (a >= 0 && a < sp.size()) {
                    Poi o = sp.get(a);
                    p.teleportTo(p.serverLevel(), o.x() + 0.5, o.y(), o.z() + 0.5, p.getYRot(), p.getXRot());
                }
            }
            case ActionPacket.EMOTE -> {
                if (a < 0 || a >= EMOTES.length) break;
                p.swing(InteractionHand.MAIN_HAND, true);
                String line = "* " + acc.displayName(p.getName().getString()) + " " + EMOTES[a] + " *";
                for (ServerPlayer o : p.serverLevel().players())
                    if (o.distanceToSqr(p) < 400) msg(o, line);
            }
            case ActionPacket.INV_EQUIP -> {
                if (a < 0 || a >= 36) break;
                ItemStack st = p.getInventory().getItem(a);
                if (st.getItem() instanceof ArmorItem ai) {
                    EquipmentSlot es = ai.getEquipmentSlot();
                    ItemStack old = p.getItemBySlot(es);
                    p.setItemSlot(es, st.copy());
                    p.getInventory().setItem(a, old);
                }
            }
            case ActionPacket.INV_DROP -> {
                if (a < 0 || a >= 36) break;
                ItemStack st = p.getInventory().getItem(a);
                if (!st.isEmpty()) { p.drop(st.copy(), false); p.getInventory().setItem(a, ItemStack.EMPTY); }
            }
            case ActionPacket.T_CREATE -> {
                String[] f = (s == null ? "" : s).split("\\|", 2);
                String text = clean(f.length > 1 ? f[1] : "", 400);
                String cat = f.length > 0 && List.of("INTREBARE", "RAPORT", "BUG").contains(f[0]) ? f[0] : "INTREBARE";
                if (text.isEmpty()) { toast(p, "Descrie problema.", false); break; }
                Ticket t = new Ticket();
                t.id = d.nextTicketId++; t.owner = p.getUUID();
                t.ownerName = acc.displayName(p.getName().getString()); t.category = cat;
                t.add(t.ownerName, text);
                d.tickets.add(t);
                toast(p, "Ticket #" + t.id + " trimis.", true);
                for (ServerPlayer sp : p.getServer().getPlayerList().getPlayers()) {
                    Account x = d.acc(sp);
                    if ((x.staff || sp.hasPermissions(2)) && x.duty) toast(sp, "Ticket nou #" + t.id + " (" + cat + ")", true);
                }
            }
            case ActionPacket.T_REPLY -> {
                Ticket t = findTicket(d, a);
                boolean st = isStaff(p, acc);
                String text = clean(s, 300);
                if (t == null || text.isEmpty() || (!st && !t.owner.equals(p.getUUID()))) break;
                t.add((st && !t.owner.equals(p.getUUID()) ? "STAFF " : "") + acc.displayName(p.getName().getString()), text);
                ServerPlayer other = p.getServer().getPlayerList().getPlayer(t.owner);
                if (other != null && !other.getUUID().equals(p.getUUID())) toast(other, "Răspuns nou la ticketul #" + t.id, true);
                request(p, d, 6, a);
            }
            case ActionPacket.T_CLOSE -> {
                Ticket t = findTicket(d, a);
                if (t == null || (!isStaff(p, acc) && !t.owner.equals(p.getUUID()))) break;
                t.open = false;
                toast(p, "Ticket #" + t.id + " închis.", true);
            }
            case ActionPacket.DUTY -> {
                if (!isStaff(p, acc)) break;
                acc.duty = !acc.duty;
                toast(p, "Duty: " + (acc.duty ? "ON" : "OFF"), acc.duty);
            }
            case ActionPacket.STAFF_TP -> {
                Ticket t = findTicket(d, a);
                if (t == null || !isStaff(p, acc)) break;
                ServerPlayer o = p.getServer().getPlayerList().getPlayer(t.owner);
                if (o == null) { toast(p, "Jucătorul e offline.", false); break; }
                p.teleportTo(o.serverLevel(), o.getX(), o.getY(), o.getZ(), o.getYRot(), o.getXRot());
            }
            case ActionPacket.MECH -> mechanic(p, acc, a, b);
            case ActionPacket.MINI_DONE -> {
                Jobs j = Jobs.byKey(acc.job);
                long now = System.currentTimeMillis();
                if (j != Jobs.WELDER && j != Jobs.CONSTRUCTOR) break;
                if (now - lastMini.getOrDefault(p.getUUID(), 0L) < 12000) { toast(p, "Mai așteaptă puțin.", false); break; }
                lastMini.put(p.getUUID(), now);
                int score = Math.max(0, Math.min(100, a));
                if (score < 30) { toast(p, "Lucrare slabă, fără plată.", false); break; }
                JobEvents.pay(p, Math.round((j == Jobs.WELDER ? 60 : 50) * score / 100.0));
            }
            case ActionPacket.INTERACT -> interact(p, acc, d, a, b);
            case ActionPacket.PIN_CHECK, ActionPacket.PIN_SET, ActionPacket.WANT_ADD, ActionPacket.WANT_DEL, ActionPacket.REC_ADD,
                 ActionPacket.DISP_CLOSE, ActionPacket.DISP_CALL, ActionPacket.INS_BUY, ActionPacket.CLAIM_FILE, ActionPacket.CLAIM_DECIDE,
                 ActionPacket.HOUSE_BUY, ActionPacket.FG_TAKE, ActionPacket.FG_PARK, ActionPacket.PART_TOGGLE, ActionPacket.NEON_SET,
                 ActionPacket.FAC_CREATE, ActionPacket.FAC_ADD, ActionPacket.FAC_REMOVE, ActionPacket.FAC_GARAGE, ActionPacket.FAC_ZONE,
                 ActionPacket.FAC_ZONECLEAR, ActionPacket.FAC_VEH_ADD, ActionPacket.FAC_DISBAND, ActionPacket.FAC_LEADER, ActionPacket.FAC_LEAVE ->
                Extra.handle(p, d, acc, type, a, b, s);
            case ActionPacket.ADMIN_SET -> {
                if (!p.hasPermissions(4)) { toast(p, "Doar owner-ul poate da acces.", false); break; }
                Account t = accById(d, a);
                if (t == null) break;
                t.staff = b == 1;
                if (!t.staff) t.duty = false;
                ServerPlayer tp = byId(p.getServer(), d, a);
                if (tp != null) { toast(tp, t.staff ? "Ai primit acces STAFF." : "Accesul STAFF ți-a fost retras.", t.staff); Sync.send(tp); }
                toast(p, "#" + a + (t.staff ? " are acum acces STAFF." : " nu mai are acces STAFF."), true);
                request(p, d, 7, 0);
            }
            default -> { }
        }
        d.setDirty();
        Sync.send(p);
    }

    private static final Map<UUID, Long> lastMini = new HashMap<>();

    static boolean isStaff(ServerPlayer p, Account a) { return a.staff || p.hasPermissions(2); }

    private static Ticket findTicket(MoonData d, int id) {
        for (Ticket t : d.tickets) if (t.id == id) return t;
        return null;
    }

    private static void mechanic(ServerPlayer p, Account acc, int op, int rgb) {
        if (Jobs.byKey(acc.job) != Jobs.MECHANIC) { toast(p, "Trebuie să fii pe jobul Mecanic.", false); return; }
        Entity v = VehicleUtil.find(p);
        if (v == null) { toast(p, "Nu e niciun vehicul lângă tine.", false); return; }
        switch (op) {
            case 0 -> { if (VehicleUtil.repair(v)) { toast(p, "Vehicul reparat.", true); JobEvents.pay(p, Jobs.MECHANIC.pay); } else toast(p, "Nu am putut repara vehiculul.", false); }
            case 1 -> { VehicleUtil.paint(v, rgb); toast(p, "Vehicul vopsit.", true); JobEvents.pay(p, Jobs.MECHANIC.pay / 2); }
            case 2 -> {
                float cap = VehicleUtil.capacity(v);
                if (cap > 0 && VehicleUtil.addFuel(v, cap * 0.25f)) toast(p, "Alimentat 25%.", true);
                else toast(p, "Nu pot alimenta vehiculul.", false);
            }
            default -> {
                float cap = VehicleUtil.capacity(v), cur = VehicleUtil.fuel(v);
                toast(p, "Combustibil: " + (cap > 0 ? Math.round(100f * cur / cap) + "%" : "?"), true);
            }
        }
    }

    private static void interact(ServerPlayer p, Account acc, MoonData d, int entityId, int op) {
        Entity e = p.serverLevel().getEntity(entityId);
        if (!(e instanceof ServerPlayer t) || t.distanceToSqr(p) > 36) return;
        Account ta = d.acc(t);
        String pn = acc.displayName(p.getName().getString());
        boolean police = Jobs.byKey(acc.job) == Jobs.POLICE || Extra.isPolice(acc);
        switch (op) {
            case 0 -> {
                msg(t, "[Buletin] " + pn + ", " + acc.age + " ani, ID #" + acc.id + ", tel. " + acc.phone());
                toast(p, "Ai oferit buletinul.", true);
            }
            case 1 -> {
                if (!police) { toast(p, "Doar polițiștii au legitimație.", false); break; }
                msg(t, "[Legitimație] " + pn + " — Poliția MoonCity, nivel " + acc.jobLevel("politist"));
                toast(p, "Ai arătat legitimația.", true);
            }
            case 2 -> {
                if (!police) { toast(p, "Doar polițiștii pot percheziționa.", false); break; }
                StringBuilder sb = new StringBuilder("[Percheziție " + ta.displayName(t.getName().getString()) + "] ");
                int n = 0;
                for (ItemStack st : t.getInventory().items) if (!st.isEmpty()) { sb.append(st.getCount()).append("x ").append(st.getHoverName().getString()).append(", "); n++; }
                msg(p, n == 0 ? sb + "nimic găsit." : sb.toString());
                toast(t, "Ești percheziționat de " + pn, false);
            }
            default -> { }
        }
    }

    private static void request(ServerPlayer p, MoonData d, int kind) { request(p, d, kind, 0); }

    private static void request(ServerPlayer p, MoonData d, int kind, int param) {
        List<String> rows = new ArrayList<>();
        switch (kind) {
            case 1 -> {
                for (ServerPlayer sp : p.getServer().getPlayerList().getPlayers()) {
                    Account x = d.acc(sp);
                    rows.add(x.id + "|" + x.displayName(sp.getName().getString()));
                }
            }
            case 2 -> { Account x = d.acc(p); for (int i = x.inbox.size() - 1; i >= 0; i--) rows.add(x.inbox.getString(i)); }
            case 3 -> {
                for (Catalog.Model m : Catalog.MODELS) rows.add(m.key() + "|" + d.stock(m.key()));
                d.setDirty();
            }
            case 4 -> {
                for (Auction x : d.auctions) {
                    ItemStack st = ItemStack.of(x.item);
                    rows.add(x.id + "|" + x.sellerName + "|" + st.getHoverName().getString() + "|" + st.getCount() + "|" + x.price);
                }
            }
            case 7 -> {
                if (!p.hasPermissions(4)) break;
                for (Map.Entry<UUID, Account> en : d.accounts.entrySet()) {
                    Account x = en.getValue();
                    boolean on = p.getServer().getPlayerList().getPlayer(en.getKey()) != null;
                    rows.add(x.id + "|" + (x.mcName.isEmpty() ? x.displayName("?") : x.mcName) + "|" + (x.staff ? 1 : 0) + "|" + (on ? 1 : 0));
                }
                rows.sort(Comparator.comparingInt(r -> Integer.parseInt(r.split("\\|")[0])));
            }
            case 5 -> {
                boolean st = isStaff(p, d.acc(p));
                for (int i = d.tickets.size() - 1; i >= 0; i--) {
                    Ticket t = d.tickets.get(i);
                    if (!st && !t.owner.equals(p.getUUID())) continue;
                    String last = t.msgs.getString(t.msgs.size() - 1);
                    rows.add(t.id + "|" + t.ownerName + "|" + t.category + "|" + (t.open ? 1 : 0) + "|" + last.substring(last.indexOf('|') + 1));
                }
            }
            case 6 -> {
                Ticket t = findTicket(d, param);
                if (t != null && (t.owner.equals(p.getUUID()) || isStaff(p, d.acc(p))))
                    for (int i = 0; i < t.msgs.size(); i++) rows.add(t.msgs.getString(i));
            }
            default -> Extra.request(p, d, kind, param, rows);
        }
        sendList(p, kind, rows);
    }

    private static void dealerBuy(ServerPlayer p, MoonData d, Account acc, int idx, int rgb) {
        if (!nearNpc(p, 4)) { msg(p, "Trebuie să fii lângă dealer."); return; }
        Catalog.Model m = Catalog.get(idx);
        if (m == null) return;
        EntityType<?> type = EntityType.byString("vehicle:" + m.key()).orElse(null);
        if (type == null) { toast(p, "Modelul nu există în Vehicle mod.", false); return; }
        if (d.stock(m.key()) <= 0) { toast(p, "Stoc epuizat.", false); return; }
        if (!acc.spend(m.price())) { toast(p, "Nu ai destui lei (" + m.price() + ").", false); return; }
        d.stock.put(m.key(), d.stock(m.key()) - 1);
        ServerLevel level = p.serverLevel();
        Entity e = type.create(level);
        if (e == null) return;
        Vec3 look = p.getLookAngle();
        e.moveTo(p.getX() + look.x * 4, p.getY(), p.getZ() + look.z * 4, p.getYRot(), 0);
        VehicleUtil.setup(e, p, rgb & 0xFFFFFF);
        level.addFreshEntity(e);
        toast(p, "Ai cumpărat " + m.label() + "!", true);
        Quests.advance(p, 4);
        request(p, d, 3);
    }

    private static void refuel(ServerPlayer p, Account acc, int percent) {
        if (!nearNpc(p, 2)) { msg(p, "Trebuie să fii lângă benzinar."); return; }
        Entity v = VehicleUtil.find(p);
        if (v == null || !VehicleUtil.isPowered(v)) { msg(p, "Nu e niciun vehicul lângă tine."); return; }
        float cap = VehicleUtil.capacity(v), cur = VehicleUtil.fuel(v);
        if (cap <= 0 || cur < 0) { msg(p, "Vehicul incompatibil cu alimentarea."); return; }
        float want = cap * Math.max(1, Math.min(percent, 100)) / 100f;
        float amount = Math.min(want, cap - cur);
        if (amount <= 0.01f) { toast(p, "Rezervorul e plin.", false); return; }
        long cost = Math.max(1, Math.round(amount * Shop.FUEL_PRICE_PER_UNIT));
        if (!acc.spend(cost)) { toast(p, "Nu ai destui lei (" + cost + " lei).", false); return; }
        if (VehicleUtil.addFuel(v, amount)) toast(p, "Alimentare reușită: " + cost + " lei", true);
        else { acc.cash += cost; toast(p, "Alimentarea a eșuat.", false); }
    }

    private static void park(ServerPlayer p, Account acc) {
        Entity v = VehicleUtil.find(p);
        if (v == null) { msg(p, "Nu e niciun vehicul lângă tine."); return; }
        if (acc.garage.size() >= 20) { msg(p, "Garajul e plin (20)."); return; }
        v.ejectPassengers();
        CompoundTag data = new CompoundTag();
        v.saveWithoutId(data);
        CompoundTag entry = new CompoundTag();
        entry.putString("type", EntityType.getKey(v.getType()).toString());
        entry.putString("name", v.getType().getDescription().getString());
        entry.put("data", data);
        acc.garage.add(entry);
        v.discard();
        toast(p, "Vehicul parcat în garaj.", true);
    }

    private static void take(ServerPlayer p, Account acc, int idx) {
        if (idx < 0 || idx >= acc.garage.size()) return;
        CompoundTag entry = acc.garage.getCompound(idx);
        ServerLevel level = p.serverLevel();
        EntityType<?> type = EntityType.byString(entry.getString("type")).orElse(null);
        if (type == null) { msg(p, "Vehiculul nu mai există în mod."); return; }
        Entity e = type.create(level);
        if (e == null) return;
        CompoundTag data = entry.getCompound("data").copy();
        data.remove("UUID");
        e.load(data);
        Vec3 look = p.getLookAngle();
        e.moveTo(p.getX() + look.x * 4, p.getY(), p.getZ() + look.z * 4, p.getYRot(), 0);
        level.addFreshEntity(e);
        acc.garage.remove(idx);
        toast(p, "Vehicul scos din garaj.", true);
    }

    private static void trunk(ServerPlayer p, MoonData d) {
        Entity v = VehicleUtil.find(p);
        if (v == null) { msg(p, "Nu e niciun vehicul lângă tine."); return; }
        UUID id = v.getUUID();
        SimpleContainer c = new SimpleContainer(27) {
            @Override
            public void stopOpen(Player pl) {
                super.stopOpen(pl);
                d.trunks.put(id, createTag());
                d.setDirty();
            }
        };
        ListTag saved = d.trunks.get(id);
        if (saved != null) c.fromTag(saved);
        p.openMenu(new SimpleMenuProvider((cid, inv, pl) -> ChestMenu.threeRows(cid, inv, c), Component.literal("Portbagaj")));
    }
}
