package com.mooncity.core.server;

import com.mooncity.core.data.Account;
import com.mooncity.core.data.MoonData;
import com.mooncity.core.entity.NpcEntity;
import com.mooncity.core.net.ActionPacket;
import com.mooncity.core.util.VehicleUtil;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;

import java.util.UUID;

public class Actions {
    private static boolean nearNpc(ServerPlayer p, int variant) {
        return !p.serverLevel().getEntitiesOfClass(NpcEntity.class, p.getBoundingBox().inflate(8),
                n -> n.getVariant() == variant).isEmpty();
    }

    private static void msg(ServerPlayer p, String s) { p.sendSystemMessage(Component.literal(s)); }

    public static void handle(ServerPlayer p, int type, int a, int b) {
        MoonData d = MoonData.get(p.getServer());
        Account acc = d.acc(p);
        switch (type) {
            case ActionPacket.DEPOSIT -> {
                if (!nearNpc(p, 0)) { msg(p, "Trebuie să fii lângă bancher."); break; }
                long amt = a < 0 ? acc.cash : Math.min(a, acc.cash);
                if (amt <= 0) break;
                acc.cash -= amt; acc.bank += amt;
            }
            case ActionPacket.WITHDRAW -> {
                if (!nearNpc(p, 0)) { msg(p, "Trebuie să fii lângă bancher."); break; }
                long amt = a < 0 ? acc.bank : Math.min(a, acc.bank);
                if (amt <= 0) break;
                acc.bank -= amt; acc.cash += amt;
            }
            case ActionPacket.BUY -> {
                if (!nearNpc(p, 1)) { msg(p, "Trebuie să fii lângă vânzător."); break; }
                if (a < 0 || a >= Shop.ITEMS.size()) break;
                int qty = Math.max(1, Math.min(b, 64));
                Shop.Entry e = Shop.ITEMS.get(a);
                long cost = (long) e.price() * qty;
                if (acc.cash < cost) { msg(p, "Nu ai destui lei (" + cost + " lei)."); break; }
                acc.cash -= cost;
                for (int i = 0; i < qty; i++) {
                    ItemStack s = e.stack().get();
                    if (!p.getInventory().add(s)) p.drop(s, false);
                }
                msg(p, "Ai cumpărat " + qty + "x " + e.name() + " (-" + cost + " lei)");
            }
            case ActionPacket.REFUEL -> refuel(p, acc, a);
            case ActionPacket.PARK -> park(p, acc);
            case ActionPacket.TAKE -> take(p, acc, a);
            case ActionPacket.TRUNK -> { trunk(p, d); return; }
            case ActionPacket.JOB_START -> {
                if (a < 0 || a >= Jobs.values().length) break;
                Jobs j = Jobs.values()[a];
                acc.job = j.key;
                JobEvents.targets.remove(p.getUUID());
                if (j == Jobs.COURIER || j == Jobs.TRUCKER) JobEvents.assignTarget(p, j);
                msg(p, "Ai început jobul: " + j.label);
            }
            case ActionPacket.JOB_QUIT -> {
                acc.job = "";
                JobEvents.targets.remove(p.getUUID());
                msg(p, "Ai părăsit jobul.");
            }
            default -> { }
        }
        d.setDirty();
        Sync.send(p);
    }

    private static void refuel(ServerPlayer p, Account acc, int percent) {
        if (!nearNpc(p, 2)) { msg(p, "Trebuie să fii lângă benzinar."); return; }
        Entity v = VehicleUtil.find(p);
        if (v == null || !VehicleUtil.isPowered(v)) { msg(p, "Nu e niciun vehicul lângă tine."); return; }
        float cap = VehicleUtil.capacity(v), cur = VehicleUtil.fuel(v);
        if (cap <= 0 || cur < 0) { msg(p, "Vehicul incompatibil cu alimentarea."); return; }
        float want = cap * Math.max(1, Math.min(percent, 100)) / 100f;
        float amount = Math.min(want, cap - cur);
        if (amount <= 0.01f) { msg(p, "Rezervorul e plin."); return; }
        long cost = Math.max(1, Math.round(amount * Shop.FUEL_PRICE_PER_UNIT));
        if (acc.cash < cost) { msg(p, "Nu ai destui lei (" + cost + " lei)."); return; }
        if (VehicleUtil.addFuel(v, amount)) {
            acc.cash -= cost;
            msg(p, "Alimentare reușită: +" + Math.round(amount) + " pentru " + cost + " lei");
        } else msg(p, "Alimentarea a eșuat.");
    }

    private static void park(ServerPlayer p, Account acc) {
        Entity v = VehicleUtil.find(p);
        if (v == null) { msg(p, "Nu e niciun vehicul lângă tine."); return; }
        if (acc.garage.size() >= 20) { msg(p, "Garajul e plin (20)."); return; }
        v.ejectPassengers();
        CompoundTag data = new CompoundTag();
        v.saveWithoutId(data);
        CompoundTag entry = new CompoundTag();
        entry.putString("type", EntityType.getKey(v.getType()).toString());
        entry.putString("name", v.getType().getDescription().getString());
        entry.put("data", data);
        acc.garage.add(entry);
        v.discard();
        msg(p, "Vehicul parcat în garaj.");
    }

    private static void take(ServerPlayer p, Account acc, int idx) {
        if (idx < 0 || idx >= acc.garage.size()) return;
        CompoundTag entry = acc.garage.getCompound(idx);
        ServerLevel level = p.serverLevel();
        EntityType<?> type = EntityType.byString(entry.getString("type")).orElse(null);
        if (type == null) { msg(p, "Vehiculul nu mai există în mod."); return; }
        Entity e = type.create(level);
        if (e == null) return;
        CompoundTag data = entry.getCompound("data").copy();
        data.remove("UUID");
        e.load(data);
        Vec3 look = p.getLookAngle();
        e.moveTo(p.getX() + look.x * 4, p.getY(), p.getZ() + look.z * 4, p.getYRot(), 0);
        level.addFreshEntity(e);
        acc.garage.remove(idx);
        msg(p, "Vehicul scos din garaj.");
    }

    private static void trunk(ServerPlayer p, MoonData d) {
        Entity v = VehicleUtil.find(p);
        if (v == null) { msg(p, "Nu e niciun vehicul lângă tine."); return; }
        UUID id = v.getUUID();
        SimpleContainer c = new SimpleContainer(27) {
            @Override
            public void stopOpen(Player pl) {
                super.stopOpen(pl);
                d.trunks.put(id, createTag());
                d.setDirty();
            }
        };
        ListTag saved = d.trunks.get(id);
        if (saved != null) c.fromTag(saved);
        p.openMenu(new SimpleMenuProvider((cid, inv, pl) -> ChestMenu.threeRows(cid, inv, c),
                Component.literal("Portbagaj")));
    }
}
