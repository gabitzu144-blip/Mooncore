package com.mooncity.core.client.screen;

import com.mooncity.core.net.ActionPacket;
import com.mooncity.core.net.ClientState;
import com.mooncity.core.net.Net;

import java.util.ArrayList;
import java.util.List;

public class HousesScreen extends ListScreen {
    public HousesScreen() { super("CASE", "GPS", "Cumpără"); }

    private String[] row(int i) { return ClientState.list(14).get(i).split("\\|", -1); }

    @Override protected List<String> rows() {
        List<String> r = new ArrayList<>();
        for (int i = 0; i < ClientState.list(14).size(); i++) {
            String[] p = row(i);
            r.add("Casa nr. " + p[0] + " — " + p[1] + " lei — " + (p[2].isEmpty() ? "LIBERĂ" : p[2]));
        }
        return r;
    }
    @Override protected void refresh() { Net.CH.sendToServer(new ActionPacket(ActionPacket.REQ, 14, 0)); }
    @Override protected void onAction(int row, int action) {
        String[] p = row(row);
        if (action == 0) { ClientState.hasWp = true; ClientState.wpX = Integer.parseInt(p[3]); ClientState.wpZ = Integer.parseInt(p[4]); ClientState.wpName = "Casa nr. " + p[0]; }
        else Net.CH.sendToServer(new ActionPacket(ActionPacket.HOUSE_BUY, Integer.parseInt(p[0]), 0));
    }
}
