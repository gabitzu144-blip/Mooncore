package com.mooncity.core.client.screen;

import com.mooncity.core.net.ActionPacket;
import com.mooncity.core.net.ClientState;
import com.mooncity.core.net.Net;
import net.minecraft.client.gui.GuiGraphics;

public class GarageScreen extends MoonScreen {
    private static final int PER_PAGE = 6;
    private int page = 0;
    private int lastSize = -1;

    @Override
    public void tick() {
        if (lastSize != ClientState.garage.size()) { lastSize = ClientState.garage.size(); rebuildWidgets(); }
    }

    public GarageScreen() { super("GARAJ"); pw = 280; ph = 230; }

    @Override
    protected void build() {
        btn("Parchează vehiculul apropiat", px + 12, py + 24, pw - 24, b -> {
            Net.CH.sendToServer(new ActionPacket(ActionPacket.PARK, 0, 0));
        });
        int size = ClientState.garage.size();
        int pages = Math.max(1, (size + PER_PAGE - 1) / PER_PAGE);
        page = Math.min(page, pages - 1);
        for (int i = 0; i < PER_PAGE; i++) {
            int idx = page * PER_PAGE + i;
            if (idx >= size) break;
            final int fi = idx;
            btn("Scoate", px + pw - 72, py + 52 + i * 22, 60, b -> {
                Net.CH.sendToServer(new ActionPacket(ActionPacket.TAKE, fi, 0));
                onClose();
            });
        }
        btn("<", px + 12, py + ph - 28, 24, b -> { if (page > 0) { page--; rebuildWidgets(); } });
        btn(">", px + 40, py + ph - 28, 24, b -> { if ((page + 1) * PER_PAGE < ClientState.garage.size()) { page++; rebuildWidgets(); } });
        btn("Închide", px + pw - 92, py + ph - 28, 80, b -> onClose());
    }

    @Override
    protected void draw(GuiGraphics g, int mx, int my) {
        int size = ClientState.garage.size();
        if (size == 0) g.drawString(font, "Garajul e gol.", px + 14, py + 56, 0xFFAAAAAA, false);
        for (int i = 0; i < PER_PAGE; i++) {
            int idx = page * PER_PAGE + i;
            if (idx >= size) break;
            g.drawString(font, (idx + 1) + ". " + ClientState.garage.get(idx), px + 14, py + 58 + i * 22, 0xFFFFFFFF, false);
        }
        g.drawString(font, "Pagina " + (page + 1), px + 72, py + ph - 22, 0xFFAAAAAA, false);
    }
}
