package com.mooncity.core.util;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;

public class Tracks {
    public static final String[] NAMES = {"Cat", "Blocks", "Chirp", "Far", "Mall", "Mellohi", "Stal", "Strad", "Ward", "Wait", "Otherside", "Pigstep"};

    public static SoundEvent get(int i) {
        return switch (Math.floorMod(i, NAMES.length)) {
            case 0 -> SoundEvents.MUSIC_DISC_CAT;
            case 1 -> SoundEvents.MUSIC_DISC_BLOCKS;
            case 2 -> SoundEvents.MUSIC_DISC_CHIRP;
            case 3 -> SoundEvents.MUSIC_DISC_FAR;
            case 4 -> SoundEvents.MUSIC_DISC_MALL;
            case 5 -> SoundEvents.MUSIC_DISC_MELLOHI;
            case 6 -> SoundEvents.MUSIC_DISC_STAL;
            case 7 -> SoundEvents.MUSIC_DISC_STRAD;
            case 8 -> SoundEvents.MUSIC_DISC_WARD;
            case 9 -> SoundEvents.MUSIC_DISC_WAIT;
            case 10 -> SoundEvents.MUSIC_DISC_OTHERSIDE;
            default -> SoundEvents.MUSIC_DISC_PIGSTEP;
        };
    }
}
