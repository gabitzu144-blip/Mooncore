package com.mooncity.core.block;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

public class SpeakerBE extends BlockEntity {
    public int track = 0;
    public float volume = 0.5f;
    public boolean playing = false;

    public SpeakerBE(BlockPos pos, BlockState state) { super(ModBlocks.SPEAKER_BE.get(), pos, state); }

    @Override
    protected void saveAdditional(CompoundTag t) {
        super.saveAdditional(t);
        t.putInt("track", track); t.putFloat("volume", volume); t.putBoolean("playing", playing);
    }

    @Override
    public void load(CompoundTag t) {
        super.load(t);
        track = t.getInt("track"); volume = t.getFloat("volume"); playing = t.getBoolean("playing");
    }
}
