package com.mooncity.core.net;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;

import java.util.UUID;
import java.util.function.Supplier;

/** rgb < 0 = sterge neonul */
public class NeonPacket {
    public final UUID id; public final int rgb;
    public NeonPacket(UUID id, int rgb) { this.id = id; this.rgb = rgb; }
    public void encode(FriendlyByteBuf b) { b.writeUUID(id); b.writeInt(rgb); }
    public static NeonPacket decode(FriendlyByteBuf b) { return new NeonPacket(b.readUUID(), b.readInt()); }
    public static void handle(NeonPacket m, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> { if (m.rgb < 0) ClientState.neon.remove(m.id); else ClientState.neon.put(m.id, m.rgb); });
        ctx.get().setPacketHandled(true);
    }
}
