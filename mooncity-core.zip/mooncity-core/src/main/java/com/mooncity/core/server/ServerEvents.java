package com.mooncity.core.server;

import com.mooncity.core.MoonCity;
import com.mooncity.core.data.MoonData;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.LogicalSide;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = MoonCity.MODID)
public class ServerEvents {
    @SubscribeEvent
    public static void login(PlayerEvent.PlayerLoggedInEvent e) {
        if (e.getEntity() instanceof ServerPlayer p) {
            MoonData d = MoonData.get(p.getServer());
            d.acc(p);
            d.setDirty();
            Sync.send(p);
        }
    }

    @SubscribeEvent
    public static void tick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || e.side != LogicalSide.SERVER) return;
        if (e.player.tickCount % 20 != 0) return;
        if (e.player instanceof ServerPlayer p) JobEvents.tickDelivery(p);
    }
}
