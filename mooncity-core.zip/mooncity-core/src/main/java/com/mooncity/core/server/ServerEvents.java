package com.mooncity.core.server;

import com.mooncity.core.MoonCity;
import com.mooncity.core.data.Account;
import com.mooncity.core.data.MoonData;
import com.mooncity.core.data.Zone;
import com.mooncity.core.net.Net;
import com.mooncity.core.net.OpenScreenPacket;
import com.mooncity.core.util.Weights;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.LogicalSide;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.PacketDistributor;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Mod.EventBusSubscriber(modid = MoonCity.MODID)
public class ServerEvents {
    private static final Map<UUID, Boolean> inZone = new HashMap<>();

    public static boolean isInZone(ServerPlayer p) { return inZone.getOrDefault(p.getUUID(), false); }

    @SubscribeEvent
    public static void login(PlayerEvent.PlayerLoggedInEvent e) {
        if (e.getEntity() instanceof ServerPlayer p) {
            MoonData d = MoonData.get(p.getServer());
            d.acc(p).mcName = p.getName().getString();
            d.setDirty();
            Ranks.apply(p);
            Sync.send(p);
            for (java.util.Map.Entry<java.util.UUID, Integer> en : d.neon.entrySet())
                com.mooncity.core.net.Net.CH.send(PacketDistributor.PLAYER.with(() -> p), new com.mooncity.core.net.NeonPacket(en.getKey(), en.getValue()));
        }
    }

    @SubscribeEvent
    public static void drink(net.minecraftforge.event.entity.living.LivingEntityUseItemEvent.Finish e) {
        if (!(e.getEntity() instanceof ServerPlayer p)) return;
        net.minecraft.world.item.ItemStack st = e.getItem();
        int add = st.is(net.minecraft.world.item.Items.POTION) ? 40 : st.is(net.minecraft.world.item.Items.MILK_BUCKET) ? 35
                : st.is(net.minecraft.world.item.Items.APPLE) || st.is(net.minecraft.world.item.Items.MELON_SLICE) ? 8 : 0;
        if (add == 0) return;
        MoonData d = MoonData.get(p.getServer());
        Account a = d.acc(p);
        a.thirst = Math.min(100, a.thirst + add);
        d.setDirty();
        Sync.send(p);
    }

    @SubscribeEvent
    public static void logout(PlayerEvent.PlayerLoggedOutEvent e) { inZone.remove(e.getEntity().getUUID()); }

    @SubscribeEvent
    public static void attack(LivingAttackEvent e) {
        if (e.getEntity() instanceof ServerPlayer t && e.getSource().getEntity() instanceof Player && isInZone(t))
            e.setCanceled(true);
    }

    @SubscribeEvent
    public static void tick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || e.side != LogicalSide.SERVER) return;
        if (!(e.player instanceof ServerPlayer p)) return;
        MoonData d = MoonData.get(p.getServer());
        Account a = d.acc(p);

        if (p.tickCount == 100 && !a.created)
            Net.CH.send(PacketDistributor.PLAYER.with(() -> p), new OpenScreenPacket(10));

        if (p.tickCount % 20 != 0) return;

        // timp jucat + recompensa orara
        a.playSeconds++;
        if (a.playSeconds % 3600 == 0) {
            a.progress++;
            long reward = 150L * a.level;
            a.cash += reward;
            if (a.progress >= 4) { a.progress = 0; a.level++; a.cash += 1000; Actions.toast(p, "Nivel " + a.level + "! +1000 lei bonus", true); }
            else Actions.toast(p, "Recompensă de joc: +" + reward + " lei", true);
            Sync.send(p);
        }
        d.setDirty();

        // sete (100 -> 0 in ~20 minute), apoi pierzi viata
        if (a.playSeconds % 12 == 0 && a.thirst > 0) { a.thirst--; if (a.thirst % 5 == 0) Sync.send(p); }
        if (a.thirst == 0 && a.playSeconds % 10 == 0) p.hurt(p.damageSources().starve(), 1.0f);

        // salariu politist (la 5 minute)
        if (a.playSeconds % 300 == 0 && Jobs.byKey(a.job) == Jobs.POLICE) {
            a.cash += 100 + 20L * a.jobLevel("politist");
            Actions.toast(p, "Salariu poliție primit.", true);
            Sync.send(p);
        }

        // safe zone
        boolean in = false;
        for (Zone z : d.zones) if (z.contains(p.getX(), p.getY(), p.getZ())) { in = true; break; }
        Boolean was = inZone.put(p.getUUID(), in);
        if (was != null && was != in) Actions.toast(p, in ? "Ești într-o safe zone" : "Ai ieșit din safe zone", in);
        else if (was == null && in) Actions.toast(p, "Ești într-o safe zone", true);

        // greutate
        if (Weights.total(p) > Weights.MAX)
            p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 1, false, false, false));

        JobEvents.tickDelivery(p);
    }
}
