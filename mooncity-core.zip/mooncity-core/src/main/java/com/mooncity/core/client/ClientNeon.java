package com.mooncity.core.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mooncity.core.MoonCity;
import com.mooncity.core.net.ClientState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.joml.Matrix4f;

/** Neon underglow: patrate luminoase sub vehiculele cu piesa NEON. */
@Mod.EventBusSubscriber(modid = MoonCity.MODID, value = Dist.CLIENT)
public class ClientNeon {
    @SubscribeEvent
    public static void render(RenderLevelStageEvent e) {
        if (e.getStage() != RenderLevelStageEvent.Stage.AFTER_TRANSLUCENT_BLOCKS || ClientState.neon.isEmpty()) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        Vec3 cam = e.getCamera().getPosition();
        PoseStack ps = e.getPoseStack();
        MultiBufferSource.BufferSource buf = mc.renderBuffers().bufferSource();
        VertexConsumer vc = buf.getBuffer(RenderType.lightning());
        Matrix4f m = ps.last().pose();
        float pt = e.getPartialTick();
        for (Entity en : mc.level.entitiesForRendering()) {
            Integer rgb = ClientState.neon.get(en.getUUID());
            if (rgb == null) continue;
            double x = Mth.lerp(pt, en.xo, en.getX()) - cam.x, y = Mth.lerp(pt, en.yo, en.getY()) - cam.y + 0.04, z = Mth.lerp(pt, en.zo, en.getZ()) - cam.z;
            double yaw = Math.toRadians(en.getYRot());
            float c = (float) Math.cos(yaw), s = (float) Math.sin(yaw);
            float hw = en.getBbWidth() / 2f + 0.3f, hl = hw * 1.9f;
            int r = (rgb >> 16) & 255, g = (rgb >> 8) & 255, b = rgb & 255;
            float[] scale = {1.0f, 0.78f, 0.55f};
            int[] alpha = {45, 80, 130};
            for (int k = 0; k < 3; k++) {
                float w = hw * scale[k], l = hl * scale[k];
                float[][] corners = {{-w, -l}, {w, -l}, {w, l}, {-w, l}};
                for (float[] cn : corners) {
                    float xw = cn[0] * c - cn[1] * s, zw = cn[0] * s + cn[1] * c;
                    vc.vertex(m, (float) (x + xw), (float) y, (float) (z + zw)).color(r, g, b, alpha[k]).endVertex();
                }
            }
        }
        buf.endBatch(RenderType.lightning());
    }
}
