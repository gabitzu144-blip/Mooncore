package com.mooncity.core.client;

import com.mooncity.core.MoonCity;
import com.mooncity.core.entity.ModEntities;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = MoonCity.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientModEvents {
    @SubscribeEvent
    public static void renderers(EntityRenderersEvent.RegisterRenderers e) {
        e.registerEntityRenderer(ModEntities.NPC.get(), NpcRenderer::new);
    }

    @SubscribeEvent
    public static void keys(RegisterKeyMappingsEvent e) {
        e.register(Keys.MENU); e.register(Keys.GARAGE); e.register(Keys.TRUNK); e.register(Keys.PHONE);
        e.register(Keys.MECH); e.register(Keys.MAP); e.register(Keys.JOB);
    }

    @SubscribeEvent
    public static void overlays(RegisterGuiOverlaysEvent e) {
        e.registerAboveAll("moonhud", (gui, g, pt, w, h) -> HudRenderer.render(g, w, h));
        e.registerAboveAll("moonspeedo", (gui, g, pt, w, h) -> Speedometer.render(g, w, h));
    }
}
