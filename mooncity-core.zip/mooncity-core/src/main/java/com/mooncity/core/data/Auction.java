package com.mooncity.core.data;

import net.minecraft.nbt.CompoundTag;

import java.util.UUID;

public class Auction {
    public int id;
    public UUID seller;
    public String sellerName;
    public CompoundTag item;
    public long price;

    public CompoundTag save() {
        CompoundTag t = new CompoundTag();
        t.putInt("id", id); t.putUUID("seller", seller); t.putString("sellerName", sellerName);
        t.put("item", item); t.putLong("price", price);
        return t;
    }
    public static Auction load(CompoundTag t) {
        Auction a = new Auction();
        a.id = t.getInt("id"); a.seller = t.getUUID("seller"); a.sellerName = t.getString("sellerName");
        a.item = t.getCompound("item"); a.price = t.getLong("price");
        return a;
    }
}
