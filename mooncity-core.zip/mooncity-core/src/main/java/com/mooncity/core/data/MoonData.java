package com.mooncity.core.data;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.*;

public class MoonData extends SavedData {
    public final Map<UUID, Account> accounts = new HashMap<>();
    public final Map<UUID, ListTag> trunks = new HashMap<>();
    public final List<Poi> pois = new ArrayList<>();
    public final List<Zone> zones = new ArrayList<>();
    public final List<Auction> auctions = new ArrayList<>();
    public final List<Ticket> tickets = new ArrayList<>();
    public int nextTicketId = 1;
    public final Map<String, Integer> stock = new HashMap<>();
    public long lastRestock = 0;
    public int nextAuctionId = 1;
    public ListTag garageZones = new ListTag();   // {name,x,y,z,r}
    public final Map<String, ListTag> factionVehicles = new HashMap<>();
    public ListTag houses = new ListTag();        // {id,x,y,z,price,owner?,ownerName}
    public ListTag wanted = new ListTag();        // {target,reason,by,ts}
    public ListTag records = new ListTag();       // {faction,target,text,by,ts}
    public ListTag dispatches = new ListTag();    // {id,text,x,z,ts,open}
    public ListTag claims = new ListTag();        // {id,owner,ownerName,ownerId,kind,desc,amount,status,ts}
    public final Map<UUID, Integer> neon = new HashMap<>();
    public final Map<UUID, String> parts = new HashMap<>();
    public ListTag factionNames = new ListTag();
    public int nextClaimId = 1, nextDispatchId = 1, nextHouseId = 1;
    public int nextId = 1;
    public int nextOrder = 1;

    public static MoonData get(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(MoonData::load, MoonData::new, "mooncity");
    }

    /** Contul jucatorului; daca nu exista, primeste automat un ID unic. */
    public Account acc(ServerPlayer p) {
        Account a = accounts.get(p.getUUID());
        if (a == null) {
            a = new Account();
            a.id = freeId();
            a.order = nextOrder++;
            accounts.put(p.getUUID(), a);
            setDirty();
        }
        return a;
    }

    private boolean idTaken(int id) {
        for (Account a : accounts.values()) if (a.id == id) return true;
        return false;
    }

    private int freeId() {
        int i = nextId;
        while (idTaken(i)) i++;
        nextId = i + 1;
        return i;
    }

    /** Seteaza ID-ul manual (owner). false daca e deja luat de altcineva. */
    public boolean setId(UUID uuid, int id) {
        for (Map.Entry<UUID, Account> e : accounts.entrySet())
            if (e.getValue().id == id && !e.getKey().equals(uuid)) return false;
        Account a = accounts.get(uuid);
        if (a == null) return false;
        a.id = id;
        if (id >= nextId) nextId = id + 1;
        setDirty();
        return true;
    }

    public boolean hasFaction(String n) {
        for (int i = 0; i < factionNames.size(); i++) if (factionNames.getString(i).equalsIgnoreCase(n)) return true;
        return false;
    }
    public void addFaction(String n) { if (!hasFaction(n)) { factionNames.add(net.minecraft.nbt.StringTag.valueOf(n.toLowerCase())); setDirty(); } }
    public void removeFaction(String n) {
        for (int i = factionNames.size() - 1; i >= 0; i--) if (factionNames.getString(i).equalsIgnoreCase(n)) factionNames.remove(i);
        setDirty();
    }

    public int stock(String key) { restock(); return stock.getOrDefault(key, 5); }

    public void restock() {
        long now = System.currentTimeMillis();
        if (lastRestock == 0) { lastRestock = now; setDirty(); return; }
        while (now - lastRestock >= 300000L) {
            lastRestock += 300000L;
            for (Map.Entry<String, Integer> e : stock.entrySet()) if (e.getValue() < 5) e.setValue(e.getValue() + 1);
            setDirty();
        }
    }

    public static MoonData load(CompoundTag t) {
        MoonData d = new MoonData();
        d.nextId = Math.max(1, t.getInt("nextId"));
        d.nextOrder = Math.max(1, t.getInt("nextOrder"));
        ListTag accs = t.getList("accounts", Tag.TAG_COMPOUND);
        for (Tag x : accs) {
            CompoundTag c = (CompoundTag) x;
            d.accounts.put(c.getUUID("uuid"), Account.load(c));
        }
        ListTag tr = t.getList("trunks", Tag.TAG_COMPOUND);
        for (Tag x : tr) {
            CompoundTag c = (CompoundTag) x;
            d.trunks.put(c.getUUID("uuid"), c.getList("items", Tag.TAG_COMPOUND));
        }
        for (Tag x : t.getList("pois", Tag.TAG_COMPOUND)) d.pois.add(Poi.load((CompoundTag) x));
        for (Tag x : t.getList("zones", Tag.TAG_COMPOUND)) d.zones.add(Zone.load((CompoundTag) x));
        for (Tag x : t.getList("auctions", Tag.TAG_COMPOUND)) d.auctions.add(Auction.load((CompoundTag) x));
        for (Tag x : t.getList("tickets", Tag.TAG_COMPOUND)) d.tickets.add(Ticket.load((CompoundTag) x));
        d.nextTicketId = Math.max(1, t.getInt("nextTicketId"));
        d.garageZones = t.getList("gz", Tag.TAG_COMPOUND);
        d.factionNames = t.getList("fnames", Tag.TAG_STRING);
        d.houses = t.getList("houses", Tag.TAG_COMPOUND);
        d.wanted = t.getList("wanted", Tag.TAG_COMPOUND);
        d.records = t.getList("records", Tag.TAG_COMPOUND);
        d.dispatches = t.getList("dispatches", Tag.TAG_COMPOUND);
        d.claims = t.getList("claims", Tag.TAG_COMPOUND);
        d.nextClaimId = Math.max(1, t.getInt("nextClaimId")); d.nextDispatchId = Math.max(1, t.getInt("nextDispatchId")); d.nextHouseId = Math.max(1, t.getInt("nextHouseId"));
        CompoundTag fv = t.getCompound("fv");
        for (String k : fv.getAllKeys()) d.factionVehicles.put(k, fv.getList(k, Tag.TAG_COMPOUND));
        CompoundTag nn = t.getCompound("neon");
        for (String k : nn.getAllKeys()) d.neon.put(UUID.fromString(k), nn.getInt(k));
        CompoundTag pp = t.getCompound("parts");
        for (String k : pp.getAllKeys()) d.parts.put(UUID.fromString(k), pp.getString(k));
        d.nextAuctionId = Math.max(1, t.getInt("nextAuctionId"));
        d.lastRestock = t.getLong("lastRestock");
        CompoundTag st = t.getCompound("stock");
        for (String k : st.getAllKeys()) d.stock.put(k, st.getInt(k));
        return d;
    }

    @Override
    public CompoundTag save(CompoundTag t) {
        t.putInt("nextId", nextId);
        t.putInt("nextOrder", nextOrder);
        ListTag accs = new ListTag();
        for (Map.Entry<UUID, Account> e : accounts.entrySet()) {
            CompoundTag c = e.getValue().save();
            c.putUUID("uuid", e.getKey());
            accs.add(c);
        }
        t.put("accounts", accs);
        ListTag tr = new ListTag();
        for (Map.Entry<UUID, ListTag> e : trunks.entrySet()) {
            CompoundTag c = new CompoundTag();
            c.putUUID("uuid", e.getKey());
            c.put("items", e.getValue());
            tr.add(c);
        }
        t.put("trunks", tr);
        ListTag p = new ListTag();
        for (Poi poi : pois) p.add(poi.save());
        t.put("pois", p);
        ListTag z = new ListTag();
        for (Zone zn : zones) z.add(zn.save());
        t.put("zones", z);
        ListTag au = new ListTag();
        for (Auction a : auctions) au.add(a.save());
        t.put("auctions", au);
        ListTag tk = new ListTag();
        for (Ticket k : tickets) tk.add(k.save());
        t.put("tickets", tk);
        t.putInt("nextTicketId", nextTicketId);
        t.put("gz", garageZones); t.put("fnames", factionNames); t.put("houses", houses); t.put("wanted", wanted);
        t.put("records", records); t.put("dispatches", dispatches); t.put("claims", claims);
        t.putInt("nextClaimId", nextClaimId); t.putInt("nextDispatchId", nextDispatchId); t.putInt("nextHouseId", nextHouseId);
        CompoundTag fv = new CompoundTag();
        for (Map.Entry<String, ListTag> e : factionVehicles.entrySet()) fv.put(e.getKey(), e.getValue());
        t.put("fv", fv);
        CompoundTag nn = new CompoundTag();
        for (Map.Entry<UUID, Integer> e : neon.entrySet()) nn.putInt(e.getKey().toString(), e.getValue());
        t.put("neon", nn);
        CompoundTag pp = new CompoundTag();
        for (Map.Entry<UUID, String> e : parts.entrySet()) pp.putString(e.getKey().toString(), e.getValue());
        t.put("parts", pp);
        t.putInt("nextAuctionId", nextAuctionId);
        t.putLong("lastRestock", lastRestock);
        CompoundTag st = new CompoundTag();
        for (Map.Entry<String, Integer> e : stock.entrySet()) st.putInt(e.getKey(), e.getValue());
        t.put("stock", st);
        return t;
    }
}
