package com.mooncity.core.data;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.*;

public class MoonData extends SavedData {
    public final Map<UUID, Account> accounts = new HashMap<>();
    public final Map<UUID, ListTag> trunks = new HashMap<>();
    public final List<Poi> pois = new ArrayList<>();
    public int nextId = 1;
    public int nextOrder = 1;

    public static MoonData get(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(MoonData::load, MoonData::new, "mooncity");
    }

    /** Contul jucatorului; daca nu exista, primeste automat un ID unic. */
    public Account acc(ServerPlayer p) {
        Account a = accounts.get(p.getUUID());
        if (a == null) {
            a = new Account();
            a.id = freeId();
            a.order = nextOrder++;
            accounts.put(p.getUUID(), a);
            setDirty();
        }
        return a;
    }

    private boolean idTaken(int id) {
        for (Account a : accounts.values()) if (a.id == id) return true;
        return false;
    }

    private int freeId() {
        int i = nextId;
        while (idTaken(i)) i++;
        nextId = i + 1;
        return i;
    }

    /** Seteaza ID-ul manual (owner). false daca e deja luat de altcineva. */
    public boolean setId(UUID uuid, int id) {
        for (Map.Entry<UUID, Account> e : accounts.entrySet())
            if (e.getValue().id == id && !e.getKey().equals(uuid)) return false;
        Account a = accounts.get(uuid);
        if (a == null) return false;
        a.id = id;
        if (id >= nextId) nextId = id + 1;
        setDirty();
        return true;
    }

    public static MoonData load(CompoundTag t) {
        MoonData d = new MoonData();
        d.nextId = Math.max(1, t.getInt("nextId"));
        d.nextOrder = Math.max(1, t.getInt("nextOrder"));
        ListTag accs = t.getList("accounts", Tag.TAG_COMPOUND);
        for (Tag x : accs) {
            CompoundTag c = (CompoundTag) x;
            d.accounts.put(c.getUUID("uuid"), Account.load(c));
        }
        ListTag tr = t.getList("trunks", Tag.TAG_COMPOUND);
        for (Tag x : tr) {
            CompoundTag c = (CompoundTag) x;
            d.trunks.put(c.getUUID("uuid"), c.getList("items", Tag.TAG_COMPOUND));
        }
        for (Tag x : t.getList("pois", Tag.TAG_COMPOUND)) d.pois.add(Poi.load((CompoundTag) x));
        return d;
    }

    @Override
    public CompoundTag save(CompoundTag t) {
        t.putInt("nextId", nextId);
        t.putInt("nextOrder", nextOrder);
        ListTag accs = new ListTag();
        for (Map.Entry<UUID, Account> e : accounts.entrySet()) {
            CompoundTag c = e.getValue().save();
            c.putUUID("uuid", e.getKey());
            accs.add(c);
        }
        t.put("accounts", accs);
        ListTag tr = new ListTag();
        for (Map.Entry<UUID, ListTag> e : trunks.entrySet()) {
            CompoundTag c = new CompoundTag();
            c.putUUID("uuid", e.getKey());
            c.put("items", e.getValue());
            tr.add(c);
        }
        t.put("trunks", tr);
        ListTag p = new ListTag();
        for (Poi poi : pois) p.add(poi.save());
        t.put("pois", p);
        return t;
    }
}
