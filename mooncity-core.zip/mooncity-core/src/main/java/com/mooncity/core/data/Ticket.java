package com.mooncity.core.data;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;

import java.util.UUID;

public class Ticket {
    public int id;
    public UUID owner;
    public String ownerName = "", category = "INTREBARE";
    public boolean open = true;
    public ListTag msgs = new ListTag(); // "autor|text"

    public CompoundTag save() {
        CompoundTag t = new CompoundTag();
        t.putInt("id", id); t.putUUID("owner", owner); t.putString("ownerName", ownerName);
        t.putString("cat", category); t.putBoolean("open", open); t.put("msgs", msgs);
        return t;
    }
    public static Ticket load(CompoundTag t) {
        Ticket k = new Ticket();
        k.id = t.getInt("id"); k.owner = t.getUUID("owner"); k.ownerName = t.getString("ownerName");
        k.category = t.getString("cat"); k.open = t.getBoolean("open"); k.msgs = t.getList("msgs", Tag.TAG_STRING);
        return k;
    }
    public void add(String who, String text) { msgs.add(StringTag.valueOf(who + "|" + text)); }
}
