package com.mooncity.core.client.screen;

import com.mooncity.core.data.Poi;
import com.mooncity.core.net.ActionPacket;
import com.mooncity.core.net.ClientState;
import com.mooncity.core.net.Net;

import java.util.ArrayList;
import java.util.List;

public class SpawnScreen extends ListScreen {
    public SpawnScreen() { super("ALEGE UN PUNCT DE SPAWN", "Alege"); }

    private List<Poi> spawns() {
        List<Poi> l = new ArrayList<>();
        for (Poi p : ClientState.pois) if (p.type().equals("spawn")) l.add(p);
        return l;
    }

    @Override protected List<String> rows() {
        List<String> r = new ArrayList<>();
        for (Poi p : spawns()) r.add(p.name());
        return r;
    }

    @Override protected void onAction(int row, int action) {
        Net.CH.sendToServer(new ActionPacket(ActionPacket.SPAWN_CHOICE, row, 0));
        onClose();
    }
}
