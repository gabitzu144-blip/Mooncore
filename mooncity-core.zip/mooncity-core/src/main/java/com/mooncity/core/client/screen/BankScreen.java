package com.mooncity.core.client.screen;

import com.mooncity.core.net.ActionPacket;
import com.mooncity.core.net.ClientState;
import com.mooncity.core.net.Net;
import net.minecraft.client.gui.GuiGraphics;

public class BankScreen extends MoonScreen {
    private int mode = 0; // 0 sumar, 1 depunere, 2 retragere

    public BankScreen() { super("MOONCITY BANKING"); pw = 290; ph = 190; }

    @Override
    protected void build() {
        btn("Sumar", px + 10, py + 26, 86, b -> { mode = 0; rebuildWidgets(); });
        btn("Alimentează card", px + 100, py + 26, 96, b -> { mode = 1; rebuildWidgets(); });
        btn("Retrage cash", px + 200, py + 26, 80, b -> { mode = 2; rebuildWidgets(); });
        if (mode != 0) {
            int[] amts = {100, 500, 1000, -1};
            String[] names = {"100", "500", "1000", "Tot"};
            for (int i = 0; i < 4; i++) {
                final int a = amts[i];
                btn(names[i], px + 10 + i * 70, py + 100, 66, b -> Net.CH.sendToServer(new ActionPacket(mode == 1 ? ActionPacket.DEPOSIT : ActionPacket.WITHDRAW, a, 0)));
            }
        }
        btn("Tranzacții", px + 10, py + ph - 28, 80, b -> minecraft.setScreen(new TransactionsScreen()));
        btn("Închide", px + pw - 90, py + ph - 28, 80, b -> onClose());
    }

    @Override
    protected void draw(GuiGraphics g, int mx, int my) {
        g.drawString(font, "CASH: " + ClientState.cash + " lei", px + 14, py + 56, 0xFF55FF55, false);
        g.drawString(font, "CARD: " + ClientState.bank + " lei", px + 14, py + 70, 0xFF55AAFF, false);
        String t = mode == 0 ? "Alege o acțiune." : mode == 1 ? "Cât vrei să depui pe card?" : "Cât vrei să retragi?";
        g.drawString(font, t, px + 14, py + 88, 0xFFF5C518, false);
    }
}
