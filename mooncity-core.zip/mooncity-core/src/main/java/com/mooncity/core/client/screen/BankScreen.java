package com.mooncity.core.client.screen;

import com.mooncity.core.net.ActionPacket;
import com.mooncity.core.net.ClientState;
import com.mooncity.core.net.Net;
import net.minecraft.client.gui.GuiGraphics;

public class BankScreen extends MoonScreen {
    public BankScreen() { super("MOONCITY BANKING"); pw = 280; ph = 170; }

    private void send(int type, int amt) { Net.CH.sendToServer(new ActionPacket(type, amt, 0)); }

    @Override
    protected void build() {
        int[] amts = {100, 1000, 10000, -1};
        String[] names = {"100", "1000", "10000", "Tot"};
        int w = 62, gap = 4, x0 = px + 12;
        for (int i = 0; i < 4; i++) {
            final int a = amts[i];
            btn("Depune " + names[i], x0 + i * (w + gap), py + 70, w, b -> send(ActionPacket.DEPOSIT, a));
            btn("Retrage " + names[i], x0 + i * (w + gap), py + 96, w, b -> send(ActionPacket.WITHDRAW, a));
        }
        btn("Închide", px + pw / 2 - 40, py + 135, 80, b -> onClose());
    }

    @Override
    protected void draw(GuiGraphics g, int mx, int my) {
        g.drawString(font, "Cash: " + ClientState.cash + " lei", px + 14, py + 30, 0xFF55FF55, false);
        g.drawString(font, "Card/Bancă: " + ClientState.bank + " lei", px + 14, py + 46, 0xFF55AAFF, false);
    }
}
