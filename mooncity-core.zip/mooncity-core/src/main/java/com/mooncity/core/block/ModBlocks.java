package com.mooncity.core.block;

import com.mooncity.core.MoonCity;
import com.mooncity.core.net.Net;
import com.mooncity.core.net.OpenScreenPacket;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

@Mod.EventBusSubscriber(modid = MoonCity.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, MoonCity.MODID);
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MoonCity.MODID);

    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES =
            DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, MoonCity.MODID);
    public static final RegistryObject<Block> SPEAKER = BLOCKS.register("speaker",
            () -> new SpeakerBlock(BlockBehaviour.Properties.of().strength(1.5f).noOcclusion()));
    public static final RegistryObject<Item> SPEAKER_ITEM = ITEMS.register("speaker",
            () -> new BlockItem(SPEAKER.get(), new Item.Properties().stacksTo(1)));
    public static final RegistryObject<BlockEntityType<SpeakerBE>> SPEAKER_BE = BLOCK_ENTITIES.register("speaker",
            () -> BlockEntityType.Builder.of(SpeakerBE::new, SPEAKER.get()).build(null));
    public static final RegistryObject<Item> MDT_ITEM = ITEMS.register("mdt",
            () -> new MdtItem(new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Block> ATM = BLOCKS.register("atm",
            () -> new AtmBlock(BlockBehaviour.Properties.of().strength(5f, 1200f)));
    public static final RegistryObject<Item> ATM_ITEM = ITEMS.register("atm",
            () -> new BlockItem(ATM.get(), new Item.Properties()));

    @SubscribeEvent
    public static void tabs(BuildCreativeModeTabContentsEvent e) {
        if (e.getTabKey() == CreativeModeTabs.FUNCTIONAL_BLOCKS) { e.accept(ATM_ITEM); e.accept(SPEAKER_ITEM); e.accept(MDT_ITEM); }
    }

    public static class MdtItem extends Item {
        public MdtItem(Properties p) { super(p); }

        @Override
        public net.minecraft.world.InteractionResultHolder<net.minecraft.world.item.ItemStack> use(Level l, Player pl, InteractionHand h) {
            if (!l.isClientSide && pl instanceof ServerPlayer sp) {
                if (com.mooncity.core.data.MoonData.get(sp.getServer()).acc(sp).faction.isEmpty() && !(com.mooncity.core.data.MoonData.get(sp.getServer()).acc(sp).staff || sp.hasPermissions(2)))
                    sp.sendSystemMessage(net.minecraft.network.chat.Component.literal("Tableta MDT e doar pentru facțiuni (poliție, mafie...)."));
                else Net.CH.send(PacketDistributor.PLAYER.with(() -> sp), new OpenScreenPacket(30));
            }
            return net.minecraft.world.InteractionResultHolder.sidedSuccess(pl.getItemInHand(h), l.isClientSide);
        }
    }

    public static class AtmBlock extends Block {
        public AtmBlock(Properties p) { super(p); }

        @Override
        public InteractionResult use(BlockState s, Level l, BlockPos pos, Player pl, InteractionHand h, BlockHitResult r) {
            if (!l.isClientSide && pl instanceof ServerPlayer sp)
                Net.CH.send(PacketDistributor.PLAYER.with(() -> sp), new OpenScreenPacket(31));
            return InteractionResult.sidedSuccess(l.isClientSide);
        }
    }
}
