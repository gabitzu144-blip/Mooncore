package com.mooncity.core.client.screen;

import com.mooncity.core.client.Ui;
import com.mooncity.core.net.ActionPacket;
import com.mooncity.core.net.ClientState;
import com.mooncity.core.net.Net;
import net.minecraft.client.gui.GuiGraphics;

public class BonusesScreen extends MoonScreen {
    public BonusesScreen() { super("BONUSURI"); pw = 280; ph = 190; }

    @Override
    protected void build() {
        btn("Revendică bonusul zilnic (300 lei)", px + 20, py + 128, pw - 40, b -> Net.CH.sendToServer(new ActionPacket(ActionPacket.BONUS, 0, 0)));
        btn("Închide", px + 20, py + 154, pw - 40, b -> onClose());
    }

    @Override
    protected void draw(GuiGraphics g, int mx, int my) {
        g.drawString(font, "Nivelul tău: LVL " + ClientState.level, px + 14, py + 30, 0xFFFFFFFF, false);
        Ui.bar(g, px + 14, py + 46, pw - 28, 8, ClientState.progress / 4f, 0xFF222844, 0xFFF5C518);
        g.drawString(font, ClientState.progress + "/4 recompense orare", px + 14, py + 58, 0xFFAAAAAA, false);
        long s = ClientState.rewardLeft();
        g.drawString(font, "Până la următoarea recompensă: " + String.format("%02d:%02d", s / 60, s % 60), px + 14, py + 76, 0xFF55FF55, false);
        g.drawString(font, "La 4 recompense urci un nivel (+1000 lei).", px + 14, py + 94, 0xFF888888, false);
    }
}
