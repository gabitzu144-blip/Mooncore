package com.mooncity.core.net;

import com.mooncity.core.data.Poi;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

public class SyncPacket {
    public int id, order, total, tx, tz;
    public long cash, bank;
    public String job;
    public boolean hasTarget;
    public List<Poi> pois;
    public List<String> garage;

    public SyncPacket(int id, int order, int total, long cash, long bank, String job,
                      boolean hasTarget, int tx, int tz, List<Poi> pois, List<String> garage) {
        this.id = id; this.order = order; this.total = total; this.cash = cash; this.bank = bank;
        this.job = job; this.hasTarget = hasTarget; this.tx = tx; this.tz = tz;
        this.pois = pois; this.garage = garage;
    }

    public void encode(FriendlyByteBuf b) {
        b.writeInt(id); b.writeInt(order); b.writeInt(total);
        b.writeLong(cash); b.writeLong(bank); b.writeUtf(job);
        b.writeBoolean(hasTarget); b.writeInt(tx); b.writeInt(tz);
        b.writeInt(pois.size());
        for (Poi p : pois) { b.writeUtf(p.type()); b.writeUtf(p.name()); b.writeInt(p.x()); b.writeInt(p.y()); b.writeInt(p.z()); }
        b.writeInt(garage.size());
        for (String s : garage) b.writeUtf(s);
    }

    public static SyncPacket decode(FriendlyByteBuf b) {
        int id = b.readInt(), order = b.readInt(), total = b.readInt();
        long cash = b.readLong(), bank = b.readLong();
        String job = b.readUtf();
        boolean ht = b.readBoolean(); int tx = b.readInt(), tz = b.readInt();
        int n = b.readInt();
        List<Poi> pois = new ArrayList<>();
        for (int i = 0; i < n; i++) pois.add(new Poi(b.readUtf(), b.readUtf(), b.readInt(), b.readInt(), b.readInt()));
        int g = b.readInt();
        List<String> garage = new ArrayList<>();
        for (int i = 0; i < g; i++) garage.add(b.readUtf());
        return new SyncPacket(id, order, total, cash, bank, job, ht, tx, tz, pois, garage);
    }

    public static void handle(SyncPacket m, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> ClientState.apply(m));
        ctx.get().setPacketHandled(true);
    }
}
