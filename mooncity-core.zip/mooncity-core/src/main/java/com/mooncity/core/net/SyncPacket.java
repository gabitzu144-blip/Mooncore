package com.mooncity.core.net;

import com.mooncity.core.data.Poi;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

public class SyncPacket {
    public int id, order, total, tx, tz, age, level, progress, quest, thirst, jobLevel, jobXp, jobNeed, factionRank;
    public long cash, bank, secondsToReward;
    public String job = "", first = "", last = "", sex = "M", phone = "", rankLabel = "", rankColor = "white", faction = "";
    public boolean hasTarget, created, license, staff, duty, owner, hasPin, licenseGun, insAuto, insHome, factionLeader, fgAccess;
    public List<Poi> pois = new ArrayList<>();
    public List<String> garage = new ArrayList<>();

    public void encode(FriendlyByteBuf b) {
        b.writeInt(id); b.writeInt(order); b.writeInt(total); b.writeInt(tx); b.writeInt(tz);
        b.writeInt(age); b.writeInt(level); b.writeInt(progress); b.writeInt(quest);
        b.writeLong(cash); b.writeLong(bank); b.writeLong(secondsToReward);
        b.writeUtf(job); b.writeUtf(first); b.writeUtf(last); b.writeUtf(sex); b.writeUtf(phone);
        b.writeBoolean(hasTarget); b.writeBoolean(created); b.writeBoolean(license);
        b.writeInt(thirst); b.writeInt(jobLevel); b.writeInt(jobXp); b.writeInt(jobNeed);
        b.writeUtf(rankLabel); b.writeUtf(rankColor); b.writeBoolean(staff); b.writeBoolean(duty); b.writeBoolean(owner);
        b.writeBoolean(hasPin); b.writeBoolean(licenseGun); b.writeBoolean(insAuto); b.writeBoolean(insHome); b.writeUtf(faction); b.writeBoolean(factionLeader); b.writeBoolean(fgAccess); b.writeInt(factionRank);
        b.writeInt(pois.size());
        for (Poi p : pois) { b.writeUtf(p.type()); b.writeUtf(p.name()); b.writeInt(p.x()); b.writeInt(p.y()); b.writeInt(p.z()); }
        b.writeInt(garage.size());
        for (String s : garage) b.writeUtf(s);
    }

    public static SyncPacket decode(FriendlyByteBuf b) {
        SyncPacket m = new SyncPacket();
        m.id = b.readInt(); m.order = b.readInt(); m.total = b.readInt(); m.tx = b.readInt(); m.tz = b.readInt();
        m.age = b.readInt(); m.level = b.readInt(); m.progress = b.readInt(); m.quest = b.readInt();
        m.cash = b.readLong(); m.bank = b.readLong(); m.secondsToReward = b.readLong();
        m.job = b.readUtf(); m.first = b.readUtf(); m.last = b.readUtf(); m.sex = b.readUtf(); m.phone = b.readUtf();
        m.hasTarget = b.readBoolean(); m.created = b.readBoolean(); m.license = b.readBoolean();
        m.thirst = b.readInt(); m.jobLevel = b.readInt(); m.jobXp = b.readInt(); m.jobNeed = b.readInt();
        m.rankLabel = b.readUtf(); m.rankColor = b.readUtf(); m.staff = b.readBoolean(); m.duty = b.readBoolean(); m.owner = b.readBoolean();
        m.hasPin = b.readBoolean(); m.licenseGun = b.readBoolean(); m.insAuto = b.readBoolean(); m.insHome = b.readBoolean(); m.faction = b.readUtf(); m.factionLeader = b.readBoolean(); m.fgAccess = b.readBoolean(); m.factionRank = b.readInt();
        int n = b.readInt();
        for (int i = 0; i < n; i++) m.pois.add(new Poi(b.readUtf(), b.readUtf(), b.readInt(), b.readInt(), b.readInt()));
        int g = b.readInt();
        for (int i = 0; i < g; i++) m.garage.add(b.readUtf());
        return m;
    }

    public static void handle(SyncPacket m, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> ClientState.apply(m));
        ctx.get().setPacketHandled(true);
    }
}
