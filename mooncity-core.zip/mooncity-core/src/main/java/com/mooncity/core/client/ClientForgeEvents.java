package com.mooncity.core.client;

import com.mooncity.core.MoonCity;
import com.mooncity.core.client.screen.*;
import com.mooncity.core.net.ActionPacket;
import com.mooncity.core.net.ClientState;
import com.mooncity.core.net.Net;
import com.mooncity.core.server.Jobs;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.ReceivingLevelScreen;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.client.event.ScreenEvent;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = MoonCity.MODID, value = Dist.CLIENT)
public class ClientForgeEvents {
    @SubscribeEvent
    public static void tick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        HudRenderer.tick();
        boolean free = mc.screen == null;
        while (Keys.MENU.consumeClick()) if (free) mc.setScreen(MainRadial.create());
        while (Keys.GARAGE.consumeClick()) if (free) {
            boolean any = false, near = false;
            for (com.mooncity.core.data.Poi gp : ClientState.pois) {
                if (!gp.type().equals("garage")) continue;
                any = true;
                double dx = mc.player.getX() - gp.x(), dz = mc.player.getZ() - gp.z();
                if (dx * dx + dz * dz <= 3600) near = true;
            }
            if (any && !near) { ClientState.toast = "Nu ești într-un garaj."; ClientState.toastGood = false; ClientState.toastUntil = System.currentTimeMillis() + 3000; }
            else mc.setScreen(new GarageScreen());
        }
        while (Keys.TRUNK.consumeClick()) if (free) Net.CH.sendToServer(new ActionPacket(ActionPacket.TRUNK, 0, 0));
        while (Keys.PHONE.consumeClick()) if (free) mc.setScreen(new PhoneScreen());
        while (Keys.MAP.consumeClick()) if (free) mc.setScreen(new MapScreen());
        while (Keys.MECH.consumeClick()) if (free) {
            if (Jobs.byKey(ClientState.job) == Jobs.MECHANIC) mc.setScreen(MainRadial.mechanic());
            else { ClientState.toast = "Tasta I merge doar pe jobul Mecanic."; ClientState.toastGood = false; ClientState.toastUntil = System.currentTimeMillis() + 3000; }
        }
        while (Keys.JOB.consumeClick()) if (free) {
            Jobs j = Jobs.byKey(ClientState.job);
            if (j == Jobs.WELDER) mc.setScreen(new WeldScreen());
            else if (j == Jobs.CONSTRUCTOR) mc.setScreen(new BuildScreen());
        }
    }

    /** Shift + click dreapta pe un jucator = meniu de interactiune. */
    @SubscribeEvent
    public static void interact(PlayerInteractEvent.EntityInteract e) {
        if (!e.getLevel().isClientSide() || !(e.getTarget() instanceof Player t) || !e.getEntity().isShiftKeyDown()) return;
        if (e.getHand() != net.minecraft.world.InteractionHand.MAIN_HAND) return;
        Minecraft.getInstance().setScreen(MainRadial.interaction(t.getId()));
        e.setCanceled(true);
        e.setCancellationResult(InteractionResult.SUCCESS);
    }

    @SubscribeEvent
    public static void hideVanilla(RenderGuiOverlayEvent.Pre e) {
        if (e.getOverlay() == VanillaGuiOverlay.PLAYER_HEALTH.type() || e.getOverlay() == VanillaGuiOverlay.ARMOR_LEVEL.type()
                || e.getOverlay() == VanillaGuiOverlay.FOOD_LEVEL.type()) e.setCanceled(true);
    }

    @SubscribeEvent
    public static void loading(ScreenEvent.Opening e) {
        if (e.getNewScreen() instanceof ReceivingLevelScreen && !(e.getNewScreen() instanceof MoonLoadingScreen))
            e.setNewScreen(new MoonLoadingScreen());
    }
}
