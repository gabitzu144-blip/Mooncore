package com.mooncity.core.client;

import com.mooncity.core.MoonCity;
import com.mooncity.core.client.screen.GarageScreen;
import com.mooncity.core.client.screen.MenuScreen;
import com.mooncity.core.client.screen.MoonLoadingScreen;
import com.mooncity.core.net.ActionPacket;
import com.mooncity.core.net.Net;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.ReceivingLevelScreen;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.client.event.ScreenEvent;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = MoonCity.MODID, value = Dist.CLIENT)
public class ClientForgeEvents {
    @SubscribeEvent
    public static void tick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        while (Keys.MENU.consumeClick()) if (mc.screen == null) mc.setScreen(new MenuScreen());
        while (Keys.GARAGE.consumeClick()) if (mc.screen == null) mc.setScreen(new GarageScreen());
        while (Keys.TRUNK.consumeClick()) if (mc.screen == null) Net.CH.sendToServer(new ActionPacket(ActionPacket.TRUNK, 0, 0));
    }

    /** Ascundem bara de viata vanilla - o inlocuieste HUD-ul MoonCity. */
    @SubscribeEvent
    public static void hideVanilla(RenderGuiOverlayEvent.Pre e) {
        if (e.getOverlay() == VanillaGuiOverlay.PLAYER_HEALTH.type()) e.setCanceled(true);
    }

    /** Inlocuim ecranul de incarcare a lumii cu cel MoonCity. */
    @SubscribeEvent
    public static void loading(ScreenEvent.Opening e) {
        if (e.getNewScreen() instanceof ReceivingLevelScreen && !(e.getNewScreen() instanceof MoonLoadingScreen))
            e.setNewScreen(new MoonLoadingScreen());
    }
}
