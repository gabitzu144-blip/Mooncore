package com.mooncity.core.net;

import com.mooncity.core.client.ClientHooks;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class OpenSpeakerPacket {
    public final BlockPos pos; public final int track; public final float vol; public final boolean playing;
    public OpenSpeakerPacket(BlockPos pos, int track, float vol, boolean playing) { this.pos = pos; this.track = track; this.vol = vol; this.playing = playing; }
    public void encode(FriendlyByteBuf b) { b.writeBlockPos(pos); b.writeInt(track); b.writeFloat(vol); b.writeBoolean(playing); }
    public static OpenSpeakerPacket decode(FriendlyByteBuf b) { return new OpenSpeakerPacket(b.readBlockPos(), b.readInt(), b.readFloat(), b.readBoolean()); }
    public static void handle(OpenSpeakerPacket m, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientHooks.openSpeaker(m.pos, m.track, m.vol, m.playing)));
        ctx.get().setPacketHandled(true);
    }
}
