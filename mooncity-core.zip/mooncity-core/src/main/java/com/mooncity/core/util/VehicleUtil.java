package com.mooncity.core.util;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;

import java.lang.reflect.Method;
import java.util.Comparator;
import java.util.List;

/**
 * Integrare cu MrCrayfish's Vehicle prin reflectie (nu avem nevoie de jar la compilare).
 */
public class VehicleUtil {
    private static final String BASE = "com.mrcrayfish.vehicle.entity.VehicleEntity";
    private static final String POWERED = "com.mrcrayfish.vehicle.entity.PoweredVehicleEntity";

    private static boolean extendsClass(Entity e, String name) {
        for (Class<?> c = e.getClass(); c != null; c = c.getSuperclass())
            if (c.getName().equals(name)) return true;
        return false;
    }

    public static boolean isVehicle(Entity e) { return e != null && extendsClass(e, BASE); }
    public static boolean isPowered(Entity e) { return e != null && extendsClass(e, POWERED); }

    /** Vehiculul in care esti, sau cel mai apropiat in 6 blocuri. */
    public static Entity find(Player p) {
        Entity v = p.getVehicle();
        if (isVehicle(v)) return v;
        List<Entity> l = p.level().getEntities(p, p.getBoundingBox().inflate(6), VehicleUtil::isVehicle);
        return l.stream().min(Comparator.comparingDouble(p::distanceToSqr)).orElse(null);
    }

    private static Object convert(Class<?> type, Object v) {
        if (v instanceof Number n) {
            if (type == float.class || type == Float.class) return n.floatValue();
            if (type == double.class || type == Double.class) return n.doubleValue();
            if (type == int.class || type == Integer.class) return n.intValue();
            if (type == long.class || type == Long.class) return n.longValue();
        }
        return v;
    }

    private static Object call(Entity v, String name, Object... args) {
        for (Class<?> c = v.getClass(); c != null; c = c.getSuperclass()) {
            for (Method m : c.getDeclaredMethods()) {
                if (!m.getName().equals(name) || m.getParameterCount() != args.length) continue;
                try {
                    m.setAccessible(true);
                    Class<?>[] pt = m.getParameterTypes();
                    Object[] conv = new Object[args.length];
                    for (int i = 0; i < args.length; i++) conv[i] = convert(pt[i], args[i]);
                    return m.invoke(v, conv);
                } catch (Throwable ignored) { }
            }
        }
        return null;
    }

    public static float fuel(Entity v) {
        Object o = call(v, "getCurrentFuel");
        return o instanceof Number n ? n.floatValue() : -1f;
    }

    public static float capacity(Entity v) {
        Object o = call(v, "getFuelCapacity");
        return o instanceof Number n ? n.floatValue() : -1f;
    }

    public static boolean addFuel(Entity v, float amount) {
        float before = fuel(v);
        call(v, "addFuel", amount);
        return fuel(v) > before || before < 0;
    }

    /** Seteaza culoare, proprietar si rezervor plin pentru un vehicul nou cumparat. */
    public static void setup(Entity v, net.minecraft.world.entity.player.Player owner, int rgb) {
        call(v, "setColorRGB", rgb);
        if (call(v, "setOwner", owner) == null) call(v, "setOwner", owner.getUUID());
        float cap = capacity(v);
        if (cap > 0) call(v, "setCurrentFuel", cap);
    }

    /** Repara vehiculul (seteaza viata la maxim) prin reflectie pe EntityDataAccessor HEALTH. */
    @SuppressWarnings({"unchecked", "rawtypes"})
    public static boolean repair(Entity v) {
        try {
            Object max = call(v, "getMaxHealth");
            float mx = max instanceof Number n ? n.floatValue() : 100f;
            for (Class<?> c = v.getClass(); c != null; c = c.getSuperclass()) {
                try {
                    java.lang.reflect.Field f = c.getDeclaredField("HEALTH");
                    f.setAccessible(true);
                    Object acc = f.get(null);
                    if (acc instanceof net.minecraft.network.syncher.EntityDataAccessor a) {
                        v.getEntityData().set(a, mx);
                        return true;
                    }
                } catch (NoSuchFieldException ignored) { }
            }
        } catch (Throwable ignored) { }
        return false;
    }

    public static void paint(Entity v, int rgb) { call(v, "setColorRGB", rgb & 0xFFFFFF); }

    /** km/h (daca vehiculul expune getKilometersPreHour). */
    public static float kmh(Entity v) {
        Object o = call(v, "getKilometersPreHour");
        return o instanceof Number n ? Math.abs(n.floatValue()) : 0f;
    }
}
