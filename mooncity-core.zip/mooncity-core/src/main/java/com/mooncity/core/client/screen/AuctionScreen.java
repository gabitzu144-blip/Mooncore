package com.mooncity.core.client.screen;

import com.mooncity.core.net.ActionPacket;
import com.mooncity.core.net.ClientState;
import com.mooncity.core.net.Net;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;

public class AuctionScreen extends ListScreen {
    private EditBox price;

    public AuctionScreen() { super("LICITAȚIE", "Cumpără"); perPage = 6; }

    private String[] row(int i) { return ClientState.list(4).get(i).split("\\|"); }

    @Override protected List<String> rows() {
        List<String> r = new ArrayList<>();
        for (int i = 0; i < ClientState.list(4).size(); i++) {
            String[] p = row(i);
            r.add(p[2] + " x" + p[3] + "  —  " + p[4] + " lei  (" + p[1] + ")");
        }
        return r;
    }

    @Override protected void refresh() { Net.CH.sendToServer(new ActionPacket(ActionPacket.REQ, 4, 0)); }

    @Override protected void onAction(int row, int action) {
        Net.CH.sendToServer(new ActionPacket(ActionPacket.AUC_BUY, Integer.parseInt(row(row)[0]), 0));
    }

    @Override protected void extra() {
        price = new EditBox(font, px + 62, py + ph - 52, 70, 18, Component.literal("Preț"));
        price.setHint(Component.literal("Preț"));
        price.setFilter(s -> s.matches("\\d*"));
        price.setMaxLength(8);
        addRenderableWidget(price);
        btn("Vinde obiectul din mână", px + 136, py + ph - 52, 150, b -> {
            if (!price.getValue().isEmpty())
                Net.CH.sendToServer(new ActionPacket(ActionPacket.AUC_SELL, Integer.parseInt(price.getValue()), 0));
        });
    }
}
