package com.mooncity.core.client.screen;

import com.mooncity.core.net.ActionPacket;
import com.mooncity.core.net.ClientState;
import com.mooncity.core.net.Net;

import java.util.ArrayList;
import java.util.List;

public class ContactsScreen extends ListScreen {
    public ContactsScreen() { super("TELEFON — JUCĂTORI ONLINE", "Sună", "Mesaj"); }

    private List<String[]> parsed() {
        List<String[]> l = new ArrayList<>();
        for (String s : ClientState.list(1)) l.add(s.split("\\|", 2));
        return l;
    }

    @Override protected List<String> rows() {
        List<String> r = new ArrayList<>();
        for (String[] p : parsed()) r.add("#" + p[0] + "  " + (p.length > 1 ? p[1] : ""));
        return r;
    }

    @Override protected void refresh() { Net.CH.sendToServer(new ActionPacket(ActionPacket.REQ, 1, 0)); }

    @Override protected void onAction(int row, int action) {
        int id = Integer.parseInt(parsed().get(row)[0]);
        if (action == 0) Net.CH.sendToServer(new ActionPacket(ActionPacket.CALL, id, 0));
        else minecraft.setScreen(new MessagesScreen(id));
    }
}
