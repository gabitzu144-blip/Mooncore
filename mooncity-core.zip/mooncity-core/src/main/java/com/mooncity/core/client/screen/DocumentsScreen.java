package com.mooncity.core.client.screen;

import com.mooncity.core.net.ActionPacket;
import com.mooncity.core.net.ClientState;
import com.mooncity.core.net.Net;
import com.mooncity.core.server.Jobs;

import java.util.ArrayList;
import java.util.List;

public class DocumentsScreen extends InfoScreen {
    public DocumentsScreen() {
        super("DOCUMENTE", () -> {
            List<String> l = new ArrayList<>();
            l.add("— BULETIN —");
            l.add("Nume: " + ClientState.first + " " + ClientState.last + "   Vârstă: " + ClientState.age + "   Sex: " + (ClientState.sex.equals("F") ? "F" : "M"));
            l.add("ID: #" + ClientState.id + "   Tel: " + ClientState.phone);
            l.add("— PERMISE —");
            l.add("Permis auto: " + (ClientState.license ? "VALID" : "nu ai") + "   Permis armă: " + (ClientState.licenseGun ? "VALID" : "nu ai"));
            Jobs j = Jobs.byKey(ClientState.job);
            l.add("Job: " + (j == null ? "-" : j.label + " (niv " + ClientState.jobLevel + ")") + "   Facțiune: " + (ClientState.faction.isEmpty() ? "-" : ClientState.faction));
            l.add("Asigurări: auto " + (ClientState.insAuto ? "DA" : "NU") + ", casă " + (ClientState.insHome ? "DA" : "NU"));
            l.add("— CONTRACTE CASĂ —");
            boolean any = false;
            for (String s : ClientState.list(14)) {
                String[] p = s.split("\\|", -1);
                if (p.length > 5 && p[5].equals("1")) { l.add("Contract: Casa nr. " + p[0] + " (" + p[1] + " lei)"); any = true; }
            }
            if (!any) l.add("niciun contract");
            if (!ClientState.rankLabel.isEmpty()) l.add("Grad: " + ClientState.rankLabel.toUpperCase());
            return l;
        });
        pw = 360; ph = 220;
    }

    @Override protected void init() {
        super.init();
        Net.CH.sendToServer(new ActionPacket(ActionPacket.REQ, 14, 0));
    }
}
