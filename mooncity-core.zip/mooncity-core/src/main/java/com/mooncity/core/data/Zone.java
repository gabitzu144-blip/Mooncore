package com.mooncity.core.data;

import net.minecraft.nbt.CompoundTag;

public record Zone(String name, int x, int y, int z, int r) {
    public CompoundTag save() {
        CompoundTag t = new CompoundTag();
        t.putString("name", name); t.putInt("x", x); t.putInt("y", y); t.putInt("z", z); t.putInt("r", r);
        return t;
    }
    public static Zone load(CompoundTag t) {
        return new Zone(t.getString("name"), t.getInt("x"), t.getInt("y"), t.getInt("z"), t.getInt("r"));
    }
    public boolean contains(double px, double py, double pz) {
        double dx = px - x, dz = pz - z;
        return dx * dx + dz * dz <= (double) r * r && Math.abs(py - y) < 80;
    }
}
