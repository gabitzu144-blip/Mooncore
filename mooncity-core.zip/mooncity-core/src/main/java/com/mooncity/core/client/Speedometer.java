package com.mooncity.core.client;

import com.mooncity.core.util.VehicleUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.Entity;

/** Vitezometru + combustibil cand esti intr-un vehicul MrCrayfish. */
public class Speedometer {
    private static float smooth = 0;

    public static void render(GuiGraphics g, int w, int h) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui) return;
        Entity v = mc.player.getVehicle();
        if (v == null || !VehicleUtil.isVehicle(v)) return;

        float kmh = VehicleUtil.kmh(v);
        smooth += (kmh - smooth) * 0.2f;
        int cx = w - 95, cy = h - 80, r = 52;
        double max = 140;
        float t = (float) Math.min(1.0, smooth / max);

        Ui.disc(g, cx, cy, r + 8, 0x99060810);
        Ui.arc(g, cx, cy, r, 5, 135, 405, 0xFF2A2F3A);
        Ui.arc(g, cx, cy, r, 5, 135, 135 + 270 * t, 0xFF22D3EE);
        Ui.arc(g, cx, cy, r, 5, 135 + 270 * 0.85, 405, 0x66FF3040);
        String s = String.valueOf(Math.round(smooth));
        g.pose().pushPose();
        g.pose().scale(2f, 2f, 1f);
        g.drawCenteredString(mc.font, s, cx / 2, (cy - 14) / 2, 0xFFFFFFFF);
        g.pose().popPose();
        g.drawCenteredString(mc.font, "KM/H", cx, cy + 8, 0xFF8899AA);
        int gear = smooth < 1 ? 0 : Math.min(5, 1 + (int) (smooth / 28));
        g.drawCenteredString(mc.font, gear == 0 ? "N" : "D" + gear, cx, cy + 22, 0xFF22D3EE);

        if (VehicleUtil.isPowered(v)) {
            float cap = VehicleUtil.capacity(v), cur = VehicleUtil.fuel(v);
            if (cap > 0 && cur >= 0) {
                float f = Math.min(1f, cur / cap);
                int fx = cx - r - 42, fy = cy + 18, fr = 28;
                Ui.disc(g, fx, fy, fr + 4, 0x99060810);
                Ui.arc(g, fx, fy, fr, 4, 135, 405, 0xFF2A2F3A);
                Ui.arc(g, fx, fy, fr, 4, 135, 135 + 270 * f, f < 0.2f ? 0xFFFF3040 : 0xFFFBBF24);
                g.drawCenteredString(mc.font, "FUEL", fx, fy - 12, 0xFF8899AA);
                g.drawCenteredString(mc.font, Math.round(f * 100) + "%", fx, fy - 2, f < 0.2f ? 0xFFFF5555 : 0xFFFBBF24);
            }
        }
    }
}
