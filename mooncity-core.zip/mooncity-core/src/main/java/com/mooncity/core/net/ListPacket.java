package com.mooncity.core.net;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

/** kind: 1 jucatori, 2 mesaje, 3 stoc dealer, 4 licitatie */
public class ListPacket {
    public final int kind;
    public final List<String> rows;

    public ListPacket(int kind, List<String> rows) { this.kind = kind; this.rows = rows; }

    public void encode(FriendlyByteBuf b) {
        b.writeInt(kind); b.writeInt(rows.size());
        for (String s : rows) b.writeUtf(s, 512);
    }

    public static ListPacket decode(FriendlyByteBuf b) {
        int k = b.readInt(), n = b.readInt();
        List<String> r = new ArrayList<>();
        for (int i = 0; i < n; i++) r.add(b.readUtf(512));
        return new ListPacket(k, r);
    }

    public static void handle(ListPacket m, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> ClientState.lists.put(m.kind, m.rows));
        ctx.get().setPacketHandled(true);
    }
}
