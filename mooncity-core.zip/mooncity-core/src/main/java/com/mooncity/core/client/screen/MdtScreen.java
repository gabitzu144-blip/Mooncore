package com.mooncity.core.client.screen;

import com.mooncity.core.net.ActionPacket;
import com.mooncity.core.net.ClientState;
import com.mooncity.core.net.Net;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.network.chat.Component;

import java.util.List;

/** Tableta MDT pentru facțiuni (poliție: totul; mafie etc.: dosare, persoane, unități). */
public class MdtScreen extends MoonScreen {
    private static final String[] NAV = {"Prezentare", "Căutați", "Dosare", "Persoane", "Dispecerat", "Unități", "Daune", "Hartă", "Facțiune"};
    private int sec = 0, ticks = 0, lastHash = 0, lookup = 0;
    private EditBox idBox, textBox;

    public MdtScreen() { super(ClientState.faction.isEmpty() ? "MDT" : "MDT — " + ClientState.faction.toUpperCase()); pw = 440; ph = 250; if (ClientState.faction.isEmpty()) sec = 8; }

    private boolean police() { return ClientState.faction.equalsIgnoreCase("politie"); }
    private boolean allowed(int s) {
        if (s == 8) return true;
        if (ClientState.faction.isEmpty()) return false;
        if (s == 1 || s == 4) return police();
        if (s == 6) return police() || ClientState.staff;
        return true;
    }

    private int hash() {
        return java.util.Objects.hash(ClientState.list(8), ClientState.list(9), ClientState.list(10), ClientState.list(11), ClientState.list(12), ClientState.list(13), ClientState.list(18), sec);
    }

    @Override
    protected void build() {
        for (int i = 0; i < NAV.length; i++) {
            final int fi = i;
            btn((sec == i ? "► " : "") + NAV[i], px + 6, py + 24 + i * 20, 92, b -> { sec = fi; lookup = 0; rebuildWidgets(); refresh(); });
        }
        btn("Închide", px + 6, py + ph - 26, 92, b -> onClose());
        if (!allowed(sec)) return;
        int cx = px + 106, cw = pw - 114;
        switch (sec) {
            case 1 -> {
                List<String> r = ClientState.list(8);
                for (int i = 0; i < Math.min(5, r.size()); i++) {
                    final int id = Integer.parseInt(r.get(i).split("\\|")[0]);
                    btn("Scoate", cx + cw - 56, py + 40 + i * 20, 56, b -> Net.CH.sendToServer(new ActionPacket(ActionPacket.WANT_DEL, id, 0)));
                }
                form(true, "ID", "Motiv", "Adaugă căutat", (id, t) -> Net.CH.sendToServer(new ActionPacket(ActionPacket.WANT_ADD, id, 0, t)));
            }
            case 2 -> {
                idBox = box(cx, py + 24, 50, "ID");
                btn("Caută", cx + 54, py + 24, 56, b -> { if (!idBox.getValue().isEmpty()) { lookup = Integer.parseInt(idBox.getValue()); refresh(); } });
                textBox = box(cx, py + ph - 52, cw - 110, "Text dosar");
                textBox.setMaxLength(200);
                btn("Adaugă dosar", cx + cw - 104, py + ph - 52, 104, b -> {
                    if (lookup > 0 && !textBox.getValue().isBlank()) {
                        Net.CH.sendToServer(new ActionPacket(ActionPacket.REC_ADD, lookup, 0, textBox.getValue()));
                        textBox.setValue("");
                    }
                });
            }
            case 3 -> {
                idBox = box(cx, py + 24, 50, "ID");
                btn("Caută persoană", cx + 54, py + 24, 100, b -> { if (!idBox.getValue().isEmpty()) { lookup = Integer.parseInt(idBox.getValue()); refresh(); } });
            }
            case 4 -> {
                List<String> r = ClientState.list(10);
                for (int i = 0; i < Math.min(5, r.size()); i++) {
                    final String[] p = r.get(i).split("\\|");
                    btn("GPS", cx + cw - 116, py + 40 + i * 20, 54, b -> { ClientState.hasWp = true; ClientState.wpX = Integer.parseInt(p[2]); ClientState.wpZ = Integer.parseInt(p[3]); ClientState.wpName = "Apel 112"; });
                    btn("Închide", cx + cw - 58, py + 40 + i * 20, 58, b -> Net.CH.sendToServer(new ActionPacket(ActionPacket.DISP_CLOSE, Integer.parseInt(p[0]), 0)));
                }
            }
            case 5 -> {
                List<String> r = ClientState.list(11);
                for (int i = 0; i < Math.min(7, r.size()); i++) {
                    final String[] p = r.get(i).split("\\|");
                    btn("GPS", cx + cw - 56, py + 40 + i * 20, 56, b -> { ClientState.hasWp = true; ClientState.wpX = Integer.parseInt(p[3]); ClientState.wpZ = Integer.parseInt(p[4]); ClientState.wpName = p[1]; });
                }
            }
            case 6 -> {
                List<String> r = ClientState.list(13);
                for (int i = 0; i < Math.min(5, r.size()); i++) {
                    final String[] p = r.get(i).split("\\|", 6);
                    if (!p[4].equals("0")) continue;
                    final int id = Integer.parseInt(p[0]);
                    btn("Aprobă", cx + cw - 116, py + 40 + i * 20, 56, b -> Net.CH.sendToServer(new ActionPacket(ActionPacket.CLAIM_DECIDE, id, 1)));
                    btn("Respinge", cx + cw - 58, py + 40 + i * 20, 58, b -> Net.CH.sendToServer(new ActionPacket(ActionPacket.CLAIM_DECIDE, id, 0)));
                }
            }
            case 8 -> buildFaction(cx, cw);
            case 7 -> btn("Deschide harta (M)", cx, py + 40, 140, b -> minecraft.setScreen(new MapScreen()));
            default -> { }
        }
    }

    private List<String> members() {
        List<String> m = new java.util.ArrayList<>();
        for (String r : ClientState.list(18)) if (!r.startsWith("meta|")) m.add(r);
        return m;
    }

    private void buildFaction(int cx, int cw) {
        if (ClientState.faction.isEmpty()) {
            if (ClientState.staff) {
                textBox = box(cx, py + 40, 140, "Nume facțiune");
                textBox.setMaxLength(16);
                btn("Creează facțiune", cx + 146, py + 40, 110, b -> {
                    if (!textBox.getValue().isBlank()) Net.CH.sendToServer(new ActionPacket(ActionPacket.FAC_CREATE, 0, 0, textBox.getValue()));
                });
            }
            return;
        }
        if (!(ClientState.factionLeader || ClientState.staff)) {
            btn("Părăsește facțiunea", cx, py + ph - 52, 140, b -> Net.CH.sendToServer(new ActionPacket(ActionPacket.FAC_LEAVE, 0, 0)));
            return;
        }
        List<String> mem = members();
        for (int i = 0; i < Math.min(5, mem.size()); i++) {
            final String[] p = mem.get(i).split("\\|");
            if (p[2].equals("1")) continue;
            final int id = Integer.parseInt(p[0]);
            final boolean has = p[3].equals("1");
            btn("Scoate", cx + cw - 172, py + 40 + i * 20, 52, b -> Net.CH.sendToServer(new ActionPacket(ActionPacket.FAC_REMOVE, id, 0)));
            btn("Garaj " + (has ? "ON" : "OFF"), cx + cw - 118, py + 40 + i * 20, 64, b -> Net.CH.sendToServer(new ActionPacket(ActionPacket.FAC_GARAGE, id, has ? 0 : 1)));
            btn("Lider", cx + cw - 52, py + 40 + i * 20, 52, b -> Net.CH.sendToServer(new ActionPacket(ActionPacket.FAC_LEADER, id, 0)));
        }
        idBox = box(cx, py + ph - 76, 46, "ID");
        btn("Adaugă membru", cx + 50, py + ph - 76, 110, b -> {
            if (!idBox.getValue().isEmpty()) Net.CH.sendToServer(new ActionPacket(ActionPacket.FAC_ADD, Integer.parseInt(idBox.getValue()), 0));
            idBox.setValue("");
        });
        int bw = (cw - 12) / 4;
        btn("Garaj aici", cx, py + ph - 52, bw, b -> Net.CH.sendToServer(new ActionPacket(ActionPacket.FAC_ZONE, 10, 0)));
        btn("Șterge garaj", cx + bw + 4, py + ph - 52, bw, b -> Net.CH.sendToServer(new ActionPacket(ActionPacket.FAC_ZONECLEAR, 0, 0)));
        btn("+ Vehicul", cx + 2 * (bw + 4), py + ph - 52, bw, b -> Net.CH.sendToServer(new ActionPacket(ActionPacket.FAC_VEH_ADD, 0, 0)));
        if (!ClientState.factionLeader) btn("Părăsește", cx, py + ph - 100, 100, b -> Net.CH.sendToServer(new ActionPacket(ActionPacket.FAC_LEAVE, 0, 0)));
        if (ClientState.staff) btn("Desființează", cx + 3 * (bw + 4), py + ph - 52, bw, b -> Net.CH.sendToServer(new ActionPacket(ActionPacket.FAC_DISBAND, 0, 0)));
    }

    private EditBox box(int x, int y, int w, String hint) {
        EditBox e = new EditBox(font, x, y, w, 18, Component.literal(hint));
        e.setHint(Component.literal(hint));
        if (hint.equals("ID")) { e.setFilter(s -> s.matches("\\d*")); e.setMaxLength(6); }
        addRenderableWidget(e);
        return e;
    }

    private interface Submit { void go(int id, String text); }

    private void form(boolean withText, String h1, String h2, String label, Submit sub) {
        int cx = px + 106, cw = pw - 114;
        idBox = box(cx, py + ph - 52, 46, h1);
        textBox = box(cx + 50, py + ph - 52, cw - 160, h2);
        textBox.setMaxLength(80);
        btn(label, cx + cw - 106, py + ph - 52, 106, b -> {
            if (idBox.getValue().isEmpty() || textBox.getValue().isBlank()) return;
            sub.go(Integer.parseInt(idBox.getValue()), textBox.getValue());
            textBox.setValue("");
        });
    }

    private void refresh() {
        int[] kinds = {8, 8, 9, 12, 10, 11, 13, 0, 18};
        if (sec == 0) { for (int k : new int[]{8, 10, 11}) Net.CH.sendToServer(new ActionPacket(ActionPacket.REQ, k, 0)); return; }
        if (kinds[sec] > 0) Net.CH.sendToServer(new ActionPacket(ActionPacket.REQ, kinds[sec], lookup));
    }

    @Override
    public void tick() {
        if (ticks++ % 40 == 0) refresh();
        int h = hash();
        if (h != lastHash) { lastHash = h; rebuildWidgets(); }
    }

    @Override
    protected void draw(GuiGraphics g, int mx, int my) {
        int cx = px + 106, cw = pw - 114;
        g.fill(cx - 4, py + 20, px + pw - 6, py + ph - 6, 0xFF0E1330);
        if (!allowed(sec)) { g.drawString(font, "Nu ai acces la această secțiune.", cx, py + 30, 0xFFFF5555, false); return; }
        switch (sec) {
            case 0 -> {
                g.drawString(font, "Facțiune: " + ClientState.faction.toUpperCase() + "   Agent #" + ClientState.id, cx, py + 28, 0xFFF5C518, false);
                g.drawString(font, "Căutați: " + ClientState.list(8).size() + "    Apeluri 112: " + ClientState.list(10).size() + "    Unități online: " + ClientState.list(11).size(), cx, py + 44, 0xFFFFFFFF, false);
                int y = py + 66;
                g.drawString(font, "ULTIMII CĂUTAȚI", cx, y, 0xFF22D3EE, false);
                for (int i = 0; i < Math.min(4, ClientState.list(8).size()); i++) {
                    String[] p = ClientState.list(8).get(i).split("\\|", 4);
                    g.drawString(font, font.plainSubstrByWidth("#" + p[0] + " " + p[1] + " — " + p[2], cw), cx, y + 12 + i * 11, 0xFFDDDDDD, false);
                }
            }
            case 1 -> rowsOut(g, ClientState.list(8), 5, cx, cw - 60, p -> "#" + p[0] + " " + p[1] + " — " + p[2] + " (" + p[3] + ")", 4);
            case 2 -> {
                g.drawString(font, lookup > 0 ? "Dosare pentru #" + lookup : "Introdu un ID și apasă Caută.", cx, py + 50, 0xFFF5C518, false);
                rowsOut(g, ClientState.list(9), 5, cx, cw, p -> p[0] + ": " + (p.length > 1 ? p[1] : ""), 2, py + 64);
            }
            case 3 -> rowsOut(g, ClientState.list(12), 6, cx, cw, p -> p[0], 1, py + 50);
            case 4 -> rowsOut(g, ClientState.list(10), 5, cx, cw - 120, p -> (p[4].equals("1") ? "● " : "○ ") + p[1], 5);
            case 5 -> rowsOut(g, ClientState.list(11), 7, cx, cw - 60, p -> "#" + p[0] + " " + p[1] + " [" + p[2] + "]", 5);
            case 6 -> rowsOut(g, ClientState.list(13), 5, cx, cw - 120, p -> "#" + p[0] + " " + p[2] + " " + p[3] + " lei " + (p[4].equals("0") ? "(nou)" : p[4].equals("1") ? "(aprobat)" : "(respins)") + " " + (p.length > 5 ? p[5] : ""), 6);
            case 8 -> {
                if (ClientState.faction.isEmpty()) {
                    g.drawString(font, ClientState.staff ? "Nu ai facțiune. Scrie un nume și creează una (ex: mafia1, politie)." : "Nu faci parte dintr-o facțiune.", cx, py + 28, 0xFFF5C518, false);
                    break;
                }
                String meta = "";
                for (String r : ClientState.list(18)) if (r.startsWith("meta|")) meta = r;
                String[] m = meta.isEmpty() ? new String[]{"", "0", "0", "0", "0"} : meta.split("\\|");
                g.drawString(font, ClientState.faction.toUpperCase() + (ClientState.factionLeader ? "  (LIDER)" : "  (membru)") + "   membri: " + m[4] + "  zone garaj: " + m[2] + "  vehicule: " + m[3], cx, py + 28, 0xFFF5C518, false);
                List<String> mem = members();
                for (int i = 0; i < Math.min(5, mem.size()); i++) {
                    String[] p = mem.get(i).split("\\|");
                    g.drawString(font, font.plainSubstrByWidth("#" + p[0] + " " + p[1] + (p[2].equals("1") ? " ★LIDER" : "") + (p[4].equals("1") ? " ●" : ""), cw - 180), cx, py + 46 + i * 20, 0xFFFFFFFF, false);
                }
                if (!ClientState.factionLeader) g.drawString(font, "Acces garaj: " + (ClientState.fgAccess ? "DA" : "NU — cere-l liderului"), cx, py + ph - 40, ClientState.fgAccess ? 0xFF55FF55 : 0xFFFF5555, false);
                else g.drawString(font, "Garaj aici = cerc la poziția ta. + Vehicul = stai în el.", cx, py + ph - 34, 0xFF666666, false);
            }
            default -> g.drawString(font, "Harta arată teren real, puncte de interes și GPS.", cx, py + 70, 0xFF888888, false);
        }
    }

    private interface Fmt { String of(String[] p); }

    private void rowsOut(GuiGraphics g, List<String> rows, int max, int x, int w, Fmt f, int split) { rowsOut(g, rows, max, x, w, f, split, py + 44); }

    private void rowsOut(GuiGraphics g, List<String> rows, int max, int x, int w, Fmt f, int split, int y0) {
        if (rows.isEmpty()) g.drawString(font, "— nimic —", x, y0, 0xFF666666, false);
        for (int i = 0; i < Math.min(max, rows.size()); i++) {
            String[] p = rows.get(i).split("\\|", split == 1 ? 1 : 8);
            g.drawString(font, font.plainSubstrByWidth(f.of(p), w), x, y0 + i * 20 - (y0 == py + 44 ? 4 : 0) + (y0 == py + 44 ? 0 : 0), 0xFFFFFFFF, false);
        }
    }
}
