package com.mooncity.core.client.screen;

import com.mooncity.core.net.ActionPacket;
import com.mooncity.core.net.Net;

public class MenuScreen extends MoonScreen {
    public MenuScreen() { super("MOONCITY"); pw = 200; ph = 170; }

    @Override
    protected void build() {
        int x = px + 20, w = pw - 40, y = py + 28;
        btn("Joburi", x, y, w, b -> minecraft.setScreen(new JobsScreen()));
        btn("Garaj  [O]", x, y + 25, w, b -> minecraft.setScreen(new GarageScreen()));
        btn("Portbagaj  [G]", x, y + 50, w, b -> {
            onClose();
            Net.CH.sendToServer(new ActionPacket(ActionPacket.TRUNK, 0, 0));
        });
        btn("Hartă", x, y + 75, w, b -> minecraft.setScreen(new MapScreen()));
        btn("Închide", x, y + 110, w, b -> onClose());
    }
}
