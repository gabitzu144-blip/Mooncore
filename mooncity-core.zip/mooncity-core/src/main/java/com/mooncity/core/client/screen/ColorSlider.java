package com.mooncity.core.client.screen;

import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.network.chat.Component;

import java.util.function.IntConsumer;

public class ColorSlider extends AbstractSliderButton {
    private final String name;
    private final IntConsumer cb;

    public ColorSlider(int x, int y, int w, String name, int init, IntConsumer cb) {
        super(x, y, w, 16, Component.literal(name + ": " + init), init / 255.0);
        this.name = name;
        this.cb = cb;
    }

    @Override protected void updateMessage() { setMessage(Component.literal(name + ": " + Math.round(value * 255))); }
    @Override protected void applyValue() { cb.accept((int) Math.round(value * 255)); }
}
