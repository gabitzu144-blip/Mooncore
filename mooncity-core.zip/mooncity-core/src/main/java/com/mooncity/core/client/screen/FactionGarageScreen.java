package com.mooncity.core.client.screen;

import com.mooncity.core.net.ActionPacket;
import com.mooncity.core.net.ClientState;
import com.mooncity.core.net.Net;

import java.util.ArrayList;
import java.util.List;

public class FactionGarageScreen extends ListScreen {
    public FactionGarageScreen() { super("GARAJ " + ClientState.faction.toUpperCase(), "Scoate"); }

    @Override protected List<String> rows() {
        List<String> r = new ArrayList<>();
        for (String s : ClientState.list(16)) { String[] p = s.split("\\|", 2); r.add(p.length > 1 ? p[1] : p[0]); }
        return r;
    }
    @Override protected void refresh() { Net.CH.sendToServer(new ActionPacket(ActionPacket.REQ, 16, 0)); }
    @Override protected void onAction(int row, int action) {
        Net.CH.sendToServer(new ActionPacket(ActionPacket.FG_TAKE, Integer.parseInt(ClientState.list(16).get(row).split("\\|")[0]), 0));
        onClose();
    }
    @Override protected void extra() {
        btn("Returnează vehiculul", px + 62, py + ph - 26, 130, b -> Net.CH.sendToServer(new ActionPacket(ActionPacket.FG_PARK, 0, 0)));
    }
}
