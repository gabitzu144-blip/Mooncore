package com.mooncity.core.client.screen;

import net.minecraft.client.gui.GuiGraphics;

import java.util.List;

/** Lista cu pagini si 1-2 butoane de actiune pe fiecare rand. */
public abstract class ListScreen extends MoonScreen {
    protected int page = 0, perPage = 7, lastHash = 0, ticks = 0;
    protected final String[] actions;

    protected ListScreen(String title, String... actions) {
        super(title); this.actions = actions; pw = 330; ph = 240;
    }

    protected abstract List<String> rows();
    protected abstract void onAction(int row, int action);
    protected void refresh() { }
    protected void extra() { }

    @Override
    protected void build() {
        List<String> r = rows();
        int pages = Math.max(1, (r.size() + perPage - 1) / perPage);
        page = Math.min(page, pages - 1);
        for (int i = 0; i < perPage; i++) {
            int idx = page * perPage + i;
            if (idx >= r.size()) break;
            for (int k = 0; k < actions.length; k++) {
                final int fi = idx, fk = k;
                int bx = px + pw - 8 - (actions.length - k) * 62;
                btn(actions[k], bx, py + 26 + i * 22, 58, b -> onAction(fi, fk));
            }
        }
        btn("<", px + 8, py + ph - 26, 22, b -> { if (page > 0) { page--; rebuildWidgets(); } });
        btn(">", px + 34, py + ph - 26, 22, b -> { if ((page + 1) * perPage < rows().size()) { page++; rebuildWidgets(); } });
        btn("Închide", px + pw - 88, py + ph - 26, 80, b -> onClose());
        extra();
    }

    @Override
    public void tick() {
        if (ticks++ % 60 == 0) refresh();
        int h = rows().hashCode();
        if (h != lastHash) { lastHash = h; rebuildWidgets(); }
    }

    @Override
    protected void draw(GuiGraphics g, int mx, int my) {
        List<String> r = rows();
        int w = pw - 24 - actions.length * 62;
        if (r.isEmpty()) g.drawString(font, "— nimic de afișat —", px + 12, py + 32, 0xFF888888, false);
        for (int i = 0; i < perPage; i++) {
            int idx = page * perPage + i;
            if (idx >= r.size()) break;
            g.drawString(font, font.plainSubstrByWidth(r.get(idx), w), px + 12, py + 32 + i * 22, 0xFFFFFFFF, false);
        }
        g.drawString(font, "Pag. " + (page + 1), px + 62, py + ph - 20, 0xFF888888, false);
    }
}
