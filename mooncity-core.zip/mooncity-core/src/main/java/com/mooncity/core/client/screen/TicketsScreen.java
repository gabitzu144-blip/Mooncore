package com.mooncity.core.client.screen;

import com.mooncity.core.net.ActionPacket;
import com.mooncity.core.net.ClientState;
import com.mooncity.core.net.Net;

import java.util.ArrayList;
import java.util.List;

public class TicketsScreen extends ListScreen {
    public TicketsScreen() { super(ClientState.staff ? "TICKETE (STAFF)" : "TICKETELE MELE", "Deschide"); perPage = 6; }

    private String[] row(int i) { return ClientState.list(5).get(i).split("\\|", 5); }

    @Override protected List<String> rows() {
        List<String> r = new ArrayList<>();
        for (int i = 0; i < ClientState.list(5).size(); i++) {
            String[] p = row(i);
            r.add("#" + p[0] + " [" + p[2] + "] " + (p[3].equals("1") ? "DESCHIS" : "ÎNCHIS") + " " + p[1] + ": " + (p.length > 4 ? p[4] : ""));
        }
        return r;
    }

    @Override protected void refresh() { Net.CH.sendToServer(new ActionPacket(ActionPacket.REQ, 5, 0)); }
    @Override protected void onAction(int row, int action) { minecraft.setScreen(new TicketScreen(Integer.parseInt(row(row)[0]))); }
    @Override protected void extra() { btn("Ticket nou", px + 62, py + ph - 26, 90, b -> minecraft.setScreen(new NewTicketScreen())); }
}
