package com.mooncity.core.data;

import net.minecraft.nbt.CompoundTag;

/** Punct de interes: garage, job, shop, bank, fuel, delivery. */
public record Poi(String type, String name, int x, int y, int z) {
    public CompoundTag save() {
        CompoundTag t = new CompoundTag();
        t.putString("type", type); t.putString("name", name);
        t.putInt("x", x); t.putInt("y", y); t.putInt("z", z);
        return t;
    }
    public static Poi load(CompoundTag t) {
        return new Poi(t.getString("type"), t.getString("name"), t.getInt("x"), t.getInt("y"), t.getInt("z"));
    }
}
