package com.mooncity.core.client.screen;

import com.mooncity.core.client.Ui;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;

import java.util.List;

/** Meniu circular (K, mecanic, interactiune). */
public class RadialScreen extends Screen {
    public record Entry(String label, ItemStack icon, Runnable action) {}

    private final List<Entry> entries;

    public RadialScreen(String title, List<Entry> entries) {
        super(Component.literal(title));
        this.entries = entries;
    }

    @Override public boolean isPauseScreen() { return false; }

    private int sector(double mx, double my) {
        double dx = mx - width / 2.0, dy = my - height / 2.0, dist = Math.sqrt(dx * dx + dy * dy);
        if (dist < 34 || dist > 124) return -1;
        double ang = Math.toDegrees(Math.atan2(dy, dx)) + 90;
        if (ang < 0) ang += 360;
        double size = 360.0 / entries.size();
        return (int) (((ang + size / 2) % 360) / size);
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        g.fill(0, 0, width, height, 0x66000000);
        int cx = width / 2, cy = height / 2;
        Ui.disc(g, cx, cy, 122, 0xE01B2250);
        Ui.disc(g, cx, cy, 34, 0xF00B0F24);
        int hover = sector(mx, my);
        double size = 360.0 / entries.size();
        for (int i = 0; i < entries.size(); i++) {
            double a = Math.toRadians(-90 + i * size);
            int px = cx + (int) (Math.cos(a) * 80), py = cy + (int) (Math.sin(a) * 80);
            if (i == hover) Ui.disc(g, px, py, 25, 0x66F5C518);
            g.renderItem(entries.get(i).icon(), px - 8, py - 12);
            g.drawCenteredString(font, entries.get(i).label(), px, py + 6, i == hover ? 0xFFF5C518 : 0xFFFFFFFF);
        }
        g.drawCenteredString(font, "✕", cx, cy - 4, 0xFFFFFFFF);
        g.drawCenteredString(font, title, cx, cy - 140, 0xFFF5C518);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int btn) {
        double dx = mx - width / 2.0, dy = my - height / 2.0;
        if (Math.sqrt(dx * dx + dy * dy) < 34) { onClose(); return true; }
        int s = sector(mx, my);
        if (s >= 0) {
            Runnable r = entries.get(s).action();
            minecraft.setScreen(null);
            r.run();
            return true;
        }
        return super.mouseClicked(mx, my, btn);
    }
}
