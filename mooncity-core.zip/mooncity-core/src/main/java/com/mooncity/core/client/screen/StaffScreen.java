package com.mooncity.core.client.screen;

import com.mooncity.core.net.ActionPacket;
import com.mooncity.core.net.ClientState;
import com.mooncity.core.net.Net;
import net.minecraft.client.gui.GuiGraphics;

public class StaffScreen extends MoonScreen {
    public StaffScreen() { super("MOONCITY DASHBOARD — STAFF"); pw = 260; ph = 180; }

    @Override
    protected void build() {
        btn("DUTY: " + (ClientState.duty ? "ON" : "OFF"), px + 20, py + 30, pw - 40, b -> {
            Net.CH.sendToServer(new ActionPacket(ActionPacket.DUTY, 0, 0));
            minecraft.setScreen(null);
        });
        btn("TICKETE", px + 20, py + 56, pw - 40, b -> minecraft.setScreen(new TicketsScreen()));
        btn("JUCĂTORI ONLINE", px + 20, py + 82, pw - 40, b -> minecraft.setScreen(new ContactsScreen()));
        btn("Închide", px + 20, py + 140, pw - 40, b -> onClose());
    }

    @Override protected void draw(GuiGraphics g, int mx, int my) {
        g.drawString(font, "Comenzi: /rank set, /staff, /setid, /givemoney, /mc ...", px + 20, py + 112, 0xFF888888, false);
    }
}
