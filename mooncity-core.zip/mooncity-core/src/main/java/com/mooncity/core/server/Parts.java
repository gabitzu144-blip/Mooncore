package com.mooncity.core.server;

import java.util.List;

/** Piese de tuning pentru panoul de mecanic (cu dependinte, ca in referinta). */
public class Parts {
    public record Part(String id, String name, String cat, int price, String[] deps) {}

    public static final List<Part> ALL = List.of(
        new Part("ecu", "ECU REMAP", "MOTOR", 1500, new String[]{}),
        new Part("intake", "ADMISIE PERFORMANȚĂ", "MOTOR", 800, new String[]{}),
        new Part("antilag", "ANTI-LAG SYSTEM", "MOTOR", 2500, new String[]{"ecu"}),
        new Part("downpipe", "PERFORMANCE DOWNPIPE", "EVACUARE", 1200, new String[]{"ecu"}),
        new Part("catdel", "CATALYST DELETE", "EVACUARE", 700, new String[]{}),
        new Part("pipe", "STRAIGHT PIPE EXHAUST", "EVACUARE", 900, new String[]{"catdel"}),
        new Part("bov", "BLOW-OFF VALVE", "TURBO", 600, new String[]{"intake"}),
        new Part("turbo", "TURBO UPGRADE", "TURBO", 3000, new String[]{"ecu", "intake"}),
        new Part("brakes", "FRÂNE PERFORMANȚĂ", "FRÂNE", 1000, new String[]{}),
        new Part("susp", "SUSPENSIE SPORT", "SUSPENSIE", 1100, new String[]{}),
        new Part("tint", "GEAMURI FUMURII", "ESTETIC", 300, new String[]{}),
        new Part("neon", "NEON UNDERGLOW", "ESTETIC", 500, new String[]{})
    );

    public static int index(String id) {
        for (int i = 0; i < ALL.size(); i++) if (ALL.get(i).id().equals(id)) return i;
        return -1;
    }
}
