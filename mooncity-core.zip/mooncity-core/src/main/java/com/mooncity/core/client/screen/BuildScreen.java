package com.mooncity.core.client.screen;

import com.mooncity.core.client.Ui;
import com.mooncity.core.net.ActionPacket;
import com.mooncity.core.net.Net;
import net.minecraft.client.gui.GuiGraphics;
import org.lwjgl.glfw.GLFW;

import java.util.Random;

/** Minijoc constructor: apasa SPACE cand bara e in zona verde (9 runde). */
public class BuildScreen extends MoonScreen {
    private static final int ROUNDS = 9;
    private final Random rnd = new Random();
    private int round = 0, hits = 0;
    private double pos = 0, dir = 1, zoneStart;
    private String msg = "Apasă SPACE în zona verde!";

    public BuildScreen() { super("REPARAȚIE PEREȚI"); pw = 340; ph = 170; newZone(); }

    private void newZone() { zoneStart = 0.1 + rnd.nextDouble() * 0.65; }

    @Override protected void build() { btn("Renunță", px + pw - 80, py + ph - 24, 70, b -> onClose()); }

    @Override
    public void tick() {
        pos += dir * (0.025 + round * 0.004);
        if (pos > 1) { pos = 1; dir = -1; }
        if (pos < 0) { pos = 0; dir = 1; }
    }

    private void hit() {
        boolean ok = pos >= zoneStart && pos <= zoneStart + 0.2;
        if (ok) hits++;
        msg = ok ? "Perfect!" : "Ai ratat!";
        round++;
        newZone();
        if (round >= ROUNDS) {
            Net.CH.sendToServer(new ActionPacket(ActionPacket.MINI_DONE, hits * 100 / ROUNDS, 0));
            minecraft.setScreen(null);
        }
    }

    @Override
    public boolean keyPressed(int key, int sc, int mod) {
        if (key == GLFW.GLFW_KEY_SPACE) { hit(); return true; }
        return super.keyPressed(key, sc, mod);
    }

    @Override
    protected void draw(GuiGraphics g, int mx, int my) {
        int left = px + 14, w = pw - 28, y = py + 60;
        g.fill(left, y, left + w, y + 22, 0xFF0F1530);
        g.fill(left + (int) (zoneStart * w), y, left + (int) ((zoneStart + 0.2) * w), y + 22, 0xFF22C55E);
        g.fill(left + (int) (pos * w) - 2, y - 4, left + (int) (pos * w) + 2, y + 26, 0xFFFBBF24);
        Ui.bar(g, left, py + 100, w, 6, round / (float) ROUNDS, 0xFF222844, 0xFF22D3EE);
        g.drawString(font, "Concentrare: " + (ROUNDS - round) + "/" + ROUNDS + "   Reușite: " + hits, left, py + 30, 0xFFDDDDDD, false);
        g.drawString(font, msg, left, py + 112, 0xFFF5C518, false);
    }
}
