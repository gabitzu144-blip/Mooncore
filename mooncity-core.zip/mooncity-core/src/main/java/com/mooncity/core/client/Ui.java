package com.mooncity.core.client;

import net.minecraft.client.gui.GuiGraphics;

public class Ui {
    public static void disc(GuiGraphics g, int cx, int cy, int r, int color) {
        for (int dy = -r; dy <= r; dy++) {
            int dx = (int) Math.sqrt((double) r * r - (double) dy * dy);
            g.fill(cx - dx, cy + dy, cx + dx, cy + dy + 1, color);
        }
    }

    /** Arc cu unghiuri in grade, in sens orar de la axa +X (ecran). */
    public static void arc(GuiGraphics g, int cx, int cy, int r, int thick, double from, double to, int color) {
        for (double a = from; a <= to; a += 1.5) {
            double rad = Math.toRadians(a), c = Math.cos(rad), s = Math.sin(rad);
            for (int rr = r - thick; rr <= r; rr++) {
                int x = cx + (int) Math.round(c * rr), y = cy + (int) Math.round(s * rr);
                g.fill(x, y, x + 2, y + 2, color);
            }
        }
    }

    public static void panel(GuiGraphics g, int x, int y, int w, int h) {
        g.fill(x, y, x + w, y + h, 0xCC10142B);
        g.fill(x, y, x + w, y + 1, 0xFFF5C518);
    }

    public static void bar(GuiGraphics g, int x, int y, int w, int h, float frac, int bg, int fg) {
        g.fill(x, y, x + w, y + h, bg);
        g.fill(x, y, x + (int) (w * Math.max(0f, Math.min(1f, frac))), y + h, fg);
    }
}
