package com.mooncity.core.server;

/** Gradele din facțiuni (0..4) + titlul liderului. Gradul 3+ = ofițer (poate adăuga/scoate membri). */
public class FactionRanks {
    public static final int OFFICER = 3;

    public static String[] names(String faction) {
        if (faction.equalsIgnoreCase("politie")) return new String[]{"Agent", "Sergent", "Locotenent", "Căpitan", "Comisar"};
        return new String[]{"Recrut", "Soldat", "Capo", "Consilier", "Underboss"};
    }

    public static String name(String faction, int rank, boolean leader) {
        if (leader) return faction.equalsIgnoreCase("politie") ? "Șef" : "Boss";
        String[] n = names(faction);
        return n[Math.max(0, Math.min(n.length - 1, rank))];
    }
}
