package com.mooncity.core.client.screen;

import com.mooncity.core.net.ActionPacket;
import com.mooncity.core.net.ClientState;
import com.mooncity.core.net.Net;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.network.chat.Component;

import java.util.List;

public class TicketScreen extends MoonScreen {
    private final int id;
    private EditBox reply;
    private int ticks;

    public TicketScreen(int id) { super("TICKET #" + id); this.id = id; pw = 360; ph = 240; }

    @Override
    protected void build() {
        reply = new EditBox(font, px + 10, py + ph - 56, pw - 90, 18, Component.literal("Răspuns"));
        reply.setMaxLength(300);
        reply.setHint(Component.literal("Scrie un răspuns..."));
        addRenderableWidget(reply);
        btn("Trimite", px + pw - 76, py + ph - 56, 66, b -> {
            if (reply.getValue().isBlank()) return;
            Net.CH.sendToServer(new ActionPacket(ActionPacket.T_REPLY, id, 0, reply.getValue()));
            reply.setValue("");
        });
        btn("Închide ticket", px + 10, py + ph - 30, 100, b -> { Net.CH.sendToServer(new ActionPacket(ActionPacket.T_CLOSE, id, 0)); onClose(); });
        if (ClientState.staff) btn("Teleport", px + 114, py + ph - 30, 80, b -> Net.CH.sendToServer(new ActionPacket(ActionPacket.STAFF_TP, id, 0)));
        btn("Înapoi", px + pw - 90, py + ph - 30, 80, b -> minecraft.setScreen(new TicketsScreen()));
    }

    @Override public void tick() { if (ticks++ % 30 == 0) Net.CH.sendToServer(new ActionPacket(ActionPacket.REQ, 6, id)); }

    @Override
    protected void draw(GuiGraphics g, int mx, int my) {
        List<String> m = ClientState.list(6);
        int start = Math.max(0, m.size() - 9);
        for (int i = start; i < m.size(); i++) {
            String[] p = m.get(i).split("\\|", 2);
            boolean staff = p[0].startsWith("STAFF");
            g.drawString(font, font.plainSubstrByWidth(p[0] + ": " + (p.length > 1 ? p[1] : ""), pw - 24), px + 12, py + 26 + (i - start) * 16,
                    staff ? 0xFFF5C518 : 0xFFDDDDDD, false);
        }
    }
}
