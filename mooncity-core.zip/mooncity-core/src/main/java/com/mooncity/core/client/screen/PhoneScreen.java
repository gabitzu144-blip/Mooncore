package com.mooncity.core.client.screen;

import com.mooncity.core.client.Ui;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.time.LocalTime;
import java.util.List;
import java.util.function.Supplier;

public class PhoneScreen extends Screen {
    private record App(String label, int color, String icon, Supplier<Screen> open) {}

    private final List<App> apps = List.of(
        new App("Telefon", 0xFF2ECC71, "☎", ContactsScreen::new),
        new App("Mesaje", 0xFF2ECC71, "✉", MessagesScreen::new),
        new App("Personaj", 0xFF2E8BEF, "☺", DocumentsScreen::new),
        new App("SIM", 0xFFE74C5C, "▦", () -> new InfoScreen("MY SIM", () -> List.of(
            "Număr: " + com.mooncity.core.net.ClientState.phone, "ID: " + com.mooncity.core.net.ClientState.id))),
        new App("Setări", 0xFF999999, "⚙", SettingsScreen::new),
        new App("Navigator", 0xFFA855F7, "➤", () -> new NavigatorScreen(null)),
        new App("Vehicule", 0xFF333333, "◆", GarageScreen::new),
        new App("Bancă", 0xFF2ECC71, "$", PhoneBankScreen::new),
        new App("Licitație", 0xFFF59E0B, "⚖", AuctionScreen::new),
        new App("Loto", 0xFFF5C518, "★", LotteryScreen::new),
        new App("Bonusuri", 0xFFFBBF24, "♥", BonusesScreen::new),
        new App("Joburi", 0xFF3B82F6, "⚒", JobsScreen::new),
        new App("Hartă", 0xFF14B8A6, "⌖", MapScreen::new),
        new App("Tickete", 0xFFF97316, "✎", TicketsScreen::new),
        new App("Asigurări", 0xFF0EA5E9, "☂", InsuranceScreen::new),
        new App("Case", 0xFF84CC16, "⌂", HousesScreen::new),
        new App("Tranzacții", 0xFF64748B, "≡", TransactionsScreen::new)
    );

    public PhoneScreen() { super(Component.literal("Telefon")); }

    @Override public boolean isPauseScreen() { return false; }

    private int px() { return (width - 360) / 2; }
    private int py() { return (height - 250) / 2; }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        renderBackground(g);
        int x = px(), y = py();
        g.fill(x - 4, y - 4, x + 364, y + 254, 0xFFDDD5CC);
        g.fill(x, y, x + 360, y + 250, 0xFF0B0F24);
        g.fillGradient(x, y, x + 360, y + 250, 0xFF0B0F24, 0xFF2A1B3D);
        LocalTime t = LocalTime.now();
        g.drawCenteredString(font, String.format("%02d:%02d", t.getHour(), t.getMinute()), x + 180, y + 6, 0xFFFFFFFF);
        g.drawString(font, "MOONCITY", x + 8, y + 6, 0xFFF5C518, false);
        g.drawString(font, "✕", x + 346, y + 6, 0xFFFFFFFF, false);
        for (int i = 0; i < apps.size(); i++) {
            int ax = x + 12 + (i % 7) * 49, ay = y + 28 + (i / 7) * 62;
            boolean hov = mx >= ax && mx < ax + 40 && my >= ay && my < ay + 56;
            g.fill(ax, ay, ax + 40, ay + 40, hov ? 0xFFFFFFFF : apps.get(i).color());
            g.fill(ax + 1, ay + 1, ax + 39, ay + 39, apps.get(i).color());
            g.drawCenteredString(font, apps.get(i).icon(), ax + 20, ay + 16, 0xFFFFFFFF);
            g.drawCenteredString(font, apps.get(i).label(), ax + 20, ay + 44, 0xFFFFFFFF);
        }
    }

    @Override
    public boolean mouseClicked(double mx, double my, int btn) {
        int x = px(), y = py();
        if (mx >= x + 340 && mx < x + 358 && my >= y && my < y + 18) { onClose(); return true; }
        for (int i = 0; i < apps.size(); i++) {
            int ax = x + 12 + (i % 7) * 49, ay = y + 28 + (i / 7) * 62;
            if (mx >= ax && mx < ax + 40 && my >= ay && my < ay + 56) { minecraft.setScreen(apps.get(i).open().get()); return true; }
        }
        return super.mouseClicked(mx, my, btn);
    }
}
