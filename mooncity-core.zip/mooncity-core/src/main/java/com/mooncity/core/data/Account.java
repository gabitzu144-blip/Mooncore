package com.mooncity.core.data;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;

public class Account {
    public int id, order;
    public long cash = 500, bank = 0;
    public String job = "";
    public ListTag garage = new ListTag();            // {type,name,data}
    public boolean created = false;
    public String first = "", last = "", sex = "M";
    public int age = 18;
    public int level = 1, progress = 0;               // progress 0..4
    public long playSeconds = 0;
    public int quest = 0;
    public long lastBonusDay = -1;
    public boolean license = false;
    public ListTag inbox = new ListTag();             // StringTag "from|text"
    public String rankLabel = "", rankColor = "white", mcName = "";
    public boolean staff = false, duty = false;
    public String faction = "", pin = "";
    public boolean licenseGun = false, factionLeader = false, fgAccess = false;
    public long insAuto = 0, insHome = 0;             // expirare (millis)
    public ListTag tx = new ListTag();                // tranzactii "data|text"
    public int thirst = 100;
    public CompoundTag jobData = new CompoundTag();   // key -> {l,x}

    public int jobLevel(String key) { return Math.max(1, jobData.getCompound(key).getInt("l")); }
    public int jobXp(String key) { return jobData.getCompound(key).getInt("x"); }
    public static int xpNeeded(int level) { return 20 + level * 18; }
    /** Adauga xp; returneaza true la level-up. */
    public boolean addJobXp(String key, int amount) {
        CompoundTag c = jobData.getCompound(key);
        int l = Math.max(1, c.getInt("l")), x = c.getInt("x") + amount;
        boolean up = false;
        while (x >= xpNeeded(l)) { x -= xpNeeded(l); l++; up = true; }
        c.putInt("l", l); c.putInt("x", x);
        jobData.put(key, c);
        return up;
    }

    /** Plateste intai din cash, apoi de pe card. */
    public boolean spend(long c) {
        if (c < 0 || cash + bank < c) return false;
        long fromCash = Math.min(cash, c);
        cash -= fromCash;
        bank -= (c - fromCash);
        return true;
    }

    public String phone() { return "07" + (10000000L + (id * 7919L) % 89999999L); }

    public String displayName(String fallback) { return created ? first + " " + last : fallback; }

    public void addTx(String text) {
        tx.add(StringTag.valueOf(java.time.LocalDateTime.now().format(java.time.format.DateTimeFormatter.ofPattern("dd/MM HH:mm")) + "|" + text));
        while (tx.size() > 40) tx.remove(0);
    }

    public void addInbox(String line) {
        inbox.add(StringTag.valueOf(line));
        while (inbox.size() > 30) inbox.remove(0);
    }

    public CompoundTag save() {
        CompoundTag t = new CompoundTag();
        t.putInt("id", id); t.putInt("order", order);
        t.putLong("cash", cash); t.putLong("bank", bank);
        t.putString("job", job); t.put("garage", garage);
        t.putBoolean("created", created);
        t.putString("first", first); t.putString("last", last); t.putString("sex", sex);
        t.putInt("age", age); t.putInt("level", level); t.putInt("progress", progress);
        t.putLong("play", playSeconds); t.putInt("quest", quest);
        t.putLong("bonusDay", lastBonusDay); t.putBoolean("license", license);
        t.put("inbox", inbox);
        t.putString("faction", faction); t.putString("pin", pin); t.putBoolean("gun", licenseGun); t.putBoolean("fLead", factionLeader); t.putBoolean("fAcc", fgAccess);
        t.putLong("insAuto", insAuto); t.putLong("insHome", insHome); t.put("tx", tx);
        t.putString("mcName", mcName);
        t.putString("rankLabel", rankLabel); t.putString("rankColor", rankColor);
        t.putBoolean("staff", staff); t.putBoolean("duty", duty);
        t.putInt("thirst", thirst); t.put("jobData", jobData);
        return t;
    }

    public static Account load(CompoundTag t) {
        Account a = new Account();
        a.id = t.getInt("id"); a.order = t.getInt("order");
        a.cash = t.getLong("cash"); a.bank = t.getLong("bank");
        a.job = t.getString("job");
        a.garage = t.getList("garage", Tag.TAG_COMPOUND);
        a.created = t.getBoolean("created");
        a.first = t.getString("first"); a.last = t.getString("last");
        a.sex = t.contains("sex") ? t.getString("sex") : "M";
        a.age = t.contains("age") ? t.getInt("age") : 18;
        a.level = Math.max(1, t.getInt("level")); a.progress = t.getInt("progress");
        a.playSeconds = t.getLong("play"); a.quest = t.getInt("quest");
        a.lastBonusDay = t.contains("bonusDay") ? t.getLong("bonusDay") : -1;
        a.license = t.getBoolean("license");
        a.inbox = t.getList("inbox", Tag.TAG_STRING);
        a.faction = t.getString("faction"); a.pin = t.getString("pin"); a.licenseGun = t.getBoolean("gun"); a.factionLeader = t.getBoolean("fLead"); a.fgAccess = t.getBoolean("fAcc");
        a.insAuto = t.getLong("insAuto"); a.insHome = t.getLong("insHome"); a.tx = t.getList("tx", Tag.TAG_STRING);
        a.mcName = t.getString("mcName");
        a.rankLabel = t.getString("rankLabel");
        a.rankColor = t.contains("rankColor") ? t.getString("rankColor") : "white";
        a.staff = t.getBoolean("staff"); a.duty = t.getBoolean("duty");
        a.thirst = t.contains("thirst") ? t.getInt("thirst") : 100;
        a.jobData = t.getCompound("jobData");
        return a;
    }
}
