package com.mooncity.core.data;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;

public class Account {
    public int id;
    public int order;
    public long cash = 500;
    public long bank = 0;
    public String job = "";
    /** fiecare element: {type, name, data} */
    public ListTag garage = new ListTag();

    public CompoundTag save() {
        CompoundTag t = new CompoundTag();
        t.putInt("id", id); t.putInt("order", order);
        t.putLong("cash", cash); t.putLong("bank", bank);
        t.putString("job", job);
        t.put("garage", garage);
        return t;
    }

    public static Account load(CompoundTag t) {
        Account a = new Account();
        a.id = t.getInt("id"); a.order = t.getInt("order");
        a.cash = t.getLong("cash"); a.bank = t.getLong("bank");
        a.job = t.getString("job");
        a.garage = t.getList("garage", Tag.TAG_COMPOUND);
        return a;
    }
}
