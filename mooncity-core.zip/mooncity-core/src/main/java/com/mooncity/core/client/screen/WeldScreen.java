package com.mooncity.core.client.screen;

import com.mooncity.core.client.Ui;
import com.mooncity.core.net.ActionPacket;
import com.mooncity.core.net.Net;
import net.minecraft.client.gui.GuiGraphics;

/** Minijoc sudor: tii cursorul pe linia ondulata cat se misca flacara. */
public class WeldScreen extends MoonScreen {
    private long start = -1;
    private int good, total;
    private boolean finished;
    private static final long DURATION = 9000;

    public WeldScreen() { super("STAȚIE DE SUDURĂ"); pw = 360; ph = 190; }

    @Override protected void build() { btn("Renunță", px + pw - 80, py + ph - 24, 70, b -> onClose()); }

    private double waveY(double t, int mid) { return mid + 34 * Math.sin(t * Math.PI * 2 * 2.5); }

    @Override
    protected void draw(GuiGraphics g, int mx, int my) {
        if (start < 0) start = System.currentTimeMillis();
        double t = Math.min(1.0, (System.currentTimeMillis() - start) / (double) DURATION);
        int left = px + 14, w = pw - 28, mid = py + 80;
        g.fill(left - 4, py + 26, left + w + 4, py + 134, 0xFF0F1530);
        for (int x = 0; x < w; x += 2) g.fill(left + x, (int) waveY(x / (double) w, mid), left + x + 2, (int) waveY(x / (double) w, mid) + 2, x / (double) w < t ? 0xFF22C55E : 0xFF445066);
        int tx = left + (int) (t * w), ty = (int) waveY(t, mid);
        g.fill(tx - 3, ty - 3, tx + 4, ty + 4, 0xFFFBBF24);
        boolean on = Math.abs(my - ty) < 14;
        if (!finished) { total++; if (on) good++; }
        g.fill(mx - 4, my - 4, mx + 5, my + 5, on ? 0xFF22D3EE : 0xFFFF5555);
        Ui.bar(g, left, py + 142, w, 6, t == 1.0 ? 1f : (float) t, 0xFF222844, 0xFF22D3EE);
        int score = total == 0 ? 0 : good * 100 / total;
        g.drawString(font, "Precizie: " + score + "%   Ține cursorul (punct albastru) pe linie.", left, py + 156, 0xFFDDDDDD, false);
        if (t >= 1.0 && !finished) {
            finished = true;
            Net.CH.sendToServer(new ActionPacket(ActionPacket.MINI_DONE, score, 0));
            minecraft.setScreen(null);
        }
    }
}
