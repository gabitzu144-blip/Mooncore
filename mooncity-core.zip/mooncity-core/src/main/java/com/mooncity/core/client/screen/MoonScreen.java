package com.mooncity.core.client.screen;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/** Baza comuna: fundal intunecat + titlu + butoane. */
public abstract class MoonScreen extends Screen {
    protected int pw = 260, ph = 200, px, py;

    protected MoonScreen(String title) { super(Component.literal(title)); }

    @Override
    protected void init() {
        px = (width - pw) / 2;
        py = (height - ph) / 2;
        build();
    }

    protected abstract void build();

    protected Button btn(String label, int x, int y, int w, Button.OnPress press) {
        return addRenderableWidget(Button.builder(Component.literal(label), press).bounds(x, y, w, 20).build());
    }

    @Override
    public boolean isPauseScreen() { return false; }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        renderBackground(g);
        g.fill(px, py, px + pw, py + ph, 0xE610142B);
        g.fill(px, py, px + pw, py + 2, 0xFFF5C518);
        g.drawCenteredString(font, title, px + pw / 2, py + 8, 0xFFF5C518);
        draw(g, mx, my);
        super.render(g, mx, my, pt);
    }

    protected void draw(GuiGraphics g, int mx, int my) { }
}
