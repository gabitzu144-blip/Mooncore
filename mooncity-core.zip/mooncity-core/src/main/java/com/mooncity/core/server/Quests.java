package com.mooncity.core.server;

import com.mooncity.core.data.Account;
import com.mooncity.core.data.MoonData;
import com.mooncity.core.net.Net;
import com.mooncity.core.net.ToastPacket;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.PacketDistributor;

public class Quests {
    public static final String[] TASKS = {
        "Vorbește cu Kevin",
        "Depune bani pe card (ATM sau bancher)",
        "Cumpără mâncare de la magazin",
        "Începe un job (K → Tabletă → Joburi)",
        "Cumpără un vehicul de la dealer"
    };
    public static final int[] REWARD = {200, 100, 100, 300, 500};

    public static void advance(ServerPlayer p, int expected) {
        MoonData d = MoonData.get(p.getServer());
        Account a = d.acc(p);
        if (a.quest != expected || expected >= TASKS.length) return;
        a.quest++;
        a.cash += REWARD[expected];
        d.setDirty();
        Net.CH.send(PacketDistributor.PLAYER.with(() -> p),
                new ToastPacket("Misiune completă: +" + REWARD[expected] + " lei", true));
    }

    public static void talk(ServerPlayer p) {
        MoonData d = MoonData.get(p.getServer());
        Account a = d.acc(p);
        if (a.quest == 0) {
            p.sendSystemMessage(Component.literal("[Kevin] Bun venit în MoonCity! Ia banii ăștia și învață orașul."));
            advance(p, 0);
            Sync.send(p);
        } else if (a.quest < TASKS.length) {
            p.sendSystemMessage(Component.literal("[Kevin] Următoarea ta sarcină: " + TASKS[a.quest]));
        } else {
            p.sendSystemMessage(Component.literal("[Kevin] Ai terminat toate misiunile. Spor la treabă!"));
        }
    }
}
