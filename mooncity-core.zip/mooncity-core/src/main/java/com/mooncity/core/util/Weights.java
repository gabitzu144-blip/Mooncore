package com.mooncity.core.util;

import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.*;

public class Weights {
    public static final double MAX = 60.0;

    public static double of(ItemStack s) {
        if (s.isEmpty()) return 0;
        Item i = s.getItem();
        double u;
        if (i instanceof ArmorItem) u = 2.5;
        else if (i instanceof TieredItem || i instanceof BowItem || i instanceof CrossbowItem || i instanceof TridentItem) u = 1.8;
        else if (s.isEdible()) u = 0.2;
        else if (i instanceof BlockItem) u = 0.3;
        else u = 0.1;
        return u * s.getCount();
    }

    public static double total(Player p) {
        double t = 0;
        for (ItemStack s : p.getInventory().items) t += of(s);
        for (ItemStack s : p.getInventory().armor) t += of(s);
        for (ItemStack s : p.getInventory().offhand) t += of(s);
        return t;
    }

    /** 1 mancare, 2 arme, 3 haine, 4 altele */
    public static int category(ItemStack s) {
        Item i = s.getItem();
        if (s.isEdible()) return 1;
        if (i instanceof SwordItem || i instanceof AxeItem || i instanceof BowItem || i instanceof CrossbowItem || i instanceof TridentItem) return 2;
        if (i instanceof ArmorItem) return 3;
        return 4;
    }
}
