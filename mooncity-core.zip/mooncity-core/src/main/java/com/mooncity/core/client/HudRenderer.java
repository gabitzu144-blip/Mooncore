package com.mooncity.core.client;

import com.mooncity.core.MoonCity;
import com.mooncity.core.data.Poi;
import com.mooncity.core.net.ClientState;
import com.mooncity.core.server.Jobs;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class HudRenderer {
    public static final ResourceLocation LOGO = new ResourceLocation(MoonCity.MODID, "textures/gui/logo.png");
    public static TerrainTexture mini;
    private static int tickCounter = 0;
    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    public static void tick() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null || !ClientState.showMinimap) return;
        if (++tickCounter % 10 != 0) return;
        if (mini == null) mini = new TerrainTexture("minimap", 150, 94);
        mini.render(mc.player.getBlockX(), mc.player.getBlockZ(), 1);
    }

    public static int poiColor(String type) {
        return switch (type) {
            case "garage" -> 0xFF55AAFF; case "job" -> 0xFFF5C518; case "shop" -> 0xFF55FF55;
            case "bank" -> 0xFFFFFFFF; case "fuel" -> 0xFFFF8800; case "delivery" -> 0xFFFF5555;
            case "spawn" -> 0xFFB06BFF; case "safezone" -> 0xFF22D3EE; case "dealer" -> 0xFFFF66CC;
            default -> 0xFFAAAAAA;
        };
    }

    private static String dist(double d) { return d >= 1000 ? String.format("%.2f km", d / 1000.0) : (int) d + " m"; }

    public static void render(GuiGraphics g, int w, int h) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null || mc.options.hideGui) return;
        Font f = mc.font;

        // ---------- dreapta: HP, cash, banca ----------
        int pw = 150, x = w - pw - 6, y = 6;
        Ui.panel(g, x, y, pw, 20);
        g.blit(LOGO, x + 2, y + 2, 16, 16, 0f, 0f, 128, 147, 128, 147);
        float hp = Mth.clamp(mc.player.getHealth() / mc.player.getMaxHealth(), 0f, 1f);
        Ui.bar(g, x + 22, y + 6, pw - 28, 8, hp, 0xFF3A1010, 0xFFE53935);
        g.drawString(f, "MOONCITY", x + 24, y + 6, 0xFFFFFFFF, true);
        y += 24;
        Ui.panel(g, x, y, pw, 28);
        g.drawString(f, "Cash", x + 4, y + 4, 0xFFAAAAAA, false);
        String cash = ClientState.cash + " lei";
        g.drawString(f, cash, x + pw - 4 - f.width(cash), y + 4, 0xFF55FF55, false);
        g.drawString(f, "Card", x + 4, y + 16, 0xFFAAAAAA, false);
        String bank = ClientState.bank + " lei";
        g.drawString(f, bank, x + pw - 4 - f.width(bank), y + 16, 0xFF55AAFF, false);
        y += 32;

        // job + nivel + progres
        Jobs j = Jobs.byKey(ClientState.job);
        if (j != null) {
            Ui.panel(g, x, y, pw, 40);
            g.drawString(f, j.label.toUpperCase() + "  NIV " + ClientState.jobLevel, x + 4, y + 4, 0xFF22D3EE, false);
            Ui.bar(g, x + 4, y + 15, pw - 8, 4, (float) ClientState.jobXp / Math.max(1, ClientState.jobNeed), 0xFF2A2F3A, 0xFF22D3EE);
            g.drawString(f, "Progres " + ClientState.jobXp + "/" + ClientState.jobNeed, x + 4, y + 21, 0xFFDDDDDD, false);
            long pay = Math.round(j.pay * (1.0 + 0.15 * (ClientState.jobLevel - 1)));
            g.drawString(f, "Plată: " + pay + " lei", x + 4, y + 31, 0xFF55FF55, false);
            y += 44;
        }

        // rank
        if (!ClientState.rankLabel.isEmpty()) {
            Ui.panel(g, x, y, pw, 14);
            g.drawString(f, ClientState.rankLabel.toUpperCase(), x + 4, y + 3, 0xFFF5C518, false);
            y += 18;
        }

        // ---------- stanga: minimap ----------
        if (ClientState.showMinimap) {
            int mx = 6, my = 6, mw = 150, mh = 94;
            g.fill(mx - 2, my - 2, mx + mw + 2, my + mh + 2, 0xFFF5C518);
            if (mini != null) mini.blit(g, mx, my, mw, mh); else g.fill(mx, my, mx + mw, my + mh, 0xFF101018);
            double px = mc.player.getX(), pz = mc.player.getZ();
            for (Poi p : ClientState.pois) {
                int sx = mx + mw / 2 + (int) (p.x() - px), sz = my + mh / 2 + (int) (p.z() - pz);
                if (sx > mx + 1 && sx < mx + mw - 3 && sz > my + 1 && sz < my + mh - 3) g.fill(sx - 1, sz - 1, sx + 2, sz + 2, poiColor(p.type()));
            }
            int tx = 0, tz = 0; boolean hasT = false; String tName = "";
            if (ClientState.hasWp) { tx = ClientState.wpX; tz = ClientState.wpZ; hasT = true; tName = ClientState.wpName; }
            else if (ClientState.hasTarget) { tx = ClientState.tx; tz = ClientState.tz; hasT = true; tName = "Livrare"; }
            if (hasT) {
                double dx = tx - px, dz = tz - pz;
                int sx = mx + mw / 2 + (int) Mth.clamp(dx, -mw / 2 + 4, mw / 2 - 4), sz = my + mh / 2 + (int) Mth.clamp(dz, -mh / 2 + 4, mh / 2 - 4);
                g.fill(sx - 2, sz - 2, sx + 3, sz + 3, 0xFFFF2030);
                String d = dist(Math.sqrt(dx * dx + dz * dz));
                g.drawString(f, d, mx + mw - 3 - f.width(d), my + mh - 20, 0xFFFFFFFF, true);
                g.drawString(f, tName, mx + mw - 3 - f.width(tName), my + mh - 10, 0xFFF5C518, true);
            }
            double yaw = Math.toRadians(mc.player.getYRot());
            int cx = mx + mw / 2, cz = my + mh / 2;
            g.fill(cx - 1, cz - 1, cx + 2, cz + 2, 0xFFFFFFFF);
            for (int k = 2; k < 6; k++) g.fill(cx + (int) (-Math.sin(yaw) * k), cz + (int) (Math.cos(yaw) * k), cx + (int) (-Math.sin(yaw) * k) + 1, cz + (int) (Math.cos(yaw) * k) + 1, 0xFFFFFFFF);
            g.drawString(f, "N", cx - 2, my + 1, 0xFFFFFFFF, true);

            // ID + ceas
            int by = my + mh + 6;
            Ui.panel(g, mx, by, 56, 16);
            g.drawString(f, "ID: " + ClientState.id, mx + 4, by + 4, 0xFFFFFFFF, false);
            long t = (mc.level.getDayTime() + 6000) % 24000;
            Ui.panel(g, mx + 60, by, 90, 16);
            g.drawString(f, String.format("%02d:%02d", t / 1000, (t % 1000) * 60 / 1000) + "  #" + ClientState.order, mx + 64, by + 4, 0xFFF5C518, false);

            // bare H A F W
            int sy = by + 22;
            String[] names = {"H", "A", "F", "W"};
            float[] vals = {hp, Mth.clamp(mc.player.getArmorValue() / 20f, 0f, 1f), mc.player.getFoodData().getFoodLevel() / 20f, ClientState.thirst / 100f};
            int[] cols = {0xFFE53935, 0xFF5B8DEF, 0xFFF59E0B, 0xFF22D3EE};
            for (int i = 0; i < 4; i++) {
                int bx = mx + i * 38;
                g.drawString(f, names[i], bx, sy, cols[i], true);
                Ui.bar(g, bx + 8, sy + 2, 26, 5, vals[i], 0xFF1A1A22, cols[i]);
            }
        }

        // ---------- sus mijloc: misiune ----------
        if (ClientState.showQuest && ClientState.quest < com.mooncity.core.server.Quests.TASKS.length && ClientState.created) {
            String task = com.mooncity.core.server.Quests.TASKS[ClientState.quest];
            int qw = Math.max(160, f.width(task) + 24), qx = w / 2 - qw / 2;
            Ui.panel(g, qx, 6, qw, 18);
            g.fill(qx + 6, 13, qx + 10, 17, 0xFFF5C518);
            g.drawString(f, task, qx + 16, 11, 0xFFFFFFFF, false);
        }

        // ---------- /anunt: banner sus, ca o notificare de telefon ----------
        if (System.currentTimeMillis() < ClientState.announceUntil) {
            var lines = f.split(net.minecraft.network.chat.Component.literal(ClientState.announce), 280);
            int bw = 300, bx = w / 2 - bw / 2, by = 30, bh = 22 + lines.size() * 10;
            g.fill(bx, by, bx + bw, by + bh, 0xEE10142B);
            g.fill(bx, by, bx + 3, by + bh, 0xFFF59E0B);
            g.drawString(f, "▮ MOONCITY • ANUNȚ", bx + 8, by + 4, 0xFFF59E0B, false);
            for (int i = 0; i < lines.size(); i++) g.drawString(f, lines.get(i), bx + 8, by + 16 + i * 10, 0xFFFFFFFF, false);
        }

        // ---------- jos mijloc: toast ----------
        if (System.currentTimeMillis() < ClientState.toastUntil) {
            String t = ClientState.toast;
            int tw = f.width(t) + 40, tx = w / 2 - tw / 2, ty = h - 70;
            Ui.panel(g, tx, ty, tw, 22);
            g.fill(tx, ty + 21, tx + tw, ty + 22, ClientState.toastGood ? 0xFF22C55E : 0xFFF59E0B);
            g.drawString(f, (ClientState.toastGood ? "✔ " : "! ") + t, tx + 14, ty + 7, 0xFFFFFFFF, false);
        }
    }
}
