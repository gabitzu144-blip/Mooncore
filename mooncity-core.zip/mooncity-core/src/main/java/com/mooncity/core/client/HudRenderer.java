package com.mooncity.core.client;

import com.mooncity.core.net.ClientState;
import com.mooncity.core.server.Jobs;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;

public class HudRenderer {
    private static void panel(GuiGraphics g, int x, int y, int w, int h) {
        g.fill(x, y, x + w, y + h, 0xCC10142B);
        g.fill(x, y, x + w, y + 1, 0xFFF5C518);
    }

    public static void render(GuiGraphics g, int w, int h) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui) return;
        Font f = mc.font;
        int pw = 140, x = w - pw - 6, y = 6;

        // bara de viata
        panel(g, x, y, pw, 16);
        float hp = Mth.clamp(mc.player.getHealth() / mc.player.getMaxHealth(), 0f, 1f);
        g.drawString(f, "HP", x + 4, y + 4, 0xFFE53935, false);
        g.fill(x + 22, y + 4, x + pw - 6, y + 12, 0xFF3A1010);
        g.fill(x + 22, y + 4, x + 22 + (int) ((pw - 28) * hp), y + 12, 0xFFE53935);
        y += 20;

        // cash + banca
        panel(g, x, y, pw, 28);
        g.drawString(f, "Cash:", x + 4, y + 4, 0xFFAAAAAA, false);
        String cash = ClientState.cash + " lei";
        g.drawString(f, cash, x + pw - 4 - f.width(cash), y + 4, 0xFF55FF55, false);
        g.drawString(f, "Bancă:", x + 4, y + 16, 0xFFAAAAAA, false);
        String bank = ClientState.bank + " lei";
        g.drawString(f, bank, x + pw - 4 - f.width(bank), y + 16, 0xFF55AAFF, false);
        y += 32;

        // ID, ordine, ora
        panel(g, x, y, pw, 28);
        g.drawString(f, "ID: " + ClientState.id, x + 4, y + 4, 0xFFFFFFFF, false);
        String ord = "#" + ClientState.order + " / " + Math.max(ClientState.total, ClientState.order);
        g.drawString(f, ord, x + pw - 4 - f.width(ord), y + 4, 0xFFF5C518, false);
        long t = (mc.level.getDayTime() + 6000) % 24000;
        String time = String.format("%02d:%02d", t / 1000, (t % 1000) * 60 / 1000);
        g.drawString(f, "Ora: " + time, x + 4, y + 16, 0xFFCCCCCC, false);
        y += 32;

        // job + tinta livrare
        Jobs j = Jobs.byKey(ClientState.job);
        if (j != null) {
            panel(g, x, y, pw, ClientState.hasTarget ? 28 : 16);
            g.drawString(f, "Job: " + j.label, x + 4, y + 4, 0xFFF5C518, false);
            if (ClientState.hasTarget) {
                double dx = mc.player.getX() - ClientState.tx, dz = mc.player.getZ() - ClientState.tz;
                g.drawString(f, "Livrare: " + (int) Math.sqrt(dx * dx + dz * dz) + " m", x + 4, y + 16, 0xFFFFFFFF, false);
            }
        }
    }
}
