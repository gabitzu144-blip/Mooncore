package com.mooncity.core.client;

import com.mojang.blaze3d.platform.NativeImage;
import com.mooncity.core.MoonCity;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;

/** Deseneaza terenul (culori de harta) din chunk-urile incarcate pe client. */
public class TerrainTexture {
    private final DynamicTexture tex;
    public final ResourceLocation rl;
    public final int w, h;
    private final int[] prev;

    public TerrainTexture(String name, int w, int h) {
        this.w = w; this.h = h;
        this.tex = new DynamicTexture(w, h, true);
        this.rl = new ResourceLocation(MoonCity.MODID, name);
        this.prev = new int[w];
        Minecraft.getInstance().getTextureManager().register(rl, tex);
    }

    public void render(int cx, int cz, int step) {
        ClientLevel lv = Minecraft.getInstance().level;
        NativeImage img = tex.getPixels();
        if (lv == null || img == null) return;
        BlockPos.MutableBlockPos mp = new BlockPos.MutableBlockPos();
        java.util.Arrays.fill(prev, -999);
        for (int j = 0; j < h; j++) {
            for (int i = 0; i < w; i++) {
                int x = cx + (i - w / 2) * step, z = cz + (j - h / 2) * step;
                if (!lv.hasChunk(x >> 4, z >> 4)) { img.setPixelRGBA(i, j, 0xFF18101A); prev[i] = -999; continue; }
                int y = lv.getHeight(Heightmap.Types.WORLD_SURFACE, x, z) - 1;
                mp.set(x, y, z);
                BlockState st = lv.getBlockState(mp);
                int col;
                if (!st.getFluidState().isEmpty()) col = 0x3F76E4;
                else { col = st.getMapColor(lv, mp).col; if (col == 0) col = 0x202020; }
                int py = prev[i];
                int shade = py == -999 ? 220 : (y > py ? 255 : (y < py ? 180 : 220));
                prev[i] = y;
                int r = ((col >> 16) & 255) * shade / 255, g = ((col >> 8) & 255) * shade / 255, b = (col & 255) * shade / 255;
                img.setPixelRGBA(i, j, 0xFF000000 | (b << 16) | (g << 8) | r);
            }
        }
        tex.upload();
    }

    public void blit(GuiGraphics g, int x, int y, int dw, int dh) {
        g.blit(rl, x, y, dw, dh, 0f, 0f, w, h, w, h);
    }
}
