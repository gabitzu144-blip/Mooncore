package com.mooncity.core.net;

import com.mooncity.core.block.SpeakerBE;
import com.mooncity.core.block.SpeakerBlock;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** op 0 = play, 1 = stop, 2 = strange boxa, 3 = doar volum */
public class SpeakerActionPacket {
    public final BlockPos pos; public final int op, track; public final float vol;
    public SpeakerActionPacket(BlockPos pos, int op, int track, float vol) { this.pos = pos; this.op = op; this.track = track; this.vol = vol; }
    public void encode(FriendlyByteBuf b) { b.writeBlockPos(pos); b.writeInt(op); b.writeInt(track); b.writeFloat(vol); }
    public static SpeakerActionPacket decode(FriendlyByteBuf b) { return new SpeakerActionPacket(b.readBlockPos(), b.readInt(), b.readInt(), b.readFloat()); }

    public static void handle(SpeakerActionPacket m, Supplier<NetworkEvent.Context> ctx) {
        ServerPlayer p = ctx.get().getSender();
        ctx.get().enqueueWork(() -> {
            if (p == null || p.distanceToSqr(m.pos.getX() + .5, m.pos.getY() + .5, m.pos.getZ() + .5) > 64) return;
            ServerLevel l = p.serverLevel();
            if (!(l.getBlockEntity(m.pos) instanceof SpeakerBE be)) return;
            float vol = Math.max(0f, Math.min(1f, m.vol));
            switch (m.op) {
                case 0 -> { be.track = m.track; be.volume = vol; be.playing = true; be.setChanged(); SpeakerBlock.broadcast(l, m.pos, 0, m.track, vol); }
                case 1 -> { be.playing = false; be.setChanged(); SpeakerBlock.broadcast(l, m.pos, 1, 0, 0); }
                case 2 -> {
                    SpeakerBlock.broadcast(l, m.pos, 1, 0, 0);
                    l.destroyBlock(m.pos, false);
                    ItemStack st = new ItemStack(com.mooncity.core.block.ModBlocks.SPEAKER_ITEM.get());
                    if (!p.getInventory().add(st)) p.drop(st, false);
                }
                default -> { be.volume = vol; be.setChanged(); }
            }
        });
        ctx.get().setPacketHandled(true);
    }
}
