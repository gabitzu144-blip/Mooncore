package com.mooncity.core.block;

import com.mooncity.core.net.Net;
import com.mooncity.core.net.OpenSpeakerPacket;
import com.mooncity.core.net.SpeakerSoundPacket;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraftforge.network.PacketDistributor;

public class SpeakerBlock extends BaseEntityBlock {
    public static final DirectionProperty FACING = BlockStateProperties.HORIZONTAL_FACING;
    private static final VoxelShape SHAPE = Block.box(3, 0, 5, 13, 10, 11);

    public SpeakerBlock(Properties p) {
        super(p);
        registerDefaultState(stateDefinition.any().setValue(FACING, Direction.NORTH));
    }

    @Override protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> b) { b.add(FACING); }
    @Override public BlockState getStateForPlacement(BlockPlaceContext c) { return defaultBlockState().setValue(FACING, c.getHorizontalDirection().getOpposite()); }
    @Override public VoxelShape getShape(BlockState s, BlockGetter g, BlockPos p, CollisionContext c) { return SHAPE; }
    @Override public RenderShape getRenderShape(BlockState s) { return RenderShape.MODEL; }
    @Override public BlockEntity newBlockEntity(BlockPos pos, BlockState state) { return new SpeakerBE(pos, state); }

    @Override
    public InteractionResult use(BlockState s, Level l, BlockPos pos, Player pl, InteractionHand h, BlockHitResult r) {
        if (!l.isClientSide && pl instanceof ServerPlayer sp && l.getBlockEntity(pos) instanceof SpeakerBE be)
            Net.CH.send(PacketDistributor.PLAYER.with(() -> sp), new OpenSpeakerPacket(pos, be.track, be.volume, be.playing));
        return InteractionResult.sidedSuccess(l.isClientSide);
    }

    @Override
    public void onRemove(BlockState s, Level l, BlockPos pos, BlockState n, boolean moved) {
        if (!l.isClientSide && s.getBlock() != n.getBlock() && l instanceof ServerLevel sl)
            broadcast(sl, pos, 1, 0, 0);
        super.onRemove(s, l, pos, n, moved);
    }

    public static void broadcast(ServerLevel l, BlockPos pos, int op, int track, float vol) {
        Net.CH.send(PacketDistributor.NEAR.with(() -> new PacketDistributor.TargetPoint(
                pos.getX() + .5, pos.getY() + .5, pos.getZ() + .5, 128, l.dimension())),
                new SpeakerSoundPacket(pos, op, track, vol));
    }
}
