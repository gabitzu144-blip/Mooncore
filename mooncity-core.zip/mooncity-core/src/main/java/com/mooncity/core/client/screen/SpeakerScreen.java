package com.mooncity.core.client.screen;

import com.mooncity.core.net.Net;
import com.mooncity.core.net.SpeakerActionPacket;
import com.mooncity.core.util.Tracks;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.client.gui.components.Button;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;

public class SpeakerScreen extends MoonScreen {
    private final BlockPos pos;
    private int track;
    private float vol;
    private boolean playing;

    public SpeakerScreen(BlockPos pos, int track, float vol, boolean playing) {
        super("BOXĂ PORTABILĂ JBL"); this.pos = pos; this.track = track; this.vol = vol; this.playing = playing; pw = 300; ph = 232;
    }

    private class VolSlider extends AbstractSliderButton {
        VolSlider(int x, int y, int w) { super(x, y, w, 18, Component.literal("Volum: " + Math.round(vol * 100) + "%"), vol); }
        @Override protected void updateMessage() { setMessage(Component.literal("Volum: " + Math.round(value * 100) + "%")); }
        @Override protected void applyValue() { vol = (float) value; }
        @Override public void onRelease(double mx, double my) {
            super.onRelease(mx, my);
            Net.CH.sendToServer(new SpeakerActionPacket(pos, 3, track, vol));
        }
    }

    @Override
    protected void build() {
        Button[] name = new Button[1];
        btn("<", px + 14, py + 54, 24, b -> { track = Math.floorMod(track - 1, Tracks.NAMES.length); name[0].setMessage(Component.literal(Tracks.NAMES[track])); });
        name[0] = btn(Tracks.NAMES[track], px + 42, py + 54, pw - 84, b -> { });
        btn(">", px + pw - 38, py + 54, 24, b -> { track = Math.floorMod(track + 1, Tracks.NAMES.length); name[0].setMessage(Component.literal(Tracks.NAMES[track])); });
        addRenderableWidget(new VolSlider(px + 14, py + 84, pw - 28));
        btn("▶ REDĂ", px + 14, py + 132, (pw - 36) / 2, b -> { playing = true; Net.CH.sendToServer(new SpeakerActionPacket(pos, 0, track, vol)); });
        btn("■ OPREȘTE", px + 22 + (pw - 36) / 2, py + 132, (pw - 36) / 2, b -> { playing = false; Net.CH.sendToServer(new SpeakerActionPacket(pos, 1, track, vol)); });
        btn("STRÂNGE BOXA", px + 14, py + 160, pw - 28, b -> { Net.CH.sendToServer(new SpeakerActionPacket(pos, 2, track, vol)); onClose(); });
        btn("Închide (ESC)", px + 14, py + 188, pw - 28, b -> onClose());
    }

    @Override
    protected void draw(GuiGraphics g, int mx, int my) {
        g.drawString(font, "AUDIO 3D — sunetul se aude în jurul boxei", px + 14, py + 22, 0xFF888888, false);
        g.drawString(font, "PIESĂ", px + 14, py + 42, 0xFFF5C518, false);
        g.drawString(font, playing ? "♪ Se redă muzica..." : "Oprit", px + 14, py + 112, playing ? 0xFFF5C518 : 0xFF888888, false);
    }
}
