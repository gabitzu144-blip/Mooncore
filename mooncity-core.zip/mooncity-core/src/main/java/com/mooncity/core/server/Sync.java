package com.mooncity.core.server;

import com.mooncity.core.data.Account;
import com.mooncity.core.data.MoonData;
import com.mooncity.core.net.Net;
import com.mooncity.core.net.SyncPacket;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.PacketDistributor;

import java.util.ArrayList;
import java.util.List;

public class Sync {
    public static void send(ServerPlayer p) {
        MoonData d = MoonData.get(p.getServer());
        Account a = d.acc(p);
        List<String> names = new ArrayList<>();
        for (Tag t : a.garage) names.add(((CompoundTag) t).getString("name"));
        BlockPos tg = JobEvents.targets.get(p.getUUID());
        Net.CH.send(PacketDistributor.PLAYER.with(() -> p), new SyncPacket(
                a.id, a.order, d.nextOrder - 1, a.cash, a.bank, a.job,
                tg != null, tg != null ? tg.getX() : 0, tg != null ? tg.getZ() : 0,
                new ArrayList<>(d.pois), names));
    }

    public static void sendAll(net.minecraft.server.MinecraftServer s) {
        for (ServerPlayer p : s.getPlayerList().getPlayers()) send(p);
    }
}
