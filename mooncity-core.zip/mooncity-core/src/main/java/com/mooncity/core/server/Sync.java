package com.mooncity.core.server;

import com.mooncity.core.data.Account;
import com.mooncity.core.data.MoonData;
import com.mooncity.core.net.Net;
import com.mooncity.core.net.SyncPacket;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.PacketDistributor;

import java.util.ArrayList;

public class Sync {
    public static void send(ServerPlayer p) {
        MoonData d = MoonData.get(p.getServer());
        Account a = d.acc(p);
        SyncPacket m = new SyncPacket();
        m.id = a.id; m.order = a.order; m.total = d.nextOrder - 1;
        m.cash = a.cash; m.bank = a.bank; m.job = a.job;
        BlockPos tg = JobEvents.targets.get(p.getUUID());
        m.hasTarget = tg != null;
        if (tg != null) { m.tx = tg.getX(); m.tz = tg.getZ(); }
        m.pois = new ArrayList<>(d.pois);
        for (Tag t : a.garage) m.garage.add(((CompoundTag) t).getString("name"));
        m.first = a.first; m.last = a.last; m.sex = a.sex; m.age = a.age; m.created = a.created;
        m.level = a.level; m.progress = a.progress; m.quest = a.quest; m.phone = a.phone(); m.license = a.license;
        m.secondsToReward = 3600 - (a.playSeconds % 3600);
        m.thirst = a.thirst; m.rankLabel = a.rankLabel; m.rankColor = a.rankColor;
        m.staff = a.staff || p.hasPermissions(2); m.duty = a.duty; m.owner = p.hasPermissions(4);
        m.hasPin = !a.pin.isEmpty(); m.licenseGun = a.licenseGun; m.faction = a.faction; m.factionLeader = a.factionLeader; m.fgAccess = a.fgAccess || a.factionLeader;
        long now = System.currentTimeMillis(); m.insAuto = a.insAuto > now; m.insHome = a.insHome > now;
        Jobs j = Jobs.byKey(a.job);
        if (j != null) { m.jobLevel = a.jobLevel(j.key); m.jobXp = a.jobXp(j.key); m.jobNeed = Account.xpNeeded(m.jobLevel); }
        else { m.jobLevel = 1; m.jobXp = 0; m.jobNeed = Account.xpNeeded(1); }
        Net.CH.send(PacketDistributor.PLAYER.with(() -> p), m);
    }

    public static void sendAll(MinecraftServer s) {
        for (ServerPlayer p : s.getPlayerList().getPlayers()) send(p);
    }
}
