package com.mooncity.core.client.screen;

import com.mooncity.core.client.HudRenderer;
import com.mooncity.core.client.TerrainTexture;
import com.mooncity.core.client.Ui;
import com.mooncity.core.data.Poi;
import com.mooncity.core.net.ClientState;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

/** Harta mare (tasta M): teren real din chunk-urile incarcate, puncte de interes, GPS. */
public class MapScreen extends Screen {
    private static TerrainTexture tex;
    private int cx, cz, step = 2, ticks = 0, lastCx = Integer.MIN_VALUE, lastCz, lastStep;
    private int dw, dh, x0, y0;

    public MapScreen() { super(Component.literal("HARTĂ")); }

    @Override public boolean isPauseScreen() { return false; }

    @Override
    protected void init() {
        if (tex == null) tex = new TerrainTexture("bigmap", 256, 160);
        cx = minecraft.player.getBlockX(); cz = minecraft.player.getBlockZ();
        recalc();
        addRenderableWidget(net.minecraft.client.gui.components.Button.builder(Component.literal("+"), b -> { step = Math.max(1, step / 2); }).bounds(8, height - 26, 22, 18).build());
        addRenderableWidget(net.minecraft.client.gui.components.Button.builder(Component.literal("-"), b -> { step = Math.min(8, step * 2); }).bounds(34, height - 26, 22, 18).build());
        addRenderableWidget(net.minecraft.client.gui.components.Button.builder(Component.literal("Centrează"), b -> { cx = minecraft.player.getBlockX(); cz = minecraft.player.getBlockZ(); }).bounds(60, height - 26, 70, 18).build());
        addRenderableWidget(net.minecraft.client.gui.components.Button.builder(Component.literal("Oprește GPS"), b -> ClientState.hasWp = false).bounds(134, height - 26, 80, 18).build());
        addRenderableWidget(net.minecraft.client.gui.components.Button.builder(Component.literal("Închide"), b -> onClose()).bounds(width - 70, height - 26, 62, 18).build());
    }

    private void recalc() {
        dw = Math.min(width - 24, (height - 60) * 256 / 160);
        dh = dw * 160 / 256;
        x0 = (width - dw) / 2; y0 = 8;
    }

    @Override
    public void tick() {
        recalc();
        if (ticks++ % 40 == 0 || cx != lastCx || cz != lastCz || step != lastStep) {
            tex.render(cx, cz, step);
            lastCx = cx; lastCz = cz; lastStep = step;
        }
    }

    private double scale() { return (double) dw / (256.0 * step); } // pixeli ecran per bloc

    private int sx(double wx) { return x0 + dw / 2 + (int) ((wx - cx) * scale()); }
    private int sz(double wz) { return y0 + dh / 2 + (int) ((wz - cz) * scale()); }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        g.fill(0, 0, width, height, 0xFF0B0F18);
        g.fill(x0 - 2, y0 - 2, x0 + dw + 2, y0 + dh + 2, 0xFFF5C518);
        tex.blit(g, x0, y0, dw, dh);
        g.enableScissor(x0, y0, x0 + dw, y0 + dh);
        String hover = null;
        for (Poi p : ClientState.pois) {
            int px = sx(p.x()), pz = sz(p.z());
            if (p.type().equals("safezone")) Ui.disc(g, px, pz, 5, 0x6622D3EE);
            g.fill(px - 3, pz - 3, px + 4, pz + 4, 0xFF000000);
            g.fill(px - 2, pz - 2, px + 3, pz + 3, HudRenderer.poiColor(p.type()));
            if (Math.abs(mx - px) <= 5 && Math.abs(my - pz) <= 5) hover = "[" + p.type() + "] " + p.name();
        }
        if (ClientState.hasWp) { int px = sx(ClientState.wpX), pz = sz(ClientState.wpZ); g.fill(px - 3, pz - 3, px + 4, pz + 4, 0xFFFF2030); }
        if (ClientState.hasTarget) { int px = sx(ClientState.tx), pz = sz(ClientState.tz); g.fill(px - 3, pz - 3, px + 4, pz + 4, 0xFFFF8800); }
        int ppx = sx(minecraft.player.getX()), ppz = sz(minecraft.player.getZ());
        g.fill(ppx - 3, ppz - 3, ppx + 4, ppz + 4, 0xFF000000);
        g.fill(ppx - 2, ppz - 2, ppx + 3, ppz + 3, 0xFFFFFFFF);
        double yaw = Math.toRadians(minecraft.player.getYRot());
        for (int k = 4; k < 10; k++) g.fill(ppx + (int) (-Math.sin(yaw) * k), ppz + (int) (Math.cos(yaw) * k), ppx + (int) (-Math.sin(yaw) * k) + 2, ppz + (int) (Math.cos(yaw) * k) + 2, 0xFFFFFFFF);
        g.disableScissor();
        super.render(g, mx, my, pt);
        g.drawString(font, "1 px = " + String.format("%.1f", 1.0 / scale()) + " blocuri   Centru: X " + cx + "  Z " + cz
                + "   |   Click stânga pe punct = GPS, click dreapta = GPS oriunde, trage = mută", 220, height - 21, 0xFFAAAAAA, false);
        if (hover != null) g.drawString(font, hover, mx + 8, my - 4, 0xFFFFFFFF, true);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int btn, double dx, double dy) {
        if (btn == 0 && mx > x0 && mx < x0 + dw && my > y0 && my < y0 + dh) {
            cx -= (int) Math.round(dx / scale()); cz -= (int) Math.round(dy / scale());
            return true;
        }
        return super.mouseDragged(mx, my, btn, dx, dy);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double delta) {
        if (delta > 0) step = Math.max(1, step / 2); else step = Math.min(8, step * 2);
        return true;
    }

    @Override
    public boolean mouseClicked(double mx, double my, int btn) {
        if (super.mouseClicked(mx, my, btn)) return true;
        if (mx < x0 || mx > x0 + dw || my < y0 || my > y0 + dh) return false;
        if (btn == 0) {
            for (Poi p : ClientState.pois)
                if (Math.abs(mx - sx(p.x())) <= 5 && Math.abs(my - sz(p.z())) <= 5) {
                    ClientState.hasWp = true; ClientState.wpX = p.x(); ClientState.wpZ = p.z(); ClientState.wpName = p.name();
                    return true;
                }
        } else if (btn == 1) {
            ClientState.hasWp = true;
            ClientState.wpX = cx + (int) ((mx - x0 - dw / 2.0) / scale());
            ClientState.wpZ = cz + (int) ((my - y0 - dh / 2.0) / scale());
            ClientState.wpName = "Punct GPS";
            return true;
        }
        return false;
    }

    @Override
    public boolean keyPressed(int key, int sc, int mod) {
        if (key == GLFW.GLFW_KEY_M) { onClose(); return true; }
        return super.keyPressed(key, sc, mod);
    }
}
