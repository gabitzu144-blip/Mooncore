package com.mooncity.core.client.screen;

import com.mooncity.core.data.Poi;
import com.mooncity.core.net.ClientState;
import net.minecraft.client.gui.GuiGraphics;

/** Harta schematica: puncte de interes (setate de owner cu /mc poi) in jurul tau. */
public class MapScreen extends MoonScreen {
    private double blocksPerPx = 2.0;

    public MapScreen() { super("HARTĂ"); pw = 300; ph = 240; }

    @Override
    protected void build() {
        btn("+", px + 10, py + ph - 26, 24, b -> blocksPerPx = Math.max(0.25, blocksPerPx / 2));
        btn("-", px + 38, py + ph - 26, 24, b -> blocksPerPx = Math.min(256, blocksPerPx * 2));
        btn("Închide", px + pw - 90, py + ph - 26, 80, b -> onClose());
    }

    private static int color(String type) {
        return switch (type) {
            case "garage" -> 0xFF55AAFF;
            case "job" -> 0xFFF5C518;
            case "shop" -> 0xFF55FF55;
            case "bank" -> 0xFFFFFFFF;
            case "fuel" -> 0xFFFF8800;
            case "delivery" -> 0xFFFF5555;
            default -> 0xFFAAAAAA;
        };
    }

    @Override
    protected void draw(GuiGraphics g, int mx, int my) {
        int x0 = px + 8, y0 = py + 22, x1 = px + pw - 8, y1 = py + ph - 34;
        g.fill(x0, y0, x1, y1, 0xFF1E2230);
        int cx = (x0 + x1) / 2, cz = (y0 + y1) / 2;
        double ppx = minecraft.player.getX(), ppz = minecraft.player.getZ();
        g.enableScissor(x0, y0, x1, y1);
        String hover = null;
        for (Poi p : ClientState.pois) {
            int sx = cx + (int) ((p.x() - ppx) / blocksPerPx), sz = cz + (int) ((p.z() - ppz) / blocksPerPx);
            g.fill(sx - 2, sz - 2, sx + 3, sz + 3, color(p.type()));
            if (Math.abs(mx - sx) <= 4 && Math.abs(my - sz) <= 4) hover = p.type() + ": " + p.name();
        }
        if (ClientState.hasTarget) {
            int sx = cx + (int) ((ClientState.tx - ppx) / blocksPerPx), sz = cz + (int) ((ClientState.tz - ppz) / blocksPerPx);
            g.fill(sx - 3, sz - 3, sx + 4, sz + 4, 0xFFFF0000);
        }
        g.fill(cx - 2, cz - 2, cx + 3, cz + 3, 0xFFFFFFFF);
        g.disableScissor();
        g.drawString(font, "1 px = " + blocksPerPx + " blocuri   X " + (int) ppx + "  Z " + (int) ppz, x0 + 2, y1 + 4, 0xFFAAAAAA, false);
        if (hover != null) g.drawString(font, hover, mx + 8, my - 4, 0xFFFFFFFF, true);
    }
}
