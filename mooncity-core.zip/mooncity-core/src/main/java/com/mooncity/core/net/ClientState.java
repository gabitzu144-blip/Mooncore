package com.mooncity.core.net;

import com.mooncity.core.data.Poi;

import java.util.ArrayList;
import java.util.List;

/** Starea primita de la server (folosita de HUD si ecrane). */
public class ClientState {
    public static int id, order, total;
    public static long cash, bank;
    public static String job = "";
    public static boolean hasTarget;
    public static int tx, tz;
    public static List<Poi> pois = new ArrayList<>();
    public static List<String> garage = new ArrayList<>();

    public static void apply(SyncPacket m) {
        id = m.id; order = m.order; total = m.total;
        cash = m.cash; bank = m.bank; job = m.job;
        hasTarget = m.hasTarget; tx = m.tx; tz = m.tz;
        pois = m.pois; garage = m.garage;
    }
}
