package com.mooncity.core.net;

import com.mooncity.core.data.Poi;

import java.util.*;

/** Starea primita de la server (HUD + ecrane) si setari locale. */
public class ClientState {
    public static int id, order, total, age, level, progress, quest, thirst = 100, jobLevel = 1, jobXp, jobNeed = 38, factionRank;
    public static long cash, bank;
    public static long secondsToReward = 3600, receivedAt = System.currentTimeMillis();
    public static String job = "", first = "", last = "", sex = "M", phone = "", rankLabel = "", rankColor = "white", faction = "";
    public static boolean created, license, hasTarget, staff, duty, owner, hasPin, licenseGun, insAuto, insHome, factionLeader, fgAccess;
    public static int tx, tz;
    public static List<Poi> pois = new ArrayList<>();
    public static List<String> garage = new ArrayList<>();
    public static final Map<Integer, List<String>> lists = new HashMap<>();

    // local only
    public static boolean showMinimap = true, showQuest = true;
    public static String wpName = "";
    public static int wpX, wpZ;
    public static boolean hasWp;
    public static String toast = "";
    public static boolean toastGood;
    public static long toastUntil;
    public static String announce = "";
    public static long announceUntil;
    public static final java.util.Map<java.util.UUID, Integer> neon = new java.util.HashMap<>();

    public static List<String> list(int kind) { return lists.getOrDefault(kind, List.of()); }

    public static long rewardLeft() {
        return Math.max(0, secondsToReward - (System.currentTimeMillis() - receivedAt) / 1000);
    }

    public static void apply(SyncPacket m) {
        id = m.id; order = m.order; total = m.total; cash = m.cash; bank = m.bank; job = m.job;
        hasTarget = m.hasTarget; tx = m.tx; tz = m.tz; pois = m.pois; garage = m.garage;
        first = m.first; last = m.last; sex = m.sex; age = m.age; created = m.created;
        level = m.level; progress = m.progress; quest = m.quest; phone = m.phone; license = m.license;
        thirst = m.thirst; jobLevel = m.jobLevel; jobXp = m.jobXp; jobNeed = m.jobNeed;
        rankLabel = m.rankLabel; rankColor = m.rankColor; staff = m.staff; duty = m.duty; owner = m.owner;
        hasPin = m.hasPin; licenseGun = m.licenseGun; insAuto = m.insAuto; insHome = m.insHome; faction = m.faction; factionLeader = m.factionLeader; fgAccess = m.fgAccess; factionRank = m.factionRank;
        secondsToReward = m.secondsToReward; receivedAt = System.currentTimeMillis();
    }
}
