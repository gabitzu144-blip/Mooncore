package com.mooncity.core.client.screen;

import com.mooncity.core.net.ClientState;
import com.mooncity.core.server.Quests;

import java.util.ArrayList;
import java.util.List;

public class TasksScreen extends InfoScreen {
    public TasksScreen() {
        super("MISIUNI", () -> {
            List<String> l = new ArrayList<>();
            for (int i = 0; i < Quests.TASKS.length; i++)
                l.add((i < ClientState.quest ? "[✔] " : i == ClientState.quest ? "[►] " : "[ ] ") + Quests.TASKS[i] + "  (+" + Quests.REWARD[i] + " lei)");
            if (ClientState.quest >= Quests.TASKS.length) l.add("Toate misiunile sunt terminate!");
            return l;
        });
        pw = 340;
    }
}
