package com.mooncity.core.client.screen;

import com.mooncity.core.net.ActionPacket;
import com.mooncity.core.net.ClientState;
import com.mooncity.core.net.Net;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.network.chat.Component;

import java.util.List;

public class InsuranceScreen extends MoonScreen {
    private EditBox amount, desc;
    private boolean casa = false;
    private int ticks, lastHash;

    public InsuranceScreen() { super("ASIGURĂRI ȘI DAUNE"); pw = 380; ph = 256; }

    @Override
    protected void build() {
        btn("Cumpără asigurare AUTO (500 lei / 30 zile)", px + 10, py + 40, pw - 20, b -> Net.CH.sendToServer(new ActionPacket(ActionPacket.INS_BUY, 0, 0)));
        btn("Cumpără asigurare CASĂ (800 lei / 30 zile)", px + 10, py + 64, pw - 20, b -> Net.CH.sendToServer(new ActionPacket(ActionPacket.INS_BUY, 1, 0)));
        btn("Dosar pentru: " + (casa ? "CASĂ" : "AUTO"), px + 10, py + 94, 130, b -> { casa = !casa; rebuildWidgets(); });
        amount = new EditBox(font, px + 144, py + 94, 70, 20, Component.literal("Sumă"));
        amount.setHint(Component.literal("Sumă")); amount.setFilter(s -> s.matches("\\d*")); amount.setMaxLength(6);
        addRenderableWidget(amount);
        desc = new EditBox(font, px + 10, py + 118, pw - 20, 18, Component.literal("Descriere"));
        desc.setHint(Component.literal("Descrie dauna (accident, furt, incendiu...)")); desc.setMaxLength(160);
        addRenderableWidget(desc);
        btn("Depune dosar de daună", px + 10, py + 140, pw - 20, b -> {
            if (amount.getValue().isEmpty() || desc.getValue().isBlank()) return;
            Net.CH.sendToServer(new ActionPacket(ActionPacket.CLAIM_FILE, Integer.parseInt(amount.getValue()), 0, (casa ? "casa" : "auto") + "|" + desc.getValue()));
        });
        btn("Închide", px + pw - 90, py + ph - 26, 80, b -> onClose());
    }

    @Override
    public void tick() { if (ticks++ % 50 == 0) Net.CH.sendToServer(new ActionPacket(ActionPacket.REQ, 13, 0)); }

    @Override
    protected void draw(GuiGraphics g, int mx, int my) {
        g.drawString(font, "Auto: " + (ClientState.insAuto ? "ACTIVĂ" : "inactivă") + "    Casă: " + (ClientState.insHome ? "ACTIVĂ" : "inactivă"), px + 12, py + 26, 0xFFFFFFFF, false);
        g.drawString(font, "Acoperire max: AUTO 5.000 lei, CASĂ 15.000 lei. Poliția aprobă dosarele.", px + 12, py + 168, 0xFF888888, false);
        List<String> rows = ClientState.list(13);
        for (int i = 0; i < Math.min(4, rows.size()); i++) {
            String[] p = rows.get(i).split("\\|", 6);
            String st = p[4].equals("0") ? "în așteptare" : p[4].equals("1") ? "APROBAT" : "RESPINS";
            g.drawString(font, font.plainSubstrByWidth("#" + p[0] + " " + p[2] + " " + p[3] + " lei — " + st + " — " + (p.length > 5 ? p[5] : ""), pw - 24),
                    px + 12, py + 182 + i * 11, p[4].equals("1") ? 0xFF55FF55 : p[4].equals("2") ? 0xFFFF5555 : 0xFFF5C518, false);
        }
    }
}
