package com.mooncity.core.client;

import com.mooncity.core.client.screen.*;
import net.minecraft.client.Minecraft;

public class ClientHooks {
    public static void open(int which) {
        Minecraft mc = Minecraft.getInstance();
        switch (which) {
            case 0 -> mc.setScreen(new BankScreen());
            case 1 -> mc.setScreen(new ShopScreen());
            case 2 -> mc.setScreen(new FuelScreen());
            default -> { }
        }
    }
}
