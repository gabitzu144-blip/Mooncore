package com.mooncity.core.client;

import com.mooncity.core.client.screen.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.client.sounds.SoundManager;
import net.minecraft.core.BlockPos;
import net.minecraft.sounds.SoundSource;
import com.mooncity.core.util.Tracks;

import java.util.HashMap;
import java.util.Map;

public class ClientHooks {
    private static final Map<BlockPos, SoundInstance> PLAYING = new HashMap<>();

    public static void open(int which) {
        Minecraft mc = Minecraft.getInstance();
        if (which >= 1000) { mc.setScreen(new ShopScreen(which - 1000)); return; }
        switch (which) {
            case 0 -> mc.setScreen(new BankScreen());
            case 2 -> mc.setScreen(new FuelScreen());
            case 4 -> mc.setScreen(new DealerScreen());
            case 10 -> mc.setScreen(new CharacterCreationScreen());
            case 11 -> mc.setScreen(new SpawnScreen());
            case 20 -> mc.setScreen(new TicketsScreen());
            case 30 -> mc.setScreen(new MdtScreen());
            case 31 -> mc.setScreen(new PinScreen());
            default -> { }
        }
    }

    public static void openSpeaker(BlockPos pos, int track, float vol, boolean playing) {
        Minecraft.getInstance().setScreen(new SpeakerScreen(pos, track, vol, playing));
    }

    public static void speakerSound(BlockPos pos, int op, int track, float vol) {
        SoundManager sm = Minecraft.getInstance().getSoundManager();
        SoundInstance old = PLAYING.remove(pos);
        if (old != null) sm.stop(old);
        if (op != 0) return;
        SimpleSoundInstance si = new SimpleSoundInstance(Tracks.get(track).getLocation(), SoundSource.RECORDS,
                Math.max(0.1f, vol) * 3f, 1f, SoundInstance.createUnseededRandom(), false, 0,
                SoundInstance.Attenuation.LINEAR, pos.getX() + .5, pos.getY() + .5, pos.getZ() + .5, false);
        sm.play(si);
        PLAYING.put(pos, si);
    }
}
