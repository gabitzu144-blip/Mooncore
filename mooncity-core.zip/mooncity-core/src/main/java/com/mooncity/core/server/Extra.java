package com.mooncity.core.server;

import com.mooncity.core.data.Account;
import com.mooncity.core.data.MoonData;
import com.mooncity.core.data.Poi;
import com.mooncity.core.net.*;
import com.mooncity.core.util.VehicleUtil;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.PacketDistributor;

import java.util.*;

/** MDT, PIN, asigurari, case, garaje de factiune, mecanic cu piese, neon. */
public class Extra {
    private static final Map<UUID, Long> pinOk = new HashMap<>();
    private static final String[] KIND = {"auto", "casa"};
    private static final int[] INS_PRICE = {500, 800};
    private static final int[] INS_COVER = {5000, 15000};
    private static final long DAY = 86400000L;

    // ---------- helpers ----------
    public static boolean pinUnlocked(ServerPlayer p) { return System.currentTimeMillis() - pinOk.getOrDefault(p.getUUID(), 0L) < 180000; }
    public static boolean isPolice(Account a) { return a.faction.equalsIgnoreCase("politie"); }
    public static boolean isPolicePlayer(ServerPlayer p) { return isPolice(MoonData.get(p.getServer()).acc(p)); }

    private static void toast(ServerPlayer p, String s, boolean good) { Actions.toast(p, s, good); }

    private static Account accById(MoonData d, int id) {
        for (Account a : d.accounts.values()) if (a.id == id) return a;
        return null;
    }

    private static String nameOf(MoonData d, int id) {
        Account a = accById(d, id);
        return a == null ? "?" : a.displayName(a.mcName.isEmpty() ? "#" + id : a.mcName);
    }

    private static void notifyFaction(MinecraftServer s, MoonData d, String faction, String text) {
        for (ServerPlayer sp : s.getPlayerList().getPlayers())
            if (d.acc(sp).faction.equalsIgnoreCase(faction)) toast(sp, text, true);
    }

    /** Esti intr-o zona de garaj cu numele dat? Daca nu exista nicio zona cu acel nume, se permite oriunde (doar pentru "personal"). */
    public static boolean zoneOk(MoonData d, ServerPlayer p, String name) {
        boolean any = false;
        for (Tag t : d.garageZones) {
            CompoundTag z = (CompoundTag) t;
            if (!z.getString("name").equalsIgnoreCase(name)) continue;
            any = true;
            double dx = p.getX() - z.getInt("x"), dz = p.getZ() - z.getInt("z");
            if (dx * dx + dz * dz <= (double) z.getInt("r") * z.getInt("r") && Math.abs(p.getY() - z.getInt("y")) < 20) return true;
        }
        return !any && name.equalsIgnoreCase("personal");
    }

    private static Set<String> installed(MoonData d, UUID veh) {
        String s = d.parts.getOrDefault(veh, "");
        return new HashSet<>(s.isEmpty() ? List.of() : Arrays.asList(s.split(",")));
    }

    private static void saveParts(MoonData d, UUID veh, Set<String> set) { d.parts.put(veh, String.join(",", set)); d.setDirty(); }

    // ---------- actiuni ----------
    public static void handle(ServerPlayer p, MoonData d, Account acc, int type, int a, int b, String s) {
        long now = System.currentTimeMillis();
        switch (type) {
            case ActionPacket.PIN_SET -> {
                if (!acc.pin.isEmpty() || s == null || !s.matches("\\d{4}")) { toast(p, "PIN invalid (4 cifre).", false); break; }
                acc.pin = s;
                pinOk.put(p.getUUID(), now);
                toast(p, "PIN setat.", true);
                Net.CH.send(PacketDistributor.PLAYER.with(() -> p), new OpenScreenPacket(0));
            }
            case ActionPacket.PIN_CHECK -> {
                if (!acc.pin.isEmpty() && acc.pin.equals(s)) {
                    pinOk.put(p.getUUID(), now);
                    Net.CH.send(PacketDistributor.PLAYER.with(() -> p), new OpenScreenPacket(0));
                } else toast(p, "PIN greșit.", false);
            }
            case ActionPacket.WANT_ADD -> {
                if (!isPolice(acc)) break;
                Account t = accById(d, a);
                String reason = clean(s, 80);
                if (t == null || reason.isEmpty()) { toast(p, "ID sau motiv invalid.", false); break; }
                CompoundTag w = new CompoundTag();
                w.putInt("target", a); w.putString("reason", reason);
                w.putString("by", acc.displayName(p.getName().getString())); w.putLong("ts", now);
                d.wanted.add(w);
                notifyFaction(p.getServer(), d, "politie", "Nou căutat: #" + a + " — " + reason);
            }
            case ActionPacket.WANT_DEL -> {
                if (!isPolice(acc)) break;
                for (int i = d.wanted.size() - 1; i >= 0; i--) if (d.wanted.getCompound(i).getInt("target") == a) d.wanted.remove(i);
            }
            case ActionPacket.REC_ADD -> {
                if (acc.faction.isEmpty()) break;
                String text = clean(s, 200);
                if (accById(d, a) == null || text.isEmpty()) { toast(p, "ID sau text invalid.", false); break; }
                CompoundTag r = new CompoundTag();
                r.putString("faction", acc.faction.toLowerCase()); r.putInt("target", a); r.putString("text", text);
                r.putString("by", acc.displayName(p.getName().getString())); r.putLong("ts", now);
                d.records.add(r);
                toast(p, "Dosar adăugat.", true);
            }
            case ActionPacket.DISP_CALL -> {
                String text = clean(s, 120);
                if (text.isEmpty()) break;
                CompoundTag c = new CompoundTag();
                c.putInt("id", d.nextDispatchId++); c.putString("text", acc.displayName(p.getName().getString()) + ": " + text);
                c.putInt("x", p.getBlockX()); c.putInt("z", p.getBlockZ()); c.putLong("ts", now); c.putBoolean("open", true);
                d.dispatches.add(c);
                while (d.dispatches.size() > 30) d.dispatches.remove(0);
                notifyFaction(p.getServer(), d, "politie", "Apel 112: " + text);
                toast(p, "Apelul a fost trimis la poliție.", true);
            }
            case ActionPacket.DISP_CLOSE -> {
                if (!isPolice(acc)) break;
                for (Tag t : d.dispatches) if (((CompoundTag) t).getInt("id") == a) ((CompoundTag) t).putBoolean("open", false);
            }
            case ActionPacket.INS_BUY -> {
                if (a < 0 || a > 1) break;
                if (!acc.spend(INS_PRICE[a])) { toast(p, "Nu ai destui lei (" + INS_PRICE[a] + ").", false); break; }
                long exp = Math.max(now, a == 0 ? acc.insAuto : acc.insHome) + 30 * DAY;
                if (a == 0) acc.insAuto = exp; else acc.insHome = exp;
                acc.addTx("Asigurare " + KIND[a] + " -" + INS_PRICE[a]);
                toast(p, "Asigurare " + KIND[a] + " activă 30 zile.", true);
            }
            case ActionPacket.CLAIM_FILE -> {
                String[] f = (s == null ? "" : s).split("\\|", 2);
                int k = f.length > 0 && f[0].equals("casa") ? 1 : 0;
                long exp = k == 0 ? acc.insAuto : acc.insHome;
                String desc = clean(f.length > 1 ? f[1] : "", 160);
                if (exp < now) { toast(p, "Nu ai asigurare " + KIND[k] + " activă.", false); break; }
                if (desc.isEmpty() || a <= 0 || a > INS_COVER[k]) { toast(p, "Sumă (max " + INS_COVER[k] + ") și descriere necesare.", false); break; }
                CompoundTag c = new CompoundTag();
                c.putInt("id", d.nextClaimId++); c.putUUID("owner", p.getUUID());
                c.putString("ownerName", acc.displayName(p.getName().getString())); c.putInt("ownerId", acc.id);
                c.putString("kind", KIND[k]); c.putString("desc", desc); c.putInt("amount", a); c.putInt("status", 0); c.putLong("ts", now);
                d.claims.add(c);
                notifyFaction(p.getServer(), d, "politie", "Dosar de daună nou #" + c.getInt("id"));
                toast(p, "Dosar de daună depus.", true);
            }
            case ActionPacket.CLAIM_DECIDE -> {
                if (!isPolice(acc) && !(acc.staff || p.hasPermissions(2))) break;
                for (Tag t : d.claims) {
                    CompoundTag c = (CompoundTag) t;
                    if (c.getInt("id") != a || c.getInt("status") != 0) continue;
                    c.putInt("status", b == 1 ? 1 : 2);
                    if (b == 1) {
                        Account o = d.accounts.get(c.getUUID("owner"));
                        if (o != null) { o.bank += c.getInt("amount"); o.addTx("Despăgubire +" + c.getInt("amount")); }
                        ServerPlayer op = p.getServer().getPlayerList().getPlayer(c.getUUID("owner"));
                        if (op != null) { toast(op, "Despăgubire aprobată: +" + c.getInt("amount") + " lei", true); Sync.send(op); }
                    }
                    toast(p, "Dosar #" + a + (b == 1 ? " aprobat." : " respins."), true);
                }
            }
            case ActionPacket.HOUSE_BUY -> {
                for (Tag t : d.houses) {
                    CompoundTag h = (CompoundTag) t;
                    if (h.getInt("id") != a) continue;
                    if (h.hasUUID("owner")) { toast(p, "Casa e deja vândută.", false); break; }
                    double dx = p.getX() - h.getInt("x"), dz = p.getZ() - h.getInt("z");
                    if (dx * dx + dz * dz > 400) { toast(p, "Trebuie să fii lângă casă.", false); break; }
                    if (!acc.spend(h.getInt("price"))) { toast(p, "Nu ai destui lei.", false); break; }
                    h.putUUID("owner", p.getUUID()); h.putString("ownerName", acc.displayName(p.getName().getString()));
                    acc.addTx("Casa nr. " + h.getInt("id") + " -" + h.getInt("price"));
                    toast(p, "Ai cumpărat casa nr. " + h.getInt("id") + ". Contractul e în Documente.", true);
                    break;
                }
            }
            case ActionPacket.FG_TAKE -> {
                if (!(acc.fgAccess || acc.factionLeader)) { toast(p, "Nu ai acces la garajul facțiunii.", false); break; }
                if (acc.faction.isEmpty() || !zoneOk(d, p, acc.faction) || !hasZone(d, acc.faction)) { toast(p, "Nu ești într-un garaj al facțiunii.", false); break; }
                ListTag list = d.factionVehicles.get(acc.faction.toLowerCase());
                if (list == null || a < 0 || a >= list.size()) break;
                CompoundTag entry = list.getCompound(a);
                EntityType<?> type2 = EntityType.byString(entry.getString("type")).orElse(null);
                ServerLevel level = p.serverLevel();
                Entity e = type2 == null ? null : type2.create(level);
                if (e == null) break;
                CompoundTag data = entry.getCompound("data").copy();
                data.remove("UUID");
                e.load(data);
                Vec3 look = p.getLookAngle();
                e.moveTo(p.getX() + look.x * 4, p.getY(), p.getZ() + look.z * 4, p.getYRot(), 0);
                level.addFreshEntity(e);
                toast(p, "Vehicul de serviciu scos.", true);
            }
            case ActionPacket.FG_PARK -> {
                if (!(acc.fgAccess || acc.factionLeader)) { toast(p, "Nu ai acces la garajul facțiunii.", false); break; }
                if (acc.faction.isEmpty() || !hasZone(d, acc.faction) || !zoneOk(d, p, acc.faction)) { toast(p, "Nu ești într-un garaj al facțiunii.", false); break; }
                Entity v = VehicleUtil.find(p);
                if (v == null) { toast(p, "Nu e niciun vehicul lângă tine.", false); break; }
                v.ejectPassengers(); v.discard();
                toast(p, "Vehicul returnat în garaj.", true);
            }
            case ActionPacket.PART_TOGGLE -> {
                if (Jobs.byKey(acc.job) != Jobs.MECHANIC) { toast(p, "Trebuie să fii pe jobul Mecanic.", false); break; }
                if (a < 0 || a >= Parts.ALL.size()) break;
                Entity v = VehicleUtil.find(p);
                if (v == null) { toast(p, "Nu e niciun vehicul lângă tine.", false); break; }
                Parts.Part part = Parts.ALL.get(a);
                Set<String> set = installed(d, v.getUUID());
                if (set.contains(part.id())) {
                    for (Parts.Part o : Parts.ALL) if (set.contains(o.id()) && Arrays.asList(o.deps()).contains(part.id())) { toast(p, "Demontează întâi: " + o.name(), false); return; }
                    set.remove(part.id());
                    if (part.id().equals("neon")) { d.neon.remove(v.getUUID()); Net.CH.send(PacketDistributor.ALL.noArg(), new NeonPacket(v.getUUID(), -1)); }
                    saveParts(d, v.getUUID(), set);
                    toast(p, "Piesă demontată.", true);
                } else {
                    for (String dep : part.deps()) if (!set.contains(dep)) { toast(p, "Lipsește: " + Parts.ALL.get(Parts.index(dep)).name(), false); return; }
                    ServerPlayer customer = null;
                    for (ServerPlayer sp : p.serverLevel().players())
                        if (sp != p && sp.distanceToSqr(p) < 64 && (customer == null || sp.distanceToSqr(p) < customer.distanceToSqr(p))) customer = sp;
                    if (customer != null) {
                        Account ca = d.acc(customer);
                        if (!ca.spend(part.price())) { toast(p, "Clientul nu are destui lei.", false); toast(customer, "Nu ai destui lei (" + part.price() + ").", false); return; }
                        ca.addTx("Tuning " + part.name() + " -" + part.price());
                        acc.cash += Math.round(part.price() * 0.8);
                        toast(customer, "Ai plătit " + part.price() + " lei pentru " + part.name(), true);
                        Sync.send(customer);
                    }
                    set.add(part.id());
                    saveParts(d, v.getUUID(), set);
                    toast(p, "Piesă montată: " + part.name(), true);
                    JobEvents.pay(p, Jobs.MECHANIC.pay);
                }
            }
            case ActionPacket.NEON_SET -> {
                if (Jobs.byKey(acc.job) != Jobs.MECHANIC) break;
                Entity v = VehicleUtil.find(p);
                if (v == null || !installed(d, v.getUUID()).contains("neon")) { toast(p, "Montează întâi piesa NEON.", false); break; }
                d.neon.put(v.getUUID(), a & 0xFFFFFF);
                Net.CH.send(PacketDistributor.ALL.noArg(), new NeonPacket(v.getUUID(), a & 0xFFFFFF));
                d.setDirty();
                toast(p, "Neon setat.", true);
            }
            case ActionPacket.FAC_CREATE -> {
                if (!(acc.staff || p.hasPermissions(2))) { toast(p, "Doar staff poate crea facțiuni.", false); break; }
                if (!acc.faction.isEmpty()) { toast(p, "Ești deja într-o facțiune.", false); break; }
                String nm = clean(s, 16).toLowerCase().replaceAll("[^a-z0-9]", "");
                if (nm.length() < 3) { toast(p, "Nume prea scurt (min 3, litere/cifre).", false); break; }
                if (d.hasFaction(nm)) { toast(p, "Facțiunea există deja.", false); break; }
                d.addFaction(nm);
                acc.faction = nm; acc.factionLeader = true; acc.fgAccess = true;
                toast(p, "Facțiunea '" + nm + "' creată. Ești liderul.", true);
            }
            case ActionPacket.FAC_ADD -> {
                if (!manage(acc, p)) { toast(p, "Doar liderul poate adăuga membri.", false); break; }
                Account t = accById(d, a);
                if (t == null || !t.faction.isEmpty()) { toast(p, "ID invalid sau are deja o facțiune.", false); break; }
                t.faction = acc.faction; t.factionLeader = false; t.fgAccess = false;
                ServerPlayer tp = online(p.getServer(), d, a);
                if (tp != null) { toast(tp, "Ai fost adăugat în facțiunea " + acc.faction.toUpperCase(), true); Sync.send(tp); }
                toast(p, "Membru adăugat.", true);
            }
            case ActionPacket.FAC_REMOVE -> {
                if (!manage(acc, p)) break;
                Account t = accById(d, a);
                if (t == null || t == acc || !t.faction.equalsIgnoreCase(acc.faction)) break;
                t.faction = ""; t.factionLeader = false; t.fgAccess = false;
                ServerPlayer tp = online(p.getServer(), d, a);
                if (tp != null) { toast(tp, "Ai fost scos din facțiune.", false); Sync.send(tp); }
                toast(p, "Membru scos.", true);
            }
            case ActionPacket.FAC_GARAGE -> {
                if (!manage(acc, p)) break;
                Account t = accById(d, a);
                if (t == null || !t.faction.equalsIgnoreCase(acc.faction)) break;
                t.fgAccess = b == 1;
                ServerPlayer tp = online(p.getServer(), d, a);
                if (tp != null) { toast(tp, b == 1 ? "Ai primit acces la garajul facțiunii." : "Accesul la garaj ți-a fost retras.", b == 1); Sync.send(tp); }
            }
            case ActionPacket.FAC_ZONE -> {
                if (!manage(acc, p)) break;
                int r = Math.max(5, Math.min(a <= 0 ? 10 : a, 40));
                CompoundTag z = new CompoundTag();
                z.putString("name", acc.faction.toLowerCase()); z.putInt("x", p.getBlockX()); z.putInt("y", p.getBlockY()); z.putInt("z", p.getBlockZ()); z.putInt("r", r);
                d.garageZones.add(z);
                d.pois.add(new Poi("garage", "Garaj " + acc.faction, p.getBlockX(), p.getBlockY(), p.getBlockZ()));
                Sync.sendAll(p.getServer());
                toast(p, "Garaj privat creat aici (raza " + r + ").", true);
            }
            case ActionPacket.FAC_ZONECLEAR -> {
                if (!manage(acc, p)) break;
                clearZones(d, acc.faction);
                Sync.sendAll(p.getServer());
                toast(p, "Zonele de garaj ale facțiunii au fost șterse.", true);
            }
            case ActionPacket.FAC_VEH_ADD -> {
                if (!manage(acc, p)) break;
                Entity v = p.getVehicle();
                if (v == null || !VehicleUtil.isVehicle(v)) { toast(p, "Stai într-un vehicul ca să-l adaugi.", false); break; }
                CompoundTag data = new CompoundTag();
                v.saveWithoutId(data);
                CompoundTag e2 = new CompoundTag();
                e2.putString("type", EntityType.getKey(v.getType()).toString());
                e2.putString("name", v.getType().getDescription().getString());
                e2.put("data", data);
                d.factionVehicles.computeIfAbsent(acc.faction.toLowerCase(), k -> new ListTag()).add(e2);
                toast(p, "Vehicul adăugat în garajul facțiunii.", true);
            }
            case ActionPacket.FAC_DISBAND -> {
                if (!(acc.staff || p.hasPermissions(2)) || acc.faction.isEmpty()) break;
                String f = acc.faction;
                for (Map.Entry<UUID, Account> en : d.accounts.entrySet()) {
                    Account x = en.getValue();
                    if (!x.faction.equalsIgnoreCase(f)) continue;
                    x.faction = ""; x.factionLeader = false; x.fgAccess = false;
                    ServerPlayer tp = p.getServer().getPlayerList().getPlayer(en.getKey());
                    if (tp != null) Sync.send(tp);
                }
                clearZones(d, f);
                d.factionVehicles.remove(f.toLowerCase());
                d.removeFaction(f);
                Sync.sendAll(p.getServer());
                toast(p, "Facțiunea '" + f + "' a fost desființată.", true);
            }
            case ActionPacket.FAC_LEAVE -> {
                if (acc.faction.isEmpty()) break;
                if (acc.factionLeader) { toast(p, "Ești lider: dă întâi conducerea altcuiva.", false); break; }
                acc.faction = ""; acc.fgAccess = false;
                toast(p, "Ai părăsit facțiunea.", true);
            }
            case ActionPacket.FAC_LEADER -> {
                if (!manage(acc, p)) break;
                Account t = accById(d, a);
                if (t == null || t == acc || !t.faction.equalsIgnoreCase(acc.faction)) break;
                acc.factionLeader = false; t.factionLeader = true; t.fgAccess = true;
                toast(p, "Conducerea a fost predată lui #" + a + ".", true);
                ServerPlayer tp = online(p.getServer(), d, a);
                if (tp != null) { toast(tp, "Ești noul lider al facțiunii.", true); Sync.send(tp); }
            }
            default -> { }
        }
    }

    private static boolean leader(Account a) { return a.factionLeader && !a.faction.isEmpty(); }

    /** Lider sau staff care e membru al facțiunii. */
    private static boolean manage(Account a, ServerPlayer p) {
        return leader(a) || ((a.staff || p.hasPermissions(2)) && !a.faction.isEmpty());
    }

    private static ServerPlayer online(MinecraftServer s, MoonData d, int id) {
        for (ServerPlayer sp : s.getPlayerList().getPlayers()) if (d.acc(sp).id == id) return sp;
        return null;
    }

    private static void clearZones(MoonData d, String faction) {
        for (int i = d.garageZones.size() - 1; i >= 0; i--)
            if (d.garageZones.getCompound(i).getString("name").equalsIgnoreCase(faction)) d.garageZones.remove(i);
        d.pois.removeIf(x -> x.type().equals("garage") && x.name().equalsIgnoreCase("Garaj " + faction));
        d.setDirty();
    }

    public static boolean hasZone(MoonData d, String name) {
        for (Tag t : d.garageZones) if (((CompoundTag) t).getString("name").equalsIgnoreCase(name)) return true;
        return false;
    }

    private static String clean(String s, int max) {
        s = s == null ? "" : s.replaceAll("[\\p{Cntrl}|]", "").trim();
        return s.length() > max ? s.substring(0, max) : s;
    }

    // ---------- cereri de liste ----------
    public static void request(ServerPlayer p, MoonData d, int kind, int param, List<String> rows) {
        Account acc = d.acc(p);
        long now = System.currentTimeMillis();
        boolean police = isPolice(acc), staff = acc.staff || p.hasPermissions(2);
        switch (kind) {
            case 8 -> { // cautati
                if (acc.faction.isEmpty()) break;
                for (Tag t : d.wanted) { CompoundTag w = (CompoundTag) t; rows.add(w.getInt("target") + "|" + nameOf(d, w.getInt("target")) + "|" + w.getString("reason") + "|" + w.getString("by")); }
            }
            case 9 -> { // dosare pentru un ID, in factiunea mea
                if (acc.faction.isEmpty()) break;
                for (int i = d.records.size() - 1; i >= 0; i--) {
                    CompoundTag r = d.records.getCompound(i);
                    if (r.getInt("target") == param && r.getString("faction").equalsIgnoreCase(acc.faction))
                        rows.add(r.getString("by") + "|" + r.getString("text"));
                }
            }
            case 10 -> { // dispecerat
                if (!police) break;
                for (int i = d.dispatches.size() - 1; i >= 0; i--) {
                    CompoundTag c = d.dispatches.getCompound(i);
                    rows.add(c.getInt("id") + "|" + c.getString("text") + "|" + c.getInt("x") + "|" + c.getInt("z") + "|" + (c.getBoolean("open") ? 1 : 0));
                }
            }
            case 11 -> { // unitati online
                if (acc.faction.isEmpty()) break;
                for (ServerPlayer sp : p.getServer().getPlayerList().getPlayers()) {
                    Account x = d.acc(sp);
                    if (x.faction.equalsIgnoreCase(acc.faction))
                        rows.add(x.id + "|" + x.displayName(sp.getName().getString()) + "|" + (Jobs.byKey(x.job) == null ? "-" : Jobs.byKey(x.job).label) + "|" + sp.getBlockX() + "|" + sp.getBlockZ());
                }
            }
            case 12 -> { // cautare persoana
                if (acc.faction.isEmpty()) break;
                Account t = accById(d, param);
                if (t == null) { rows.add("Nicio persoană cu acest ID."); break; }
                int recs = 0, wants = 0;
                for (Tag x : d.records) if (((CompoundTag) x).getInt("target") == param && ((CompoundTag) x).getString("faction").equalsIgnoreCase(acc.faction)) recs++;
                for (Tag x : d.wanted) if (((CompoundTag) x).getInt("target") == param) wants++;
                rows.add("Nume: " + t.first + " " + t.last + "  (ID #" + t.id + ")");
                rows.add("Vârstă: " + t.age + "   Sex: " + t.sex + "   Tel: " + t.phone());
                rows.add("Job: " + (t.job.isEmpty() ? "-" : t.job) + "   Facțiune: " + (t.faction.isEmpty() ? "-" : t.faction));
                rows.add("Permis auto: " + (t.license ? "DA" : "NU") + "   Permis armă: " + (t.licenseGun ? "DA" : "NU"));
                rows.add("Dosare: " + recs + "   Căutat: " + (wants > 0 ? "DA" : "NU"));
            }
            case 13 -> { // dosare de dauna
                for (int i = d.claims.size() - 1; i >= 0; i--) {
                    CompoundTag c = d.claims.getCompound(i);
                    boolean mine = c.getUUID("owner").equals(p.getUUID());
                    if (!mine && !police && !staff) continue;
                    rows.add(c.getInt("id") + "|" + c.getString("ownerName") + "|" + c.getString("kind") + "|" + c.getInt("amount") + "|" + c.getInt("status") + "|" + c.getString("desc"));
                }
            }
            case 14 -> { // case
                for (Tag t : d.houses) {
                    CompoundTag h = (CompoundTag) t;
                    rows.add(h.getInt("id") + "|" + h.getInt("price") + "|" + (h.hasUUID("owner") ? h.getString("ownerName") : "") + "|" + h.getInt("x") + "|" + h.getInt("z") + "|" + (h.hasUUID("owner") && h.getUUID("owner").equals(p.getUUID()) ? 1 : 0));
                }
            }
            case 15 -> { for (int i = acc.tx.size() - 1; i >= 0; i--) rows.add(acc.tx.getString(i)); }
            case 16 -> { // garaj factiune
                ListTag l = d.factionVehicles.get(acc.faction.toLowerCase());
                if (l != null) for (int i = 0; i < l.size(); i++) rows.add(i + "|" + l.getCompound(i).getString("name"));
            }
            case 17 -> { // piese montate pe vehiculul apropiat
                Entity v = VehicleUtil.find(p);
                if (v == null) { rows.add("veh|"); break; }
                rows.add("veh|" + v.getType().getDescription().getString());
                for (String id : installed(d, v.getUUID())) rows.add("part|" + id);
                Integer rgb = d.neon.get(v.getUUID());
                rows.add("neon|" + (rgb == null ? -1 : rgb));
            }
            case 18 -> { // membri facțiune (primul rând = meta)
                if (acc.faction.isEmpty()) break;
                int zones = 0;
                for (Tag t : d.garageZones) if (((CompoundTag) t).getString("name").equalsIgnoreCase(acc.faction)) zones++;
                ListTag veh = d.factionVehicles.get(acc.faction.toLowerCase());
                List<String> mem = new ArrayList<>();
                for (Map.Entry<UUID, Account> en : d.accounts.entrySet()) {
                    Account x = en.getValue();
                    if (!x.faction.equalsIgnoreCase(acc.faction)) continue;
                    boolean on = p.getServer().getPlayerList().getPlayer(en.getKey()) != null;
                    mem.add(x.id + "|" + nameOf(d, x.id) + "|" + (x.factionLeader ? 1 : 0) + "|" + (x.fgAccess || x.factionLeader ? 1 : 0) + "|" + (on ? 1 : 0));
                }
                rows.add("meta|" + (acc.factionLeader ? 1 : 0) + "|" + zones + "|" + (veh == null ? 0 : veh.size()) + "|" + mem.size());
                rows.addAll(mem);
            }
            default -> { }
        }
    }
}
