package com.mooncity.core.client.screen;

import com.mooncity.core.net.ActionPacket;
import com.mooncity.core.net.ClientState;
import com.mooncity.core.net.Net;
import com.mooncity.core.server.Shop;
import net.minecraft.client.gui.GuiGraphics;

public class ShopScreen extends MoonScreen {
    public ShopScreen() { super("MAGAZIN"); pw = 300; ph = 40 + Shop.ITEMS.size() * 24 + 36; }

    @Override
    protected void build() {
        for (int i = 0; i < Shop.ITEMS.size(); i++) {
            final int idx = i;
            int y = py + 30 + i * 24;
            btn("Cumpără", px + pw - 130, y, 60, b -> Net.CH.sendToServer(new ActionPacket(ActionPacket.BUY, idx, 1)));
            btn("x5", px + pw - 66, y, 50, b -> Net.CH.sendToServer(new ActionPacket(ActionPacket.BUY, idx, 5)));
        }
        btn("Închide", px + pw / 2 - 40, py + ph - 28, 80, b -> onClose());
    }

    @Override
    protected void draw(GuiGraphics g, int mx, int my) {
        g.drawString(font, "Cash: " + ClientState.cash + " lei", px + 10, py + 18, 0xFF55FF55, false);
        for (int i = 0; i < Shop.ITEMS.size(); i++) {
            Shop.Entry e = Shop.ITEMS.get(i);
            int y = py + 30 + i * 24;
            g.renderItem(e.stack().get(), px + 10, y + 2);
            g.drawString(font, e.name(), px + 32, y + 6, 0xFFFFFFFF, false);
            g.drawString(font, e.price() + " lei", px + 130, y + 6, 0xFFF5C518, false);
        }
    }
}
