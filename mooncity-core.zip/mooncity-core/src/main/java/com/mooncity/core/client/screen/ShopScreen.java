package com.mooncity.core.client.screen;

import com.mooncity.core.net.ActionPacket;
import com.mooncity.core.net.ClientState;
import com.mooncity.core.net.Net;
import com.mooncity.core.server.Shop;
import net.minecraft.client.gui.GuiGraphics;

public class ShopScreen extends MoonScreen {
    private final Shop.Store store;

    public ShopScreen(int sub) {
        super(Shop.STORES.get(Math.floorMod(sub, Shop.STORES.size())).name().toUpperCase());
        store = Shop.STORES.get(Math.floorMod(sub, Shop.STORES.size()));
        pw = 310; ph = 70 + store.items().size() * 24;
    }

    @Override
    protected void build() {
        for (int i = 0; i < store.items().size(); i++) {
            final int idx = i;
            int y = py + 32 + i * 24;
            btn("Cumpără", px + pw - 132, y, 62, b -> Net.CH.sendToServer(new ActionPacket(ActionPacket.BUY, idx, 1)));
            btn("x5", px + pw - 66, y, 54, b -> Net.CH.sendToServer(new ActionPacket(ActionPacket.BUY, idx, 5)));
        }
        btn("Închide", px + pw / 2 - 40, py + ph - 26, 80, b -> onClose());
    }

    @Override
    protected void draw(GuiGraphics g, int mx, int my) {
        g.drawString(font, "Cash: " + ClientState.cash + "  Card: " + ClientState.bank, px + 10, py + 20, 0xFF55FF55, false);
        for (int i = 0; i < store.items().size(); i++) {
            Shop.Entry e = store.items().get(i);
            int y = py + 32 + i * 24;
            g.renderItem(e.stack().get(), px + 10, y + 2);
            g.drawString(font, e.name(), px + 32, y + 6, 0xFFFFFFFF, false);
            g.drawString(font, e.price() + " lei", px + 150, y + 6, 0xFFF5C518, false);
        }
    }
}
