package com.mooncity.core.client.screen;

import com.mooncity.core.net.ActionPacket;
import com.mooncity.core.net.ClientState;
import com.mooncity.core.net.Net;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.network.chat.Component;

import java.util.List;

public class MessagesScreen extends MoonScreen {
    private EditBox idBox, textBox;
    private final int prefill;
    private int ticks;

    public MessagesScreen() { this(0); }
    public MessagesScreen(int prefill) { super("MESAJE"); this.prefill = prefill; pw = 340; ph = 230; }

    @Override
    protected void build() {
        idBox = new EditBox(font, px + 10, py + ph - 60, 50, 18, Component.literal("ID"));
        idBox.setMaxLength(6);
        idBox.setFilter(s -> s.matches("\\d*"));
        if (prefill > 0) idBox.setValue(String.valueOf(prefill));
        idBox.setHint(Component.literal("ID"));
        addRenderableWidget(idBox);
        textBox = new EditBox(font, px + 64, py + ph - 60, pw - 74, 18, Component.literal("Mesaj"));
        textBox.setMaxLength(120);
        textBox.setHint(Component.literal("Scrie un mesaj..."));
        addRenderableWidget(textBox);
        btn("Trimite", px + 10, py + ph - 34, 90, b -> {
            if (idBox.getValue().isEmpty() || textBox.getValue().isBlank()) return;
            Net.CH.sendToServer(new ActionPacket(ActionPacket.SEND_MSG, Integer.parseInt(idBox.getValue()), 0, textBox.getValue()));
            textBox.setValue("");
        });
        btn("Închide", px + pw - 100, py + ph - 34, 90, b -> onClose());
    }

    @Override
    public void tick() { if (ticks++ % 40 == 0) Net.CH.sendToServer(new ActionPacket(ActionPacket.REQ, 2, 0)); }

    @Override
    protected void draw(GuiGraphics g, int mx, int my) {
        List<String> in = ClientState.list(2);
        if (in.isEmpty()) g.drawString(font, "Nu ai mesaje.", px + 12, py + 28, 0xFF888888, false);
        for (int i = 0; i < Math.min(6, in.size()); i++) {
            String[] p = in.get(i).split("\\|", 2);
            g.drawString(font, font.plainSubstrByWidth(p[0] + ": " + (p.length > 1 ? p[1] : ""), pw - 24), px + 12, py + 28 + i * 20, i == 0 ? 0xFFF5C518 : 0xFFDDDDDD, false);
        }
    }
}
