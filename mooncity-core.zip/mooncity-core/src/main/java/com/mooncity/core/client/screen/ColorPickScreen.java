package com.mooncity.core.client.screen;

import net.minecraft.client.gui.GuiGraphics;

import java.util.function.IntConsumer;

public class ColorPickScreen extends MoonScreen {
    private int r, g, b;
    private final IntConsumer done;

    public ColorPickScreen(String title, int r, int g, int b, IntConsumer done) {
        super(title); this.r = r; this.g = g; this.b = b; this.done = done; pw = 220; ph = 170;
    }

    @Override
    protected void build() {
        addRenderableWidget(new ColorSlider(px + 10, py + 28, pw - 20, "Roșu", r, v -> r = v));
        addRenderableWidget(new ColorSlider(px + 10, py + 48, pw - 20, "Verde", g, v -> g = v));
        addRenderableWidget(new ColorSlider(px + 10, py + 68, pw - 20, "Albastru", b, v -> b = v));
        btn("Aplică", px + 10, py + 135, 90, bt -> { done.accept((r << 16) | (g << 8) | b); onClose(); });
        btn("Anulează", px + pw - 100, py + 135, 90, bt -> onClose());
    }

    @Override
    protected void draw(GuiGraphics gg, int mx, int my) {
        gg.fill(px + 10, py + 92, px + pw - 10, py + 126, 0xFF000000 | (r << 16) | (g << 8) | b);
    }
}
