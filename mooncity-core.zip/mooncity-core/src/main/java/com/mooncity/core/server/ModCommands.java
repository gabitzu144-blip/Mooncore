package com.mooncity.core.server;

import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.LongArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mooncity.core.MoonCity;
import com.mooncity.core.data.Account;
import com.mooncity.core.data.MoonData;
import com.mooncity.core.data.Poi;
import com.mooncity.core.data.Zone;
import com.mooncity.core.entity.ModEntities;
import com.mooncity.core.entity.NpcEntity;
import com.mooncity.core.net.Net;
import com.mooncity.core.net.OpenScreenPacket;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.PacketDistributor;

import java.util.List;

@Mod.EventBusSubscriber(modid = MoonCity.MODID)
public class ModCommands {
    private static final String[] NPC_NAMES = {"Bancher", "Vânzător", "Benzinar", "Kevin", "Dealer"};
    private static final List<String> POI_TYPES = List.of("garage", "job", "shop", "bank", "fuel", "delivery", "spawn", "safezone", "dealer");

    private static int spawnNpc(CommandContext<CommandSourceStack> c, int sub) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        String t = StringArgumentType.getString(c, "type");
        int v = switch (t) { case "banker" -> 0; case "shop" -> 1; case "fuel" -> 2; case "kevin" -> 3; case "dealer" -> 4; default -> -1; };
        if (v < 0) { c.getSource().sendFailure(Component.literal("Tipuri: banker, shop [0-4], fuel, kevin, dealer")); return 0; }
        ServerPlayer p = c.getSource().getPlayerOrException();
        NpcEntity n = ModEntities.NPC.get().create(p.serverLevel());
        if (n == null) return 0;
        n.setVariant(v);
        n.setSub(sub);
        n.moveTo(p.getX(), p.getY(), p.getZ(), p.getYRot() + 180, 0);
        n.setYHeadRot(p.getYRot() + 180);
        String name = v == 1 ? Shop.STORES.get(Math.floorMod(sub, Shop.STORES.size())).name() : NPC_NAMES[v];
        n.setCustomName(Component.literal(name));
        n.setCustomNameVisible(true);
        p.serverLevel().addFreshEntity(n);
        return 1;
    }

    private static int zone(CommandContext<CommandSourceStack> c, int r) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        ServerPlayer p = c.getSource().getPlayerOrException();
        MoonData md = MoonData.get(c.getSource().getServer());
        String nm = StringArgumentType.getString(c, "name").toLowerCase();
        net.minecraft.nbt.CompoundTag z = new net.minecraft.nbt.CompoundTag();
        z.putString("name", nm); z.putInt("x", p.getBlockX()); z.putInt("y", p.getBlockY()); z.putInt("z", p.getBlockZ()); z.putInt("r", r);
        md.garageZones.add(z);
        md.pois.add(new Poi("garage", "Garaj " + nm, p.getBlockX(), p.getBlockY(), p.getBlockZ()));
        md.setDirty();
        Sync.sendAll(c.getSource().getServer());
        c.getSource().sendSuccess(() -> Component.literal("Zonă de garaj '" + nm + "' (raza " + r + ") creată."), true);
        return 1;
    }

    @SubscribeEvent
    public static void register(RegisterCommandsEvent e) {
        var d = e.getDispatcher();

        d.register(Commands.literal("setid").requires(s -> s.hasPermission(2))
            .then(Commands.argument("player", EntityArgument.player())
            .then(Commands.argument("id", IntegerArgumentType.integer(1)).executes(c -> {
                ServerPlayer t = EntityArgument.getPlayer(c, "player");
                int id = IntegerArgumentType.getInteger(c, "id");
                MoonData md = MoonData.get(c.getSource().getServer());
                md.acc(t);
                if (!md.setId(t.getUUID(), id)) { c.getSource().sendFailure(Component.literal("ID-ul " + id + " e deja luat.")); return 0; }
                Sync.send(t);
                c.getSource().sendSuccess(() -> Component.literal(t.getName().getString() + " are acum ID " + id), true);
                return 1;
            }))));

        d.register(Commands.literal("givemoney").requires(s -> s.hasPermission(2))
            .then(Commands.argument("player", EntityArgument.player())
            .then(Commands.argument("amount", LongArgumentType.longArg(1)).executes(c -> {
                ServerPlayer t = EntityArgument.getPlayer(c, "player");
                long amt = LongArgumentType.getLong(c, "amount");
                MoonData md = MoonData.get(c.getSource().getServer());
                md.acc(t).cash += amt;
                md.setDirty();
                Sync.send(t);
                c.getSource().sendSuccess(() -> Component.literal("+" + amt + " lei pentru " + t.getName().getString()), true);
                return 1;
            }))));

        // /rank set <jucator> <grad> <culoare>   |   /rank remove <jucator>
        d.register(Commands.literal("rank").requires(s -> s.hasPermission(2))
            .then(Commands.literal("set").then(Commands.argument("player", EntityArgument.player())
                .then(Commands.argument("rank", StringArgumentType.word())
                .then(Commands.argument("color", StringArgumentType.word()).executes(c -> {
                    ServerPlayer t = EntityArgument.getPlayer(c, "player");
                    MoonData md = MoonData.get(c.getSource().getServer());
                    Account a = md.acc(t);
                    a.rankLabel = StringArgumentType.getString(c, "rank").replace('_', ' ');
                    a.rankColor = StringArgumentType.getString(c, "color");
                    md.setDirty();
                    Ranks.apply(t);
                    Sync.send(t);
                    c.getSource().sendSuccess(() -> Component.literal("Grad setat: " + a.rankLabel + " (" + a.rankColor + ")"), true);
                    return 1;
                })))))
            .then(Commands.literal("remove").then(Commands.argument("player", EntityArgument.player()).executes(c -> {
                ServerPlayer t = EntityArgument.getPlayer(c, "player");
                MoonData md = MoonData.get(c.getSource().getServer());
                md.acc(t).rankLabel = "";
                md.setDirty();
                Ranks.apply(t);
                Sync.send(t);
                return 1;
            }))));

        // /staff <jucator> <true|false>
        d.register(Commands.literal("staff").requires(s -> s.hasPermission(3))
            .then(Commands.argument("player", EntityArgument.player())
            .then(Commands.argument("value", BoolArgumentType.bool()).executes(c -> {
                ServerPlayer t = EntityArgument.getPlayer(c, "player");
                MoonData md = MoonData.get(c.getSource().getServer());
                md.acc(t).staff = BoolArgumentType.getBool(c, "value");
                md.setDirty();
                Sync.send(t);
                return 1;
            }))));

        // /ticket -> deschide ecranul de tickete
        d.register(Commands.literal("ticket").executes(c -> {
            ServerPlayer p = c.getSource().getPlayerOrException();
            Net.CH.send(PacketDistributor.PLAYER.with(() -> p), new OpenScreenPacket(20));
            return 1;
        }));


        // /anunt <text>  -> banner sus, ca o notificare de telefon
        d.register(Commands.literal("anunt").requires(s -> s.hasPermission(2) || (s.getEntity() instanceof ServerPlayer sp && MoonData.get(sp.getServer()).acc(sp).staff))
            .then(Commands.argument("text", StringArgumentType.greedyString()).executes(c -> {
                String text = StringArgumentType.getString(c, "text");
                Net.CH.send(PacketDistributor.ALL.noArg(), new com.mooncity.core.net.AnnouncePacket(text));
                return 1;
            })));

        // /112 <text> -> apel catre politie (dispecerat MDT)
        d.register(Commands.literal("112").then(Commands.argument("text", StringArgumentType.greedyString()).executes(c -> {
            ServerPlayer p = c.getSource().getPlayerOrException();
            Actions.handle(p, com.mooncity.core.net.ActionPacket.DISP_CALL, 0, 0, StringArgumentType.getString(c, "text"));
            return 1;
        })));

        // /faction set <jucator> <nume> | remove <jucator>
        d.register(Commands.literal("faction").requires(s -> s.hasPermission(2))
            .then(Commands.literal("set").then(Commands.argument("player", EntityArgument.player())
                .then(Commands.argument("name", StringArgumentType.word()).executes(c -> {
                    ServerPlayer t = EntityArgument.getPlayer(c, "player");
                    MoonData md = MoonData.get(c.getSource().getServer());
                    String fn = StringArgumentType.getString(c, "name").toLowerCase();
                    md.addFaction(fn);
                    md.acc(t).faction = fn; md.acc(t).fgAccess = true;
                    md.setDirty();
                    Sync.send(t);
                    c.getSource().sendSuccess(() -> Component.literal(t.getName().getString() + " -> facțiunea " + md.acc(t).faction), true);
                    return 1;
                }))))
            .then(Commands.literal("leader").then(Commands.argument("player", EntityArgument.player())
                .then(Commands.argument("name", StringArgumentType.word()).executes(c -> {
                    ServerPlayer t = EntityArgument.getPlayer(c, "player");
                    MoonData md = MoonData.get(c.getSource().getServer());
                    String fn = StringArgumentType.getString(c, "name").toLowerCase();
                    md.addFaction(fn);
                    Account a = md.acc(t);
                    a.faction = fn; a.factionLeader = true; a.fgAccess = true;
                    md.setDirty();
                    Sync.send(t);
                    Actions.toast(t, "Ești liderul facțiunii " + fn.toUpperCase(), true);
                    c.getSource().sendSuccess(() -> Component.literal(t.getName().getString() + " e liderul facțiunii " + fn), true);
                    return 1;
                }))))
            .then(Commands.literal("remove").then(Commands.argument("player", EntityArgument.player()).executes(c -> {
                ServerPlayer t = EntityArgument.getPlayer(c, "player");
                MoonData md = MoonData.get(c.getSource().getServer());
                md.acc(t).faction = ""; md.acc(t).factionLeader = false; md.acc(t).fgAccess = false;
                md.setDirty();
                Sync.send(t);
                return 1;
            }))));

        // /doc give <jucator> <auto|arma>   (staff sau politie)
        d.register(Commands.literal("doc").requires(s -> s.hasPermission(2) || (s.getEntity() instanceof ServerPlayer sp && Extra.isPolicePlayer(sp)))
            .then(Commands.literal("give").then(Commands.argument("player", EntityArgument.player())
                .then(Commands.argument("type", StringArgumentType.word()).executes(c -> {
                    ServerPlayer t = EntityArgument.getPlayer(c, "player");
                    String ty = StringArgumentType.getString(c, "type");
                    MoonData md = MoonData.get(c.getSource().getServer());
                    if (ty.equals("auto")) md.acc(t).license = true;
                    else if (ty.equals("arma")) md.acc(t).licenseGun = true;
                    else { c.getSource().sendFailure(Component.literal("Tipuri: auto, arma")); return 0; }
                    md.setDirty();
                    Sync.send(t);
                    Actions.toast(t, "Ai primit permis: " + ty, true);
                    return 1;
                })))));

        // /garage <nume> add | zone [raza] | clear
        d.register(Commands.literal("garage").requires(s -> s.hasPermission(2))
            .then(Commands.argument("name", StringArgumentType.word())
                .then(Commands.literal("add").executes(c -> {
                    ServerPlayer p = c.getSource().getPlayerOrException();
                    var v = p.getVehicle();
                    if (v == null || !com.mooncity.core.util.VehicleUtil.isVehicle(v)) { c.getSource().sendFailure(Component.literal("Stai într-un vehicul Vehicle.")); return 0; }
                    MoonData md = MoonData.get(c.getSource().getServer());
                    String nm = StringArgumentType.getString(c, "name").toLowerCase();
                    net.minecraft.nbt.CompoundTag data = new net.minecraft.nbt.CompoundTag();
                    v.saveWithoutId(data);
                    net.minecraft.nbt.CompoundTag e2 = new net.minecraft.nbt.CompoundTag();
                    e2.putString("type", net.minecraft.world.entity.EntityType.getKey(v.getType()).toString());
                    e2.putString("name", v.getType().getDescription().getString());
                    e2.put("data", data);
                    md.factionVehicles.computeIfAbsent(nm, k -> new net.minecraft.nbt.ListTag()).add(e2);
                    md.setDirty();
                    c.getSource().sendSuccess(() -> Component.literal("Vehicul adăugat în garajul '" + nm + "'."), true);
                    return 1;
                }))
                .then(Commands.literal("zone").executes(c -> zone(c, 10))
                    .then(Commands.argument("radius", IntegerArgumentType.integer(3, 60)).executes(c -> zone(c, IntegerArgumentType.getInteger(c, "radius")))))
                .then(Commands.literal("clear").executes(c -> {
                    MoonData md = MoonData.get(c.getSource().getServer());
                    String nm = StringArgumentType.getString(c, "name").toLowerCase();
                    md.factionVehicles.remove(nm);
                    md.setDirty();
                    return 1;
                }))));

        d.register(Commands.literal("mc").requires(s -> s.hasPermission(2))
            .then(Commands.literal("npc")
                .then(Commands.argument("type", StringArgumentType.word()).executes(c -> spawnNpc(c, 0))
                    .then(Commands.argument("sub", IntegerArgumentType.integer(0, 4)).executes(c -> spawnNpc(c, IntegerArgumentType.getInteger(c, "sub"))))))
            .then(Commands.literal("npcremove").executes(c -> {
                ServerPlayer p = c.getSource().getPlayerOrException();
                var l = p.serverLevel().getEntitiesOfClass(NpcEntity.class, p.getBoundingBox().inflate(4));
                l.forEach(n -> n.discard());
                c.getSource().sendSuccess(() -> Component.literal("Șterse: " + l.size()), true);
                return l.size();
            }))
            .then(Commands.literal("poi")
                .then(Commands.argument("type", StringArgumentType.word())
                .then(Commands.argument("name", StringArgumentType.greedyString()).executes(c -> {
                    String t = StringArgumentType.getString(c, "type");
                    if (!POI_TYPES.contains(t)) { c.getSource().sendFailure(Component.literal("Tipuri: " + POI_TYPES)); return 0; }
                    ServerPlayer p = c.getSource().getPlayerOrException();
                    MoonData md = MoonData.get(c.getSource().getServer());
                    md.pois.add(new Poi(t, StringArgumentType.getString(c, "name"), p.getBlockX(), p.getBlockY(), p.getBlockZ()));
                    md.setDirty();
                    Sync.sendAll(c.getSource().getServer());
                    c.getSource().sendSuccess(() -> Component.literal("Punct adăugat."), true);
                    return 1;
                }))))
            .then(Commands.literal("safezone")
                .then(Commands.argument("radius", IntegerArgumentType.integer(3, 500))
                .then(Commands.argument("name", StringArgumentType.greedyString()).executes(c -> {
                    ServerPlayer p = c.getSource().getPlayerOrException();
                    MoonData md = MoonData.get(c.getSource().getServer());
                    String nm = StringArgumentType.getString(c, "name");
                    md.zones.add(new Zone(nm, p.getBlockX(), p.getBlockY(), p.getBlockZ(), IntegerArgumentType.getInteger(c, "radius")));
                    md.pois.add(new Poi("safezone", nm, p.getBlockX(), p.getBlockY(), p.getBlockZ()));
                    md.setDirty();
                    Sync.sendAll(c.getSource().getServer());
                    c.getSource().sendSuccess(() -> Component.literal("Safe zone adăugată."), true);
                    return 1;
                }))))
            .then(Commands.literal("house").then(Commands.argument("price", IntegerArgumentType.integer(1)).executes(c -> {
                ServerPlayer p = c.getSource().getPlayerOrException();
                MoonData md = MoonData.get(c.getSource().getServer());
                net.minecraft.nbt.CompoundTag h = new net.minecraft.nbt.CompoundTag();
                int id = md.nextHouseId++;
                h.putInt("id", id); h.putInt("x", p.getBlockX()); h.putInt("y", p.getBlockY()); h.putInt("z", p.getBlockZ());
                h.putInt("price", IntegerArgumentType.getInteger(c, "price"));
                md.houses.add(h);
                md.pois.add(new Poi("house", "Casa nr. " + id, p.getBlockX(), p.getBlockY(), p.getBlockZ()));
                md.setDirty();
                Sync.sendAll(c.getSource().getServer());
                c.getSource().sendSuccess(() -> Component.literal("Casa nr. " + id + " creată."), true);
                return 1;
            })))
            .then(Commands.literal("zoneclear").executes(c -> {
                MoonData md = MoonData.get(c.getSource().getServer());
                md.zones.clear();
                md.pois.removeIf(x -> x.type().equals("safezone"));
                md.setDirty();
                Sync.sendAll(c.getSource().getServer());
                return 1;
            }))
            .then(Commands.literal("license")
                .then(Commands.argument("player", EntityArgument.player()).executes(c -> {
                    ServerPlayer t = EntityArgument.getPlayer(c, "player");
                    MoonData md = MoonData.get(c.getSource().getServer());
                    md.acc(t).license = true;
                    md.setDirty();
                    Sync.send(t);
                    return 1;
                })))
            .then(Commands.literal("poiclear").executes(c -> {
                MoonData md = MoonData.get(c.getSource().getServer());
                md.pois.clear();
                md.setDirty();
                Sync.sendAll(c.getSource().getServer());
                return 1;
            })));
    }
}
