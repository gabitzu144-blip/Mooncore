package com.mooncity.core.server;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.LongArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mooncity.core.MoonCity;
import com.mooncity.core.data.Account;
import com.mooncity.core.data.MoonData;
import com.mooncity.core.data.Poi;
import com.mooncity.core.entity.ModEntities;
import com.mooncity.core.entity.NpcEntity;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.List;

@Mod.EventBusSubscriber(modid = MoonCity.MODID)
public class ModCommands {
    private static final String[] NPC_NAMES = {"Bancher", "Vânzător", "Benzinar"};
    private static final List<String> POI_TYPES = List.of("garage", "job", "shop", "bank", "fuel", "delivery");

    @SubscribeEvent
    public static void register(RegisterCommandsEvent e) {
        var d = e.getDispatcher();

        // /setid <jucator> <id>
        d.register(Commands.literal("setid").requires(s -> s.hasPermission(2))
            .then(Commands.argument("player", EntityArgument.player())
            .then(Commands.argument("id", IntegerArgumentType.integer(1)).executes(c -> {
                ServerPlayer t = EntityArgument.getPlayer(c, "player");
                int id = IntegerArgumentType.getInteger(c, "id");
                MoonData md = MoonData.get(c.getSource().getServer());
                md.acc(t);
                if (!md.setId(t.getUUID(), id)) {
                    c.getSource().sendFailure(Component.literal("ID-ul " + id + " e deja luat."));
                    return 0;
                }
                Sync.send(t);
                c.getSource().sendSuccess(() -> Component.literal(t.getName().getString() + " are acum ID " + id), true);
                return 1;
            }))));

        // /givemoney <jucator> <lei>
        d.register(Commands.literal("givemoney").requires(s -> s.hasPermission(2))
            .then(Commands.argument("player", EntityArgument.player())
            .then(Commands.argument("amount", LongArgumentType.longArg(1)).executes(c -> {
                ServerPlayer t = EntityArgument.getPlayer(c, "player");
                long amt = LongArgumentType.getLong(c, "amount");
                MoonData md = MoonData.get(c.getSource().getServer());
                Account a = md.acc(t);
                a.cash += amt;
                md.setDirty();
                Sync.send(t);
                c.getSource().sendSuccess(() -> Component.literal("+" + amt + " lei pentru " + t.getName().getString()), true);
                return 1;
            }))));

        // /mc npc <banker|shop|fuel>, /mc npcremove, /mc poi <tip> <nume>, /mc poiclear
        d.register(Commands.literal("mc").requires(s -> s.hasPermission(2))
            .then(Commands.literal("npc")
                .then(Commands.argument("type", StringArgumentType.word()).executes(c -> {
                    String t = StringArgumentType.getString(c, "type");
                    int v = switch (t) { case "banker" -> 0; case "shop" -> 1; case "fuel" -> 2; default -> -1; };
                    if (v < 0) { c.getSource().sendFailure(Component.literal("Tipuri: banker, shop, fuel")); return 0; }
                    ServerPlayer p = c.getSource().getPlayerOrException();
                    NpcEntity n = ModEntities.NPC.get().create(p.serverLevel());
                    if (n == null) return 0;
                    n.setVariant(v);
                    n.moveTo(p.getX(), p.getY(), p.getZ(), p.getYRot() + 180, 0);
                    n.setYHeadRot(p.getYRot() + 180);
                    n.setCustomName(Component.literal(NPC_NAMES[v]));
                    n.setCustomNameVisible(true);
                    p.serverLevel().addFreshEntity(n);
                    return 1;
                })))
            .then(Commands.literal("npcremove").executes(c -> {
                ServerPlayer p = c.getSource().getPlayerOrException();
                var l = p.serverLevel().getEntitiesOfClass(NpcEntity.class, p.getBoundingBox().inflate(4));
                l.forEach(n -> n.discard());
                c.getSource().sendSuccess(() -> Component.literal("Șterse: " + l.size()), true);
                return l.size();
            }))
            .then(Commands.literal("poi")
                .then(Commands.argument("type", StringArgumentType.word())
                .then(Commands.argument("name", StringArgumentType.greedyString()).executes(c -> {
                    String t = StringArgumentType.getString(c, "type");
                    if (!POI_TYPES.contains(t)) {
                        c.getSource().sendFailure(Component.literal("Tipuri: " + POI_TYPES));
                        return 0;
                    }
                    ServerPlayer p = c.getSource().getPlayerOrException();
                    MoonData md = MoonData.get(c.getSource().getServer());
                    md.pois.add(new Poi(t, StringArgumentType.getString(c, "name"), p.getBlockX(), p.getBlockY(), p.getBlockZ()));
                    md.setDirty();
                    Sync.sendAll(c.getSource().getServer());
                    c.getSource().sendSuccess(() -> Component.literal("Punct adăugat."), true);
                    return 1;
                }))))
            .then(Commands.literal("poiclear").executes(c -> {
                MoonData md = MoonData.get(c.getSource().getServer());
                md.pois.clear();
                md.setDirty();
                Sync.sendAll(c.getSource().getServer());
                return 1;
            })));
    }
}
