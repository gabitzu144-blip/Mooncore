package com.mooncity.core.client.screen;

import com.mooncity.core.net.ActionPacket;
import com.mooncity.core.net.ClientState;
import com.mooncity.core.net.Net;
import com.mooncity.core.client.Ui;
import com.mooncity.core.server.Catalog;
import net.minecraft.client.gui.GuiGraphics;

import java.util.List;

public class DealerScreen extends MoonScreen {
    private int cls = 0, sel = -1, r = 255, g = 255, b = 255, ticks = 0;

    public DealerScreen() { super("DEALER AUTO"); pw = 400; ph = 252; }

    private int stock(String key) {
        for (String s : ClientState.list(3)) { String[] p = s.split("\\|"); if (p[0].equals(key)) return Integer.parseInt(p[1]); }
        return 5;
    }

    @Override
    protected void build() {
        for (int i = 0; i < Catalog.CLASSES.length; i++) {
            final int fi = i;
            btn((cls == i ? "► " : "") + "Clasa " + Catalog.CLASSES[i], px + 8, py + 24 + i * 22, 96, bt -> { cls = fi; sel = -1; rebuildWidgets(); });
        }
        List<Integer> ids = Catalog.ofClass(Catalog.CLASSES[cls]);
        for (int i = 0; i < ids.size() && i < 8; i++) {
            final int idx = ids.get(i);
            Catalog.Model m = Catalog.get(idx);
            btn((sel == idx ? "► " : "") + m.label(), px + 110, py + 24 + i * 21, 116, bt -> { sel = idx; rebuildWidgets(); });
        }
        addRenderableWidget(new ColorSlider(px + 236, py + 138, 154, "Roșu", r, v -> r = v));
        addRenderableWidget(new ColorSlider(px + 236, py + 156, 154, "Verde", g, v -> g = v));
        addRenderableWidget(new ColorSlider(px + 236, py + 174, 154, "Albastru", b, v -> b = v));
        btn("CUMPĂRĂ", px + 236, py + 200, 154, bt -> {
            if (sel >= 0) Net.CH.sendToServer(new ActionPacket(ActionPacket.DEALER_BUY, sel, (r << 16) | (g << 8) | b));
        });
        btn("Închide", px + 8, py + ph - 26, 96, bt -> onClose());
    }

    @Override
    public void tick() { if (ticks++ % 60 == 0) Net.CH.sendToServer(new ActionPacket(ActionPacket.REQ, 3, 0)); }

    @Override
    protected void draw(GuiGraphics gg, int mx, int my) {
        gg.drawString(font, "Cash: " + ClientState.cash + "  Card: " + ClientState.bank, px + 110, py + ph - 20, 0xFF55FF55, false);
        Catalog.Model m = Catalog.get(sel);
        if (m == null) { gg.drawString(font, "Alege un model din listă.", px + 236, py + 30, 0xFF888888, false); return; }
        gg.drawString(font, m.label(), px + 236, py + 24, 0xFFFFFFFF, false);
        gg.drawString(font, m.price() + " lei", px + 236, py + 36, 0xFFF5C518, false);
        gg.drawString(font, "Stoc: " + stock(m.key()), px + 330, py + 36, stock(m.key()) > 0 ? 0xFF55FF55 : 0xFFFF5555, false);
        String[] n = {"Viteză", "Control", "Frână", "Accelerație"};
        int[] v = {m.speed(), m.handling(), m.brake(), m.accel()};
        for (int i = 0; i < 4; i++) {
            gg.drawString(font, n[i], px + 236, py + 54 + i * 14, 0xFFAAAAAA, false);
            Ui.bar(gg, px + 300, py + 56 + i * 14, 90, 5, v[i] / 100f, 0xFF222844, 0xFF22C55E);
        }
        gg.fill(px + 236, py + 114, px + 390, py + 134, 0xFF000000 | (r << 16) | (g << 8) | b);
    }
}
