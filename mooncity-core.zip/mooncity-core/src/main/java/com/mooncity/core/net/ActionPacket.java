package com.mooncity.core.net;

import com.mooncity.core.server.Actions;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class ActionPacket {
    public static final int DEPOSIT = 0, WITHDRAW = 1, BUY = 2, REFUEL = 3, PARK = 4, TAKE = 5, TRUNK = 6,
            JOB_START = 7, JOB_QUIT = 8, TRANSFER = 9, SEND_MSG = 10, CALL = 11, REQ = 12,
            AUC_SELL = 13, AUC_BUY = 14, LOTTERY = 15, BONUS = 16, DEALER_BUY = 17,
            CREATE_CHAR = 18, SPAWN_CHOICE = 19, EMOTE = 20, INV_EQUIP = 21, INV_DROP = 22,
            T_CREATE = 23, T_REPLY = 24, T_CLOSE = 25, DUTY = 26, MECH = 27, MINI_DONE = 28, INTERACT = 29, STAFF_TP = 30, ADMIN_SET = 31,
            PIN_CHECK = 32, PIN_SET = 33, WANT_ADD = 34, WANT_DEL = 35, REC_ADD = 36, DISP_CLOSE = 37, DISP_CALL = 38,
            INS_BUY = 39, CLAIM_FILE = 40, CLAIM_DECIDE = 41, HOUSE_BUY = 42, FG_TAKE = 43, FG_PARK = 44, PART_TOGGLE = 45, NEON_SET = 46,
            FAC_CREATE = 47, FAC_ADD = 48, FAC_REMOVE = 49, FAC_GARAGE = 50, FAC_ZONE = 51, FAC_ZONECLEAR = 52, FAC_VEH_ADD = 53, FAC_DISBAND = 54, FAC_LEADER = 55, FAC_LEAVE = 56, FAC_RANK = 57;

    public final int type, a, b;
    public final String s;

    public ActionPacket(int type, int a, int b) { this(type, a, b, ""); }
    public ActionPacket(int type, int a, int b, String s) { this.type = type; this.a = a; this.b = b; this.s = s; }

    public void encode(FriendlyByteBuf buf) { buf.writeInt(type); buf.writeInt(a); buf.writeInt(b); buf.writeUtf(s, 256); }
    public static ActionPacket decode(FriendlyByteBuf buf) {
        return new ActionPacket(buf.readInt(), buf.readInt(), buf.readInt(), buf.readUtf(256));
    }

    public static void handle(ActionPacket m, Supplier<NetworkEvent.Context> ctx) {
        ServerPlayer p = ctx.get().getSender();
        ctx.get().enqueueWork(() -> { if (p != null) Actions.handle(p, m.type, m.a, m.b, m.s); });
        ctx.get().setPacketHandled(true);
    }
}
