package com.mooncity.core.net;

import com.mooncity.core.server.Actions;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class ActionPacket {
    public static final int DEPOSIT = 0, WITHDRAW = 1, BUY = 2, REFUEL = 3, PARK = 4,
            TAKE = 5, TRUNK = 6, JOB_START = 7, JOB_QUIT = 8;

    public final int type, a, b;
    public ActionPacket(int type, int a, int b) { this.type = type; this.a = a; this.b = b; }
    public void encode(FriendlyByteBuf buf) { buf.writeInt(type); buf.writeInt(a); buf.writeInt(b); }
    public static ActionPacket decode(FriendlyByteBuf buf) { return new ActionPacket(buf.readInt(), buf.readInt(), buf.readInt()); }

    public static void handle(ActionPacket m, Supplier<NetworkEvent.Context> ctx) {
        ServerPlayer p = ctx.get().getSender();
        ctx.get().enqueueWork(() -> { if (p != null) Actions.handle(p, m.type, m.a, m.b); });
        ctx.get().setPacketHandled(true);
    }
}
